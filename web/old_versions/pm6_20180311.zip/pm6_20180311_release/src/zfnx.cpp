#include <allegro.h>
#include "pm.h"
#include <math.h>
#include <zlib.h>  


void erase_last_bmsg(void)
{
    extern char b_msg[40][80];
    int c;
    if (strcmp(b_msg[0],b_msg[1])==0) /* if last two are the same */
       for (c=0; c<39; c++)
          sprintf(b_msg[c], "%s", b_msg[c+1]);
}
void slide_bmsg(void)
{
    extern char b_msg[40][80];
    int c;
    for (c=39; c>0; c--)
       sprintf(b_msg[c], "%s", b_msg[c-1]);
}

void tsw(void)
{
   while (key[KEY_ESC]);
   clear_keybuf();
   while (!keypressed());
   clear_keybuf();
}

void reset_animation_sequence_passcounts(int pc)
{
   int c;
   for (c=0; c<NUM_ANS; c++)
   {
     zz[2][c] = pc;       // reset the passcounts 
     zz[1][c] = 0;        // set the bitmap indexes to 0
     zz[0][c] = zz[5][c]; // put the first shapes in 0
   }
   passcount = pc;
}

void update_animation(void)
{
   int y;
   passcount++; 
   for (y=0; y<NUM_ANS; y++)
      if (zz[4][y] != 0)
         if ((passcount - zz[2][y]) > zz[3][y])            
         {
            zz[2][y] = passcount;                     // set counter 
            zz[1][y]++;                               // next bitmap 
            if (zz[1][y] > zz[4][y]) zz[1][y] = 0;    // is bitmap past end? 
            zz[0][y] = zz[ 5 + zz[1][y] ] [y];        // put shape in 0 
         }
}

fixed get_rot_from_xyinc(int EN)
{
   fixed xlen = Efi[EN][2];
   fixed ylen = Efi[EN][3];
   fixed angle = fixatan2(ylen, xlen);
   return angle - itofix(64);
}

fixed get_rot_from_PXY(int EN, int p)
{
   fixed xlen = players[p].PX - Efi[EN][0];
   fixed ylen = players[p].PY - Efi[EN][1];
   fixed angle = fixatan2(ylen, xlen);
   return angle - itofix(64);
}

void seek_set_xyinc(int EN)
{
   int p = find_closest_player(EN);
   fixed xlen = players[p].PX - Efi[EN][0];   // get the x distance between enemy and player
   fixed ylen = players[p].PY - Efi[EN][1];   // get the y distance between enemy and player
   fixed hy_dist =  fixhypot(xlen, ylen);     // hypotenuse distance
   fixed speed = Efi[EN][5];                  // speed
   fixed scaler = fixdiv(hy_dist, speed);     // get scaler
   fixed xinc = fixdiv(xlen, scaler);         // calc xinc
   fixed yinc = fixdiv(ylen, scaler);         // calc yinc
   Efi[EN][2] = xinc;
   Efi[EN][3] = yinc;
}

void seek_set_xyinc(int EN, int x, int y)
{
   fixed xlen = itofix(x) - Efi[EN][0];       // get the x distance between enemy and x
   fixed ylen = itofix(y) - Efi[EN][1];       // get the y distance between enemy and y
   fixed hy_dist =  fixhypot(xlen, ylen);     // hypotenuse distance
   fixed speed = Efi[EN][5];                  // speed
   fixed scaler = fixdiv(hy_dist, speed);     // get scaler
   fixed xinc = fixdiv(xlen, scaler);         // calc xinc
   fixed yinc = fixdiv(ylen, scaler);         // calc yinc
   Efi[EN][2] = xinc;
   Efi[EN][3] = yinc;
}





int find_closest_player_flapper(int EN, int dir)
{
   fixed width = itofix(Ei[EN][17]); // fixed version of width
   int height  = Ei[EN][18];
   int depth   = Ei[EN][19];

   // get the enemy's trigger box y values
   int ey = fixtoi(Efi[EN][1]); 
   int ey1 = ey - height;
   int ey2 = ey + depth;

   fixed d[NUM_PLAYERS]; // array of distances for each player
   for (int p=0; p<NUM_PLAYERS; p++)
   {
      d[p] = itofix(-1); // default result (player not in range or not active) 
      if ((players[p].active) && (!players[p].paused))
      {
         // is player in the y range?
         int py = fixtoi(players[p].PY)+10; 
         if ((py > ey1) && (py < ey2)) 
         {
            fixed xlen = players[p].PX - Efi[EN][0]; // get x distance
            if ((!dir) && (xlen < itofix(0))) d[p] = -xlen; // left
            if ( (dir) && (xlen > itofix(0))) d[p] =  xlen; // right
         }
      }
      // check if distance is within range (width); invalidate if not
      if (d[p] > width) d[p] = itofix(-1);
   }

   fixed closest_val = itofix(9999);
   int closest_p = -1;
   for (int p=0; p<NUM_PLAYERS; p++)
   {
      if ((d[p] != itofix(-1)) && (d[p] < closest_val))
      {
         closest_val = d[p];
         closest_p = p;
      }   
   }
   if (closest_val == itofix(9999)) return -1;    // no player in range 
   else return closest_p;
}    


int find_closest_player_quad(int EN, int quad, int prox)
{
   int closest_p = -1;    // return -1 if no player in range
   fixed closest_val = itofix(3000);

   fixed fz = itofix(0);  
   fixed fm1 = itofix(-1);  
   fixed fprox = itofix(prox);  

   fixed d[NUM_PLAYERS];
   for (int p=0; p<NUM_PLAYERS; p++)
   {
      d[p] = fm1; // default result (players not in quad or not active) 
      if ((players[p].active) && (!players[p].paused))
      {
         fixed xlen = players[p].PX - Efi[EN][0];
         fixed ylen = players[p].PY - Efi[EN][1];

/*           normal cartesian
              I    x+  Y+        II | I
             II    x-  Y+       ----+----
             III   x-  Y-       III | IV
             IV    x+  Y-

             screen
              I    x+  Y-        II | I
             II    x-  Y-       ----+----
             III   x-  Y+       III | IV
             IV    x+  Y+ */
  
            if ((quad == 1) && (xlen >= fz) && (ylen <= fz)) d[p] = fixhypot(xlen,ylen);
            if ((quad == 2) && (xlen <= fz) && (ylen <= fz)) d[p] = fixhypot(xlen,ylen);
            if ((quad == 3) && (xlen <= fz) && (ylen >= fz)) d[p] = fixhypot(xlen,ylen);
            if ((quad == 4) && (xlen >= fz) && (ylen >= fz)) d[p] = fixhypot(xlen,ylen);
         }
         // check if distances are within range 
         if (d[p] > fprox) d[p] = fm1;
   }
   for (int p=0; p<NUM_PLAYERS; p++)
      if ((d[p] != fm1) && (d[p] < closest_val))
      {
         closest_val = d[p];
         closest_p = p;
      }   
   if (closest_val == itofix(3000)) return -1;    // no player in range 
   else return closest_p;
}

int find_closest_player(int EN)
{
   int closest_player = 0; // defaults to zero (will always return a valid player)
   fixed hd = itofix(10000);
   for (int p=0; p<NUM_PLAYERS; p++)
      if ((players[p].active) && (!players[p].paused))
      {
         fixed h = fixhypot((players[p].PX - Efi[EN][0]), (players[p].PY - Efi[EN][1]));
         if (h < hd)
         {
             hd = h;                 
             closest_player = p;
         }
      }   
   return closest_player;
}

fixed fixmod(fixed in, int mod)
{
   int t = fixtoi(in);
   int u = t / 20;
   int s = u * 20; 
   fixed r = itofix(s);
//   printf("%f %d %d %d %f\n", fixtof(in), t, u, s, fixtof(s));
   return r; 
}      

void fire_enemy_bulleta(int EN, int bullet_ans, int p)  
{
   extern int e_bullet_active[50], e_bullet_shape[50];
   extern fixed e_bullet_fx[50], e_bullet_fy[50], e_bullet_fxinc[50], e_bullet_fyinc[50];
   fixed xlen = players[p].PX - Efi[EN][0];   // get the x distance between enemy and player
   fixed ylen = players[p].PY - Efi[EN][1];   // get the y distance between enemy and player
   fixed hy_dist =  fixhypot(xlen, ylen);     // hypotenuse distance
   fixed speed = Efi[EN][7];                  // speed
   fixed scaler = fixdiv(hy_dist, speed);     // get scaler
   fixed xinc = fixdiv(xlen, scaler);        // calc xinc
   fixed yinc = fixdiv(ylen, scaler);        // calc yinc

   for (int z=0; z<50; z++)  // find empty e_bullet 
      if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_shape[z] = 1000 + bullet_ans;
         e_bullet_fx[z] = Efi[EN][0];
         e_bullet_fy[z] = Efi[EN][1];
         e_bullet_fxinc[z] = xinc;
         e_bullet_fyinc[z] = yinc;

         int EXint = fixtoi(Efi[EN][0]);
         int EYint = fixtoi(Efi[EN][1]);

         switch (bullet_ans)
         {
            case 54: event(17, EXint, EYint, 0, 0, 0, 0); break; // green 
            case 55: event(18, EXint, EYint, 0, 0, 0, 0); break; // cannonball 
            case 20: event(19, EXint, EYint, 0, 0, 0, 0); break; // twirly 
         }
         z=50;
      }
}

void fire_enemy_x_bullet(int EN, int p)
{
   extern int e_bullet_active[50], e_bullet_shape[50];
   extern fixed e_bullet_fx[50], e_bullet_fy[50], e_bullet_fxinc[50], e_bullet_fyinc[50];
   fixed x_bullet_speed = Efi[EN][7];
   for (int z=0; z<50; z++)  // find empty e_bullet 
      if (!e_bullet_active[z])
      {
         e_bullet_active[z] = 1;
         e_bullet_fyinc[z] = itofix(0);
         e_bullet_fx[z] = Efi[EN][0];
         e_bullet_fy[z] = Efi[EN][1];
         if (Efi[EN][0] < players[p].PX)
         {
            e_bullet_fxinc[z] = x_bullet_speed;
            e_bullet_shape[z] = 488;
         }
         if (Efi[EN][0] >= players[p].PX)
         {
            e_bullet_fxinc[z] = -x_bullet_speed;
            e_bullet_shape[z] = 489;
         }
         event(16, fixtoi(Efi[EN][0]), fixtoi(Efi[EN][1]), 0, 0, 0, 0);
         z=50; // end loop 
      }
}

// returns 1 for solid block, 2 for semi-solid, or 32+lift_num for lift
int is_right_solid(int solid_x, int solid_y, int lift_check)
{
   int a, b, c, d;
   int xx = solid_x / 20 + 1;
   int yy = solid_y / 20;
   int cc = solid_y / 20 + 1;
   a = solid_y % 20;

   if (lift_check)
      for (d = 0; d<num_lifts; d++)

         if (solid_y > lifts[d].y1 - 18)
            if (solid_y < lifts[d].y2 - 2)
               if (solid_x < lifts[d].x1 - 8)
                  if (solid_x > lifts[d].x1 - 18)
                     return 32+d;
   
   if (a > 16)  // next block only 
   {
      c = l[xx][cc];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   if (a < 3)    // this block only 
   {
      c = l[xx][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   if ((a > 2) && (a < 17)) // dual compare with ||  
   {
      b = l[xx][yy];
      c = l[xx][cc];
      if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) return 1;
      if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) return 2;
   }
   return 0;
}




// returns 1 for solid block, 2 for semi-solid, or 32+lift_num for lift
int is_left_solid(int solid_x, int solid_y, int lift_check)
{
   int a, b, c, d;
   int xx = solid_x / 20;
   int yy = solid_y / 20;
   int cc = solid_y / 20 + 1;
   a = solid_y % 20;
   if (lift_check)
      for (d = 0; d<num_lifts; d++)
         if (solid_y > lifts[d].y1 - 18)
            if (solid_y < lifts[d].y2 - 2)
               if (solid_x < lifts[d].x2 + 2)
                  if (solid_x > lifts[d].x2 - 8)
                     return 32+d;
   
   if (a > 16)  // next block only 
   {
      c = l[xx][cc];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   if (a < 3)    // this block only 
   {
      c = l[xx][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   if ((a > 2) && (a < 17)) // dual compare with ||  
   {
      b = l[xx][yy];
      c = l[xx][cc];
      if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) return 1;
      if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) return 2;
   }
   return 0;
}


// returns 1 for solid block, 2 for semi-solid, or 32+lift_num for lift
int is_down_solid(int solid_x, int solid_y, int lift_check)
{
   int a, b, c, d;
   int yy = solid_y / 20 + 1;
   int cc = solid_x / 20;
   int xx = solid_x / 20 + 1;
   a = solid_x % 20;
   if (lift_check)
      for (d = 0; d<num_lifts; d++)  
            if (solid_x > lifts[d].x1-18)
               if (solid_x < lifts[d].x2-2)
                  if (solid_y > lifts[d].y1 - 25)
                     if (solid_y < lifts[d].y1 - 10)
                         return d+32;

   if (a > 16)  // next block only 
   {
      c = l[xx][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   if (a < 3)    // this block only 
   {
      c = l[cc][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   if ((a > 2) && (a <17)) // dual compare with ||  
   {
      b = l[xx][yy];
      c = l[cc][yy];
      if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) return 1;
      if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) return 2;
   }

   return 0;
}

// returns 1 for solid block, 2 for semi-solid, or 32+lift_num for lift
int is_up_solid(int solid_x, int solid_y, int lift_check)
{
   int yy = (solid_y - 2) / 20;
   int cc = solid_x / 20;
   int xx = solid_x / 20 + 1;
   int a = solid_x % 20;

   if (lift_check)
      for (int d = 0; d<num_lifts; d++)
         if (solid_x > lifts[d].x1 - 18)
            if (solid_x < lifts[d].x2 - 2)
               if (solid_y < lifts[d].y2 + 2)
                  if (solid_y > lifts[d].y2 - 10)
                     return d+32;
   
   if (a > 16)  // next block only 
   {
      int c = l[xx][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   if (a < 3)    // this block only 
   {
      int c = l[cc][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   if ((a > 2) && (a < 17))// dual compare with ||  
   {
      int b = l[cc][yy];
      int c = l[xx][yy];
      if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) return 1;
      if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) return 2;
   }
   return 0;
}





/*

These 4 functions:

fixed is_up_solidfm(fixed fx, fixed fy, fixed fmove, int dir)
fixed is_down_solidfm(fixed fx, fixed fy, fixed fmove, int dir)
fixed is_left_solidfm(fixed fx, fixed fy, fixed fmove, int dir)
fixed is_right_solidfm(fixed fx, fixed fy, fixed fmove, int dir)

are used with trakbot only (for now).

They are more accurate than the other ones, they work to the exact pixel.
This was needed when trakbot clings to walls, ceilings and floors,
and need to navigate single block openings.

It is possible to exactly adjacent to a solid, and not trigger a solid.

These checks have some new parameters:
'fixed fmove' - is the distance of the requested move
we want to know if we can move that far
the functions returns 'fixed allowed_move' - how far before the condition is met.

it is assumed that what ever calls the functions will add fmove to position (fx or fy) on return
by comparing requested move to allowed move you can tell if a collision occured:

mv = is_down_solidfm(Efi[EN][0], Efi[EN][1], Efi[EN][2], 1);
if (mv < Efi[EN][2]) // allowed move less than requested move

'int dir' - the direction to look and the type of thing we are checking for

if dir == 0, we are looking in the direction of the named function for the next solid  

for example:
is_down_solidfm(fx, fy, fmove, 0)
looks down from fy, fmove amount for a solid
if none is found, the full fmove is returned
if solid is found, fmove is adjusted to make the move line up with solid

if (dir == 1 or -1) we are looking at a right angle from the named function 
for the next empty

for example:
is_down_solidfm(fx, fy, fmove, 1) 
looks right (+1 in x dir) from fx for the next empty below   
if none is found, the full fmove is returned
if empty is found, fmove is adjusted to make the move line up to the next empty

is_down_solidfm(fx, fy, fmove, -1)
looks left (-1 in x dir) from fx for the next empty below   
if none is found, the full fmove is returned
if empty is found, fmove is adjusted to make the move line up to the next empty

if you just want to know if the floor below you is solid:
is_down_solidfm(fx, fy, itofix(1), 0)

also they completely ignore lifts


*/

fixed is_up_solidfm(fixed fx, fixed fy, fixed fmove, int dir)
{
   int ix = fixtoi(fx);
   int iy = fixtoi(fy);
   int im = fixtoi(fmove);
   int move = 0;   
   for (int t=0; t<=im; t++) 
   {
      int j = 0, a, b=0, c=0, ret = 0, xx, yy, cc;
      if (dir == 0) yy = (iy-t-1) / 20; 
      else 
      {
         yy = (iy-1) / 20;
         j = dir * t;
      } 
      cc = (ix+j) / 20;
      xx = (ix+j) / 20 + 1;
      a = (ix+j) % 20;

      if (a == 0)    // this block only 
      {
         c = l[cc][yy];
         if      ((c > 63) && (c < NUM_SPRITES)) ret = 1;
         else if ((c > 31) && (c < NUM_SPRITES)) ret = 2;
      }
      else // dual compare with ||  
      {
         b = l[xx][yy];
         c = l[cc][yy];
         if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) ret = 1;
         else if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) ret = 2;
      }
      if (dir == 0) // solid mode - look up for next solid
      {
         if (ret) // as soon as solid is found, return
         {
             int fp = iy - move;             // next solid pos 
             fixed dist = fy - itofix(fp);   // distance from initial pos
             if (dist > fmove) dist = fmove; // limit to requested if over 
             return dist; 
         } 
         else move++;  
      }   
      else // empty mode - look left or right for next empty
      {
         if (ret == 0) // as soon as an empty is found, return
         {
            if (dir == 1) // look right
            {
                int fp = ix + move;             // next empty pos 
                fixed dist = itofix(fp) - fx;   // distance from initial pos
                if (dist > fmove) dist = fmove; // limit to requested if over 
                return dist; 
             }   
            if (dir == -1) // look left
            {
                int fp = ix - move;             // next empty pos 
                fixed dist = fx - itofix(fp);   // distance from initial pos
                if (dist > fmove) dist = fmove; // limit to requested if over 
                return dist; 
             }   
         }   
         else move++;  
      }   
   }   
   // finished the loop with finding either case;
   return fmove; // max move allowed
}

fixed is_down_solidfm(fixed fx, fixed fy, fixed fmove, int dir)
{
   int ix = fixtoi(fx);
   int iy = fixtoi(fy);
   int im = fixtoi(fmove);
   int move = 0;   
   for (int t=0; t<=im; t++) 
   {
      int j = 0, a, b=0, c=0, ret = 0, xx, yy, cc;
      if (dir == 0) yy = (iy + t) / 20 + 1;
      else 
      {
         yy = iy / 20 + 1;
         j = dir * t;
      } 
      cc = (ix+j) / 20;
      xx = (ix+j) / 20 + 1;
      a = (ix+j) % 20;
      if (a == 0)    // this block only 
      {
         c = l[cc][yy];
         if      ((c > 63) && (c < NUM_SPRITES)) ret = 1;
         else if ((c > 31) && (c < NUM_SPRITES)) ret = 2;
      }
      else // dual compare with ||  
      {
         b = l[xx][yy];
         c = l[cc][yy];
         if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) ret = 1;
         else if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) ret = 2;
      }
      if (dir == 0) // solid mode - looks down for next solid
      {
         if (ret) // as soon as solid is found, return
         {
             int fp = iy + move;             // next solid pos 
             fixed dist = itofix(fp) - fy;   // distance from initial pos
             if (dist > fmove) dist = fmove; // limit to requested if over 
             return dist; 
         } 
         else move++;  
      }   
      else // empty mode - look left or right for next empty
      {
         if (ret == 0) // as soon as an empty is found, return
         {
            if (dir == 1) // look right
            {
                int fp = ix + move;             // next empty pos 
                fixed dist = itofix(fp) - fx;   // distance from initial pos
                if (dist > fmove) dist = fmove; // limit to requested if over 
                return dist; 
             }   
            if (dir == -1) // look left
            {
                int fp = ix - move;             // next empty pos 
                fixed dist = fx - itofix(fp);   // distance from initial pos
                if (dist > fmove) dist = fmove; // limit to requested if over 
                return dist; 
             }   
         }   
         else move++;  
      }   
   }   
   // finished the loop with finding either case;
   return fmove; // max move allowed
}


fixed is_left_solidfm(fixed fx, fixed fy, fixed fmove, int dir)
{
   int ix = fixtoi(fx);
   int iy = fixtoi(fy);
   int im = fixtoi(fmove);
   int move = 0;   
   for (int t=0; t<=im; t++) 
   {
      int j = 0, a, b=0, c=0, ret = 0, xx, yy, cc;
      if (dir == 0) xx = (ix-t-1) / 20; 
      else 
      {
         xx = (ix-1) / 20;
         j = dir * t;
      } 
      yy = (iy+j) / 20;
      cc = (iy+j) / 20 + 1;
      a = (iy+j) % 20;
      if (a == 0)    // this block only 
      {
         c = l[xx][yy];
         if      ((c > 63) && (c < NUM_SPRITES)) ret = 1;
         else if ((c > 31) && (c < NUM_SPRITES)) ret = 2;
      }
      else // dual compare with ||  
      {
         b = l[xx][yy];
         c = l[xx][cc];
         if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) ret = 1;
         else if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) ret = 2;
      }

      if (dir == 0) // solid mode - looks left for next solid
      {
         if (ret) // as soon as solid is found, return
         {
             int fp = ix - move;             // next solid pos 
             fixed dist = fx - itofix(fp);   // distance from initial pos
             if (dist > fmove) dist = fmove; // limit to requested if over 
             return dist; 
         } 
         else move++;  
      }   
      else // empty mode - look up or down for next empty
      {
         if (ret == 0) // as soon as an empty is found, return
         {
            if (dir == 1) // look down
            {
                int fp = iy + move;             // next empty pos 
                fixed dist = itofix(fp) - fy;   // distance from initial pos
                if (dist > fmove) dist = fmove; // limit to requested if over 
                return dist; 
             }   
            if (dir == -1) // look up
            {
                int fp = iy - move;             // next empty pos 
                fixed dist = fy - itofix(fp);   // distance from initial pos
                if (dist > fmove) dist = fmove; // limit to requested if over 
                return dist; 
             }   
         }   
         else move++;  
      }   
   }   
   // finished the loop with finding either case;
   return fmove; // max move allowed
}


fixed is_right_solidfm(fixed fx, fixed fy, fixed fmove, int dir)
{
   int ix = fixtoi(fx);
   int iy = fixtoi(fy);
   int im = fixtoi(fmove);
   int move = 0;   
   for (int t=0; t<=im; t++) 
   {
      int j = 0, a, b=0, c=0, ret = 0, xx, yy, cc;
      if (dir == 0) xx = (ix + t) / 20 + 1; 
      else 
      {
         xx = (ix) / 20 + 1;
         j = dir * t;
      } 
      yy = (iy+j) / 20;
      cc = (iy+j) / 20 + 1;

      a = (iy+j) % 20;

      if (a == 0)    // this block only 
      {
         c = l[xx][yy];
         if      ((c > 63) && (c < NUM_SPRITES)) ret = 1;
         else if ((c > 31) && (c < NUM_SPRITES)) ret = 2;
      }
      else // dual compare with ||  
      {
         b = l[xx][yy];
         c = l[xx][cc];
         if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) ret = 1;
         else if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) ret = 2;
      }
      if (dir == 0) // solid mode - looks right for next solid
      {
         if (ret) // as soon as solid is found, return
         {
             int fp = ix + move;             // next solid pos 
             fixed dist = itofix(fp) - fx;   // distance from initial pos
             if (dist > fmove) dist = fmove; // limit to requested if over 
             return dist; 
         } 
         else move++;  
      }   
      else // empty mode - look up or down for next empty
      {
         if (ret == 0) // as soon as an empty is found, return
         {
            if (dir == 1) // look down
            {
                int fp = iy + move;             // next empty pos 
                fixed dist = itofix(fp) - fy;   // distance from initial pos
                if (dist > fmove) dist = fmove; // limit to requested if over 
                return dist; 
             }   
            if (dir == -1) // look up
            {
                int fp = iy - move;             // next empty pos 
                fixed dist = fy - itofix(fp);   // distance from initial pos
                if (dist > fmove) dist = fmove; // limit to requested if over 
                return dist; 
             }   
         }   
         else move++;  
      }   
   }   
   // finished the loop with finding either case;
   return fmove; // max move allowed
}














/*













// these functione are not used, they were built when testing solutions to the trakbot problem
int is_down_solidf(fixed x, fixed y, int lift_check)
{
   int a, b=0, c=0, ret = 0;
   int yy = (fixtoi(y)-1) / 20 + 1;
   int cc = fixtoi(x) / 20;
   int xx = fixtoi(x) / 20 + 1;
   a = fixtoi(x) % 20;
   if (a == 0)    // this block only 
   {
      c = l[cc][yy];
      if ((c > 63) && (c < NUM_SPRITES))
      {
         ret = 1;
      }
      else if ((c > 31) && (c < NUM_SPRITES))
      {
         ret = 2;
      }   
   }
   else // dual compare with ||  
   {
      b = l[xx][yy];
      c = l[cc][yy];
      if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) )
      {
         ret = 1;
      }   
      else if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) )
      {
         ret = 2;
      }
   }
   return ret;
}
int is_up_solidf(fixed x, fixed y, int lift_check)
{
   int a, b, c;
   
   int yy = fixtoi(y) / 20;
   int cc = fixtoi(x) / 20;
   int xx = fixtoi(x) / 20 + 1;
   a = fixtoi(x) % 20;
   if (a == 0)    // this block only 
   {
      c = l[cc][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   else // dual compare with ||  
   {
      b = l[xx][yy];
      c = l[cc][yy];
      if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) return 1;
      if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) return 2;
   }
   return 0;
}
int is_right_solidf(fixed x, fixed y, int lift_check)
{
   int a, b, c;

   int xx = (fixtoi(x)-1) / 20 + 1;
   int yy = fixtoi(y) / 20;
   int cc = fixtoi(y) / 20 + 1;
   a = fixtoi(y) % 20;
   if (a == 0)    // this block only 
   {
      c = l[xx][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   else // dual compare with ||  
   {
      b = l[xx][yy];
      c = l[xx][cc];
      if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) return 1;
      if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) return 2;
   }
   return 0;
}
int is_left_solidf(fixed x, fixed y, int lift_check)
{
   int a, b, c;

   int xx = fixtoi(x) / 20;
   int yy = fixtoi(y) / 20;
   int cc = fixtoi(y) / 20 + 1;
   a = fixtoi(y) % 20;
   if (a == 0)    // this block only 
   {
      c = l[xx][yy];
      if ((c > 63) && (c < NUM_SPRITES)) return 1;
      if ((c > 31) && (c < NUM_SPRITES)) return 2;
   }
   else // dual compare with ||  
   {
      b = l[xx][yy];
      c = l[xx][cc];
      if ( ((b > 63) && (b < NUM_SPRITES)) || ((c > 63) && (c < NUM_SPRITES)) ) return 1;
      if ( ((b > 31) && (b < NUM_SPRITES)) || ((c > 31) && (c < NUM_SPRITES)) ) return 2;
   }
   return 0;
}





void proc_frame_delay(void);
extern int speed;
void set_speed(void);



// test solid functions

void solid_test(void)
{
   load_level(316, 0);
   int quit = 0;
   speed = 5;
   set_speed();
   players[0].PX = itofix(1000); 
   players[0].PY = itofix(1000); 
   while (!quit)
   {  
      proc_controllers();       



*/



/*
// original solid functions
      if (players[0].up)
      {
         players[0].PY -= itofix(1); 
         if (is_up_solid(fixtoi(players[0].PX), fixtoi(players[0].PY), 0)) players[0].PY += itofix(1); 
      }         
      if (players[0].down)
      {
         players[0].PY += itofix(1); 
         if (is_down_solid(fixtoi(players[0].PX), fixtoi(players[0].PY), 0)) players[0].PY -= itofix(1); 
      }      
      if (players[0].right)
      {
         players[0].PX += itofix(1); 
         if (is_right_solid(fixtoi(players[0].PX), fixtoi(players[0].PY), 0)) players[0].PX -= itofix(1); 
      }      
      if (players[0].left)
      {
         players[0].PX -= itofix(1); 
         if (is_left_solid(fixtoi(players[0].PX), fixtoi(players[0].PY), 0)) players[0].PX += itofix(1); 
      }      

*/
// new solid functions
/*
      if (players[0].up)
      {
         players[0].PY -= itofix(1); 
         if (is_up_solidf(players[0].PX, players[0].PY, 0)) players[0].PY += itofix(1); 
      }         
      if (players[0].down)
      {
         players[0].PY += itofix(1); 
         if (is_down_solidf(players[0].PX, players[0].PY, 0)) players[0].PY -= itofix(1); 
      }      
      if (players[0].right)
      {
         players[0].PX += itofix(1); 
         if (is_right_solidf(players[0].PX, players[0].PY, 0)) players[0].PX -= itofix(1); 
      }      
      if (players[0].left)
      {
         players[0].PX -= itofix(1); 
         if (is_left_solidf(players[0].PX, players[0].PY, 0)) players[0].PX += itofix(1); 
      }      


*/



/*

// new solid functions with move

      fixed mv = ftofix(2.2); 

      if (players[0].up)
      {
         players[0].PY -= is_up_solidfm(players[0].PX, players[0].PY, mv, 0);
      }         
      if (players[0].down)
      {
         players[0].PY += is_down_solidfm(players[0].PX, players[0].PY, mv, 0);
      }      
      if (players[0].left)
      {
         players[0].PX -= is_left_solidfm(players[0].PX, players[0].PY, mv, 0);
      }      
      if (players[0].right)
      {
         players[0].PX += is_right_solidfm(players[0].PX, players[0].PY, mv, 0);
      }      

      rest(10);

      proc_frame_delay();
      get_new_background();     
      draw_players();         

      rect(level_buffer, fixtoi(players[0].PX), fixtoi(players[0].PY), fixtoi(players[0].PX)+19, fixtoi(players[0].PY)+19, palette_color[10]);

      get_new_screen_buffer();
      blit_buffer_to_screen(); 
      if (key[KEY_ESC]) quit = 1;
   } // end of while (!quit)
}

*/








// my version of spline with thickness
void mspline(BITMAP *b, int *par, int col, int thickness)
{
   int draw_points[8];
   int t = thickness - 1;
   for (int a=-t; a<=t; a++)
      for (int c=-t; c<=t; c++)
      {  
         for (int i=0; i<8; i+=2)
         {
            draw_points[i]   = par[i]   + a;
            draw_points[i+1] = par[i+1] + c;
         }
         spline(b, draw_points, palette_color[col]);


      }
//   int r = (int) ( (float)thickness * 1.6);
   int r = (int) ( (float)thickness * 1.3);

   circlefill(b, par[0], par[1], r, palette_color[col]);
   circlefill(b, par[0], par[1], thickness+0, palette_color[0]);
   circlefill(b, par[0], par[1], thickness, palette_color[col]);

   circlefill(b, par[6], par[7], r, palette_color[col]);
   circlefill(b, par[6], par[7], thickness+0, palette_color[0]);
   circlefill(b, par[6], par[7], thickness, palette_color[col]);


}

// my version of spline with thickness and fading
void mfspline(BITMAP *b, int *par, int col, int thickness)
{
//   color_cycle = 

   // th = 2  cc = 128
   // th = 4  cc = 64
   // th = 8  cc = 32
   // th = 16 cc = 16

// 16 32 48 64 80 96 112 128


   if (thickness == 2)
   {
      for (int a = thickness; a>0; a--)
      {
         if (col == 8)
         {
            if (a==2) mspline(b, par, 12, a);
            if (a==1) mspline(b, par, 8, a);
         }  
         if (col == 10)
         {
            if (a==2) mspline(b, par, 8, a);
            if (a==1) mspline(b, par, 12, a);
         }  


      }
   }

   else if (thickness == 3)
   {
      for (int a = thickness; a>0; a--)
      {
         if (col == 8)
         {
            if (a==3) mspline(b, par, 12, a);
            if (a==2) mspline(b, par, 0, a);
            if (a==1) mspline(b, par, 10, a);
         }  
         if (col == 10)
         {
            if (a==3) mspline(b, par, 10, a);
            if (a==2) mspline(b, par, 0, a);
            if (a==1) mspline(b, par, 12, a);
         }  


      }
   }

   else if (thickness == 4)
   {
      for (int a = thickness; a>0; a--)
      {
         if (col == 8)
         {
            if (a==4) mspline(b, par, 12, a);
            if (a==3) mspline(b, par, 12, a);
            if (a==2) mspline(b, par, 10, a);
            if (a==1) mspline(b, par, 10, a);
         }  
         if (col == 10)
         {
            if (a==4) mspline(b, par, 10, a);
            if (a==3) mspline(b, par, 10, a);
            if (a==2) mspline(b, par, 12, a);
            if (a==1) mspline(b, par, 12, a);
         }  


      }
   }


   else if (thickness == 5)
   {
      for (int a = thickness; a>0; a--)
      {

         // this looks good 
/*         if (a==5) mspline(b, par, 8, a);
         if (a==4) mspline(b, par, 12, a);
         if (a==3) mspline(b, par, 0, a);
         if (a==2) mspline(b, par, 12, a);
         if (a==1) mspline(b, par, 10, a);
*/

         if (a==5) mspline(b, par, 10, a);
         if (a==4) mspline(b, par, 12, a);
         if (a==3) mspline(b, par, 0, a);
         if (a==2) mspline(b, par, 12, a);
         if (a==1) mspline(b, par, 10, a);




      }
   }
   else
   {
      for (int a = thickness; a>0; a--)
          mspline(b, par, col+(thickness-a)*64, a);
   }

}


void draw_mdw(BITMAP *b, int x, int y, float x_scale, float y_scale, int line_thickness)
{
   int t = line_thickness;
   int draw_points[10][8];

   // apply x_scale
   for (int j=0; j<10; j++)   
      for (int i=0; i<8; i+=2)
      {   
         draw_points[j][i] = (int) ( (float) points[j][i] * x_scale);
         draw_points[j][i+1] = (int) ( (float) points[j][i+1] * y_scale);
      }

   // apply offset
   for (int j=0; j<10; j++)   
      for (int i=0; i<8; i+=2)
      {
         draw_points[j][i] += x;
         draw_points[j][i+1] += y;
      }

   //mark the center
   //circle(b, x, y, 4, palette_color[8]);

   // drawing order
   int order = 0; // normal with arms in front  
   if (x_scale < 0) order = !order;
   if (y_scale < 0) order = !order;


   if (order)
   {
      mfspline(b, draw_points[4], 10, t);
      mfspline(b, draw_points[2], 10, t);
      mfspline(b, draw_points[3], 10, t);
      mfspline(b, draw_points[8], 10, t);
      mfspline(b, draw_points[9], 10, t);
      mfspline(b, draw_points[0], 8, t);
      mfspline(b, draw_points[1], 8, t);
      mfspline(b, draw_points[6], 8, t);
      mfspline(b, draw_points[7], 8, t);
   }
   else
   {
      mfspline(b, draw_points[0], 8, t);
      mfspline(b, draw_points[1], 8, t);
      mfspline(b, draw_points[6], 8, t);
      mfspline(b, draw_points[7], 8, t);
      mfspline(b, draw_points[4], 10, t);
      mfspline(b, draw_points[2], 10, t);
      mfspline(b, draw_points[3], 10, t);
      mfspline(b, draw_points[8], 10, t);
      mfspline(b, draw_points[9], 10, t);
   }

   // show the rest of the name

   void mtextout(BITMAP *dbmp, char *txt1, int x, int y, float x_scale, float y_scale, int col);

   sprintf(msg, "ichael");
   mtextout(b, msg, (int)(x - 50 * x_scale), (int)(y - 130 * y_scale), x_scale*2, y_scale*3, 12);

   sprintf(msg, "avid");
   mtextout(b, msg, (int)(x + 90 * x_scale), (int)(y -15 * y_scale), x_scale*2, y_scale*3, 8);

   sprintf(msg, "eiss");
   mtextout(b, msg, (int)(x + 150 * x_scale), (int)(y + 120 * y_scale), x_scale*2, y_scale*3, 12);
}









// 0 1 are the outer parts of M
// 2 3 are the inner parts of M
// 4 D
// 5 rsvd (not used)
// 6 7 outer W
// 8 9 inner W

// 0 is copied to 1 6 7 
// 2 is copied to 3 8 9 

// the height and width of M and W are 200

// they meet at the lower right corner of M and the upper left corner of W
// that spot is the origin 0, 0
// this makes scaling easy as I can mutlipy all the values by the same scaler



void seed_mdw(void)
{
   // outer arms start and end pos are all fixed
   points[0][0] = -200;
   points[0][1] = 0;
   points[0][6] = -200;
   points[0][7] = -200;

   points[1][0] = 0;
   points[1][1] = 0;
   points[1][6] = 0;
   points[1][7] = -200;

   points[6][0] = 0;
   points[6][1] = 0;
   points[6][6] = 0;
   points[6][7] = 200;

   points[7][0] = 200;
   points[7][1] = 0;
   points[7][6] = 200;
   points[7][7] = 200;
   
   // outer arm 0 control points are relative to outer arm 0 positon
   points[0][2] = points[0][6] + 85;
   points[0][3] = points[0][7] + 107;
   points[0][4] = points[0][6] + 95;
   points[0][5] = points[0][7] + 31;

   // inner arm is relative to outer arm
   points[2][0] = points[0][6] + 30;
   points[2][1] = points[0][7] + 30;
   points[2][2] = points[0][6] + 77;
   points[2][3] = points[0][7] + 32;
   points[2][4] = points[0][6] + 93;
   points[2][5] = points[0][7] + 53;
   points[2][6] = points[0][6] + 109;
   points[2][7] = points[0][7] + 69;

/*
   points[0][2] = points[0][6] + 72;
   points[0][3] = points[0][7] + 115;
   points[0][4] = points[0][6] + 95;
   points[0][5] = points[0][7] + 31;

   points[2][0] = points[0][6] + 30;
   points[2][1] = points[0][7] + 30;
   points[2][2] = points[0][6] + 77;
   points[2][3] = points[0][7] + 32;
   points[2][4] = points[0][6] + 93;
   points[2][5] = points[0][7] + 53;
   points[2][6] = points[0][6] + 103;
   points[2][7] = points[0][7] + 88;

*/

   // 'D' has only 1 spline, start point and first control point are mirrored in the y axis
   points[4][0] = -70;
   points[4][1] = -40;
   points[4][2] = 132;
   points[4][3] = -88;
}

void fill_mdw(void)
{
   // get control point 1 from spline 0
   int cp1x = points[0][0] - points[0][2];
   int cp1y = points[0][1] - points[0][3];

   // get control point 2 from spline 0
   int cp2x = points[0][0] - points[0][4];
   int cp2y = points[0][1] - points[0][5];

   // apply to other splines
   points[1][2] = points[1][0] + cp1x;
   points[1][3] = points[1][1] - cp1y;
   points[1][4] = points[1][0] + cp2x;
   points[1][5] = points[1][1] - cp2y;

   points[6][2] = points[6][0] - cp1x;
   points[6][3] = points[6][1] + cp1y;
   points[6][4] = points[6][0] - cp2x;
   points[6][5] = points[6][1] + cp2y;

   points[7][2] = points[7][0] + cp1x;
   points[7][3] = points[7][1] + cp1y;
   points[7][4] = points[7][0] + cp2x;
   points[7][5] = points[7][1] + cp2y;

   // these are the 4 inner arms and their positions are relative to the outer arms (or center?)

   // get inner arm offsets from outer arm 
   int ia1x = points[0][0] - points[2][0]; // inner arm x1
   int ia1y = points[0][1] - points[2][1]; // inner arm y1
   int ia2x = points[0][0] - points[2][6]; // inner arm x2
   int ia2y = points[0][1] - points[2][7]; // inner arm y2

   // get inner arm control points
   cp1x = points[2][0] - points[2][2]; // inner arm x1
   cp1y = points[2][1] - points[2][3]; // inner arm y1
   cp2x = points[2][0] - points[2][4]; // inner arm x2
   cp2y = points[2][1] - points[2][5]; // inner arm y2


   // apply to other inner arms
   points[3][0] = points[1][0] + ia1x;
   points[3][1] = points[1][1] - ia1y;
   points[3][6] = points[1][0] + ia2x;
   points[3][7] = points[1][1] - ia2y;

   points[3][2] = points[3][0] + cp1x;
   points[3][3] = points[3][1] - cp1y;
   points[3][4] = points[3][0] + cp2x;
   points[3][5] = points[3][1] - cp2y;

   points[8][0] = points[6][0] - ia1x;
   points[8][1] = points[6][1] + ia1y;
   points[8][6] = points[6][0] - ia2x;
   points[8][7] = points[6][1] + ia2y;

   points[8][2] = points[8][0] - cp1x;
   points[8][3] = points[8][1] + cp1y;
   points[8][4] = points[8][0] - cp2x;
   points[8][5] = points[8][1] + cp2y;

   points[9][0] = points[7][0] + ia1x;
   points[9][1] = points[7][1] + ia1y;
   points[9][6] = points[7][0] + ia2x;
   points[9][7] = points[7][1] + ia2y;

   points[9][2] = points[9][0] + cp1x;
   points[9][3] = points[9][1] + cp1y;
   points[9][4] = points[9][0] + cp2x;
   points[9][5] = points[9][1] + cp2y;

   // d adjust
   points[4][6] = points[4][0]; // same x
   points[4][7] = -points[4][1]; // mirror y
   points[4][4] = points[4][2]; // same x
   points[4][5] = -points[4][3]; // mirror y
}



void mdw_an3(BITMAP *b, int x, int y, float sc, int th)
{
   float mdw_help_logo_scale = sc;

   float x_scale = mdw_help_logo_scale;
   float y_scale = mdw_help_logo_scale;

   // how many seq?

   // 1st static 128  0    - 127
   // y rot 256       128  - 383
   // 2nd static 128  384  - 511
   // x rot 192       512  - 703
   // xy rot 256      704  - 959
   // xlink 64        960  - 1023
   // total 1024

   if (++mdw_an_seq > 1023) mdw_an_seq = 0;
   fixed t;

   // 1st static
   if (mdw_an_seq < 128)
   {
      x_scale = mdw_help_logo_scale;
      y_scale = mdw_help_logo_scale;
   }
   // y rot
   if ((mdw_an_seq > 127) && (mdw_an_seq < 384))
   {
      t = itofix(mdw_an_seq - 128);
      y_scale = mdw_help_logo_scale * fixtof(fixcos(t));  
   }
   // 2nd static
   if ((mdw_an_seq > 383) && (mdw_an_seq < 512))
   {
      x_scale = mdw_help_logo_scale;
      y_scale = mdw_help_logo_scale;
   }
   // x rot
   if ((mdw_an_seq > 511) && (mdw_an_seq < 704))
   {
      t = itofix(mdw_an_seq - 512);
      x_scale = mdw_help_logo_scale * fixtof(fixcos(t));  
   }
   // xy rot
   if ((mdw_an_seq > 703) && (mdw_an_seq < 960))
   {
      t = itofix(mdw_an_seq - 704);
      x_scale = mdw_help_logo_scale * fixtof(fixsin(t));  
      y_scale = mdw_help_logo_scale * fixtof(fixcos(t));  
   }
   // x link
   if ((mdw_an_seq > 959) && (mdw_an_seq < 1024))
   {
      t = itofix(mdw_an_seq - 960);
      x_scale = mdw_help_logo_scale * fixtof(fixsin(t));  
   }
   draw_mdw(b, x, y, x_scale, y_scale, th);
}


int mdw_an2(void)
{
   float x_scale = mdw_splash_logo_scale;
   float y_scale = mdw_splash_logo_scale;

   // 1st grow while rotating 256   0    - 255
   // 2nd xlink                64   256  - 319
   // 3nd static              128   320  - 447
   // 4th spin back for dual  192   448  - 639
   // 5th dual flip           256   640  - 895
   // 6th spin back to orig    64   896  - 959
   // total shrink frames 320 (mode 5 and 6)

   if (++mdw_an_seq > 959) return 1;

   // grow and spin in both axis
   if ((mdw_an_seq > -1) && (mdw_an_seq < 256))
   {
      fixed t = itofix(mdw_an_seq);
      float s = (float)mdw_an_seq / 320; 
      if (s > 1) s = 1; 
      x_scale = s * mdw_splash_logo_scale * fixtof(fixsin(t));  
      y_scale = s * mdw_splash_logo_scale * fixtof(fixcos(t));  
   }
   // fix x scale
   if ((mdw_an_seq > 255) && (mdw_an_seq < 319))
   {
      fixed t = itofix(mdw_an_seq-256);
      float s = (float)mdw_an_seq / 320; 
      if (s > 1) s = 1; 
      x_scale = s * mdw_splash_logo_scale * fixtof(fixsin(t));  
      y_scale = s * mdw_splash_logo_scale;  
   }
   // freeze
   if ((mdw_an_seq > 319) && (mdw_an_seq < 448))
   {
      x_scale = mdw_splash_logo_scale;  
      y_scale = mdw_splash_logo_scale;  
   }
   // spin back to prepare for dual flip...
   if ((mdw_an_seq > 447) && (mdw_an_seq < 640))
   {
      fixed t = itofix(mdw_an_seq-448);
      x_scale = mdw_splash_logo_scale * fixtof(fixcos(t));  
   }
   // shrink and move
   if ((mdw_an_seq > 639) && (mdw_an_seq < 960))
   {
      mdw_splash_logo_x -= mdw_logo_x_dec; 
      mdw_splash_logo_y -= mdw_logo_y_dec; 
      mdw_splash_logo_scale -= mdw_logo_scale_dec;  
   }
   // dual flip
   if ((mdw_an_seq > 639) && (mdw_an_seq < 896))
   {
      fixed t = itofix(mdw_an_seq-640);
      x_scale = mdw_splash_logo_scale * fixtof(fixsin(t));  
      y_scale = mdw_splash_logo_scale * fixtof(fixcos(t));  
   }
   // back to original
   if ((mdw_an_seq > 895) && (mdw_an_seq < 960))
   {
      fixed t = itofix(mdw_an_seq-896);
      x_scale = mdw_splash_logo_scale * fixtof(fixsin(t));  
      y_scale = mdw_splash_logo_scale;  
   }
   draw_mdw(scrn_buffer, (int)mdw_splash_logo_x, (int)mdw_splash_logo_y, x_scale, y_scale, mdw_splash_logo_th);
   return 0;
}

void mdw_an(void)
{
   float x_scale = mdw_map_logo_scale;
   float y_scale = mdw_map_logo_scale;

   // how many seq?

   // 1st static 128  0    - 127
   // y rot 256       128  - 383
   // 2nd static 128  384  - 511
   // x rot 192       512  - 703
   // xy rot 256      704  - 959
   // xlink 64        960  - 1023
   // total 1024

   if (++mdw_an_seq > 1023) mdw_an_seq = 0;
   fixed t;

   // 1st static
   if (mdw_an_seq < 128)
   {
      x_scale = mdw_map_logo_scale;
      y_scale = mdw_map_logo_scale;
   }
   // y rot
   if ((mdw_an_seq > 127) && (mdw_an_seq < 384))
   {
      t = itofix(mdw_an_seq - 128);
      y_scale = mdw_map_logo_scale * fixtof(fixcos(t));  
   }
   // 2nd static
   if ((mdw_an_seq > 383) && (mdw_an_seq < 512))
   {
      x_scale = mdw_map_logo_scale;
      y_scale = mdw_map_logo_scale;
   }
   // x rot
   if ((mdw_an_seq > 511) && (mdw_an_seq < 704))
   {
      t = itofix(mdw_an_seq - 512);
      x_scale = mdw_map_logo_scale * fixtof(fixcos(t));  
   }
   // xy rot
   if ((mdw_an_seq > 703) && (mdw_an_seq < 960))
   {
      t = itofix(mdw_an_seq - 704);
      x_scale = mdw_map_logo_scale * fixtof(fixsin(t));  
      y_scale = mdw_map_logo_scale * fixtof(fixcos(t));  
   }
   // x link
   if ((mdw_an_seq > 959) && (mdw_an_seq < 1024))
   {
      t = itofix(mdw_an_seq - 960);
      x_scale = mdw_map_logo_scale * fixtof(fixsin(t));  
   }
   draw_mdw(scrn_buffer, mdw_map_logo_x, mdw_map_logo_y, x_scale, y_scale, mdw_map_logo_th);
}



















void spline_test(void)
{
   seed_mdw(); 
   fill_mdw();

   float x_scale = 1.0;
   float y_scale = 1.0;

   int quit = 0;
   while (!quit)
   {
      if (key[KEY_RIGHT])
      {
         while (key[KEY_RIGHT]);
         x_scale += .1; 
      }
      if (key[KEY_LEFT])
      {
         while (key[KEY_LEFT]);
         x_scale -= .1; 

      }
      if (key[KEY_UP])
      {
         while (key[KEY_UP]);
         y_scale += .1; 
      }
      if (key[KEY_DOWN])
      {
         while (key[KEY_DOWN]);
         y_scale -= .1; 
      }
      clear(scrn_buffer);
      draw_mdw(scrn_buffer, SCREEN_W/2, SCREEN_H/2, x_scale, y_scale, 2);
      blit(scrn_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
      rest(20);
      while ((key[KEY_ESC]) || (mouse_b & 2)) quit = 1;
   }
}

void redraw_spline(int s)
{
   fill_mdw();
   clear(scrn_buffer);
   draw_mdw(scrn_buffer, 200, 200, 1.0, 1.0, 1);
   textprintf_ex(scrn_buffer, font, 100, 402, 15, 0, "current spline:%d", s);
   for (int i=0; i<8; i+=2)
   {
      circle(scrn_buffer, points[s][i]+200, points[s][i+1]+200, 4, palette_color[11]);
      textprintf_ex(scrn_buffer, font, 100, 410+i*4, 15, 0, "x:%d y:%d", points[s][i], points[s][i+1] );
   }
}

void spline_adjust(void)
{
   int current_spline = 0;
   seed_mdw(); 
   fill_mdw();
   int quit = 0;
   while (!quit)
   {
      show_mouse(NULL);
      redraw_spline(current_spline);
      blit(scrn_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
      show_mouse(screen);
      rest(20);

      int mx = mouse_x-200;
      int my = mouse_y-200;
      for (int i=0; i<8; i+=2)
      {
         int px = points[current_spline][i];
         int py = points[current_spline][i+1];
         if ((mx > px-4) && (mx < px+4) && (my > py-4) && (my < py+4))
         {
            while (mouse_b & 1)
            {
               show_mouse(NULL);
               redraw_spline(current_spline);
               blit(scrn_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
               show_mouse(screen);
               rest(20);
               circle(scrn_buffer, points[current_spline][i]+200, points[current_spline][i+1]+200, 4, palette_color[10]);
               points[current_spline][i] = mouse_x-200;
               points[current_spline][i+1] = mouse_y-200;
            }
         }
      }

      if (key[KEY_UP])
      {
         while (key[KEY_UP]);
         if (current_spline == 0) current_spline = 2;
         else if (current_spline == 2) current_spline = 4;
      } 
      if (key[KEY_DOWN])
      {
         while (key[KEY_DOWN]);
         if (current_spline == 2) current_spline = 0;
         else if (current_spline == 4) current_spline = 2;
      } 
   while ((key[KEY_ESC]) || (mouse_b & 2)) quit = 1;
   }
}

















































































/*



void chunk(void)
{

   printf("\n\n  TEST CHUNK!!\n");

   // get all the data need for a frame state in one chunk and compress

   int offset = 0;
   int size;


   int ch_players = 1;
   int ch_Ei = 1;
   int ch_Efi = 1;
   int ch_item = 1;
   int ch_itemf = 1;
   int ch_lifts = 1;
   int ch_l = 1;

   printf("\nGet sizes\n");

   if (ch_players)
   {
      size = sizeof(players);
      printf("players \t\tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_Ei)
   {
      size = sizeof(Ei);
      printf("int Ei[100][32] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_Efi)
   {
      size = sizeof(Efi);
      printf("fixed Efi[100][16] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_item)
   {
      size = sizeof(item);
      printf("int item[500][16] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_itemf)
   {
      size = sizeof(itemf);
      printf("fixed item[500][4] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_lifts)
   {
      size = sizeof(lifts);
      printf("lifts \t\t\tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_l)
   {
      size = sizeof(l);
      printf("int l[100][100] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }


   size_t sz = offset;

   char buf[sz];
   char cmp[sz];
   char dec[sz];

   printf("\nPut in buffer\n");


   offset = 0;

   if (ch_players)
   {
      size = sizeof(players);
      memmove(buf+offset, players, size);
      printf("players \t\tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_Ei)
   {
      size = sizeof(Ei);
      memmove(buf+offset, Ei, size);
      printf("int Ei[100][32] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_Efi)
   {
      size = sizeof(Efi);
      memmove(buf+offset, Efi, size);
      printf("fixed Efi[100][16] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_item)
   {
      size = sizeof(item);
      memmove(buf+offset, item, size);
      printf("int item[500][16] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_itemf)
   {
      size = sizeof(itemf);
      memmove(buf+offset, itemf, size);
      printf("fixed item[500][4] \tsize %d \toffset %d \n", size, offset);
      offset += size;
   }
   if (ch_lifts)
   {
      size = sizeof(lifts);
      memmove(buf+offset, lifts, size);
      printf("lifts \t\t\tsize %d \toffset %d \n", size, offset);
      offset += size;
   }

   if (ch_l)
   {
      size = sizeof(l);
      memmove(buf+offset, l, size);
      printf("l[100][100] \t\tsize %d \toffset %d \n", size, offset);
      offset += size;
   }




   printf("\nTest buffer\n");

   offset = 0;
   if (ch_players)
   {
      size = sizeof(players);
      if (memcmp(players, buf+offset, size) == 0) printf("players and buf are the same\n");
      offset += size;
   }
   if (ch_Ei)
   {
      size = sizeof(Ei);
      if (memcmp(Ei, buf+offset, size) == 0) printf("Ei and buf are the same\n");
      offset += size;
   }
   if (ch_Efi)
   {
      size = sizeof(Efi);
      if (memcmp(Efi, buf+offset, size) == 0) printf("Efi and buf are the same\n");
      offset += size;
   }
   if (ch_item)
   {
      size = sizeof(item);
      if (memcmp(item, buf+offset, size) == 0) printf("item and buf are the same\n");
      offset += size;
   }
   if (ch_itemf)
   {
      size = sizeof(itemf);
      if (memcmp(itemf, buf+offset, size) == 0) printf("itemf and buf are the same\n");
      offset += size;
   }
   if (ch_lifts)
   {
      size = sizeof(lifts);
      if (memcmp(lifts, buf+offset, size) == 0) printf("lifts and buf are the same\n");
      offset += size;
   }
   if (ch_l)
   {
      size = sizeof(l);
      if (memcmp(l, buf+offset, size) == 0) printf("l and buf are the same\n");
      offset += size;
   }


   printf("\nCompress\n");


   for (int i=1; i<10; i++)
   {
      uLongf destLen= sizeof(cmp);
      compress2((Bytef*)cmp, (uLongf*)&destLen, (Bytef*)buf, sizeof(buf), i);
      int cp = destLen;
      printf("Compressed size is: %d\n", cp);
      printf("Ratio:%f (%d // %d)\n", (float)cp*100 / (float)sz, cp, sz);
   }


   printf("\nDecompress\n");

   uLongf destLen= sizeof(dec);
   uncompress((Bytef*)dec, (uLongf*)&destLen, (Bytef*)cmp, sizeof(cmp));
   int cp = destLen;
   printf("Uncompressed size is: %d\n", cp);

   if (memcmp(dec, buf, 105536) == 0) printf("dec and buf are the same\n");


}
*/





void state_to_chunk(char * b)
{
   int offset = 0;
   int size;

   size = sizeof(players);
   memmove(b+offset, players, size);
//      printf("players \tsize %d \toffset %d \n", size, offset);
   offset += size;
   size = sizeof(Ei);
   memmove(b+offset, Ei, size);
//      printf("int Ei[100][32] \tsize %d \toffset %d \n", size, offset);
   offset += size;
   size = sizeof(Efi);
   memmove(b+offset, Efi, size);
//    printf("fixed Efi[100][16] \tsize %d \toffset %d \n", size, offset);
   offset += size;
   size = sizeof(item);
   memmove(b+offset, item, size);
//    printf("int item[500][16] \tsize %d \toffset %d \n", size, offset);
   offset += size;
   size = sizeof(itemf);
   memmove(b+offset, itemf, size);
//    printf("fixed item[500][4] \tsize %d \toffset %d \n", size, offset);
   offset += size;
   size = sizeof(lifts);
   memmove(b+offset, lifts, size);
//      printf("lifts \t\t\tsize %d \toffset %d \n", size, offset);
   offset += size;
   size = sizeof(l);
   memmove(b+offset, l, size);
//    printf("l[100][100] \t\tsize %d \toffset %d \n", size, offset);
   offset += size;
//      printf("----------------total chunk size %d \n", offset);

}


void chnk_to_state(char * b)
{      
   int offset = 0;
   int size;

   size = sizeof(players);
   memcpy(players, b+offset, size);
   offset += size;

   size = sizeof(Ei);
   memcpy(Ei, b+offset, size);
   offset += size;

   size = sizeof(Efi);
   memcpy(Efi, b+offset, size);
   offset += size;

   size = sizeof(item);
   memcpy(item, b+offset, size);
   offset += size;

   size = sizeof(itemf);
   memcpy(itemf, b+offset, size);
   offset += size;

   size = sizeof(lifts);
   memcpy(lifts, b+offset, size);
   offset += size;

   size = sizeof(l);
   memcpy(l, b+offset, size);
}


// test a=20 b=10

// get  c = a - b (c=10)

// apply a-= c (a=10)


void get_chunk_dif(char *a, char *b, char *c, int size)
{
   for (int i=0; i<size; i++)
      c[i] = a[i] - b[i];
}

void apply_chunk_dif(char *a, char *c, int size)
{
   for (int i=0; i<size; i++)
      a[i] -= c[i];
}


void reset_states(void)
{
   // reset base state on client
   memset(clientl_chdf, 0, CHUNK_SIZE);
   clientl_chdf_id = 0;  // passcount id


   // reset dif buffer and passcount
   memset(dif, 0, CHUNK_SIZE);
   dif_id[0] = -1; // -1 will never match a passcount
   dif_id[1] = -1; 

   // reset buffer and passcounts used to build compressed chdf from packets
   memset(chdf, 0, CHUNK_SIZE);
   for (int i=0; i<16; i++)
      chdf_pieces[i] = -1;

   // reset server chdf's
   for (int i=0; i<8; i++)
   {
      memset(client_chdf[i][0], 0, CHUNK_SIZE);
      memset(client_chdf[i][1], 0, CHUNK_SIZE);
      client_chdf_id[i][0] = 0; // src passcount id
      client_chdf_id[i][1] = -3; // dst passcount id
   }
}



void show_chunk_dif(char *a, char *b)
{ 
   // copy chunks to temp vars

   struct player c1_players[NUM_PLAYERS];
   struct player c2_players[NUM_PLAYERS];

   int c1_Ei[100][32];    // enemy ints
   int c2_Ei[100][32];    // enemy ints
   
   fixed c1_Efi[100][16]; // enemy fixeds 
   fixed c2_Efi[100][16]; // enemy fixeds 
   
   
   int c1_item[500][16];  // item ints
   int c2_item[500][16];  // item ints
   
   fixed c1_itemf[500][4]; // item fixed points
   fixed c2_itemf[500][4]; // item fixed points
   
   struct lift c1_lifts[NUM_LIFTS];
   struct lift c2_lifts[NUM_LIFTS];

   int c1_l[100][100];    // level
   int c2_l[100][100];    // level


   int offset = 0;
   int size;

   size = sizeof(players);
   memcpy(c1_players, a+offset, size);
   memcpy(c2_players, b+offset, size);
   offset += size;

   size = sizeof(Ei);
   memcpy(c1_Ei, a+offset, size);
   memcpy(c2_Ei, b+offset, size);
   offset += size;

   size = sizeof(Efi);
   memcpy(c1_Efi, a+offset, size);
   memcpy(c2_Efi, b+offset, size);
   offset += size;

   size = sizeof(item);
   memcpy(c1_item, a+offset, size);
   memcpy(c2_item, b+offset, size);
   offset += size;

   size = sizeof(itemf);
   memcpy(c1_itemf, a+offset, size);
   memcpy(c2_itemf, b+offset, size);
   offset += size;

   size = sizeof(lifts);
   memcpy(c1_lifts, a+offset, size);
   memcpy(c2_lifts, b+offset, size);
   offset += size;

   size = sizeof(l);
   memcpy(c1_l, a+offset, size);
   memcpy(c2_l, b+offset, size);


   int sop = sizeof(players);

   if (memcmp(c1_players, c2_players, sop))
   {
      if (L_LOGGING_NETPLAY_show_dif1)
      {
         #ifdef LOGGING_NETPLAY_show_dif1
         sprintf(msg, "player errors detected\n");
         add_log_entry2(31, active_local_player, msg); printf("%s", msg);
         #endif   
      }  
      if (L_LOGGING_NETPLAY_show_dif2)
      {
         #ifdef LOGGING_NETPLAY_show_dif2
   
         // show where  
         for (int i=0; i<sop; i++)
         {
            if (a[i] != b[i])
            {
               int ps = sop /8;  // size of one player
               int p = i/ps ;    // get player
               int o = i % ps;   // get offset
   //            printf("player[%d] error detected at offset%d byte_pos:%d\n", p, o, o/4);
   //            sprintf(msg, "[%d][%d] \n", a[i], b[i]);
   
               sprintf(msg, "player[%d] byte:[%d] var:[%d] server:[%d] local:[%d] \n", p, o, o/4, a[i], b[i] );
               add_log_entry2(32, active_local_player, msg); 
            }              
         }  
    

         for (int p=0; p<8; p++)
         {
            if (c1_players[p].active != c2_players[p].active)
            {
               sprintf(msg, "player[%d].active  server:[%d] local:[%d]\n", p, c1_players[p].active, c2_players[p].active );
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].paused != c2_players[p].paused)
            {
               sprintf(msg, "player[%d].paused  server:[%d] local:[%d]\n", p, c1_players[p].paused, c2_players[p].paused );
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].paused_type  != c2_players[p].paused_type)
            {
               sprintf(msg, "player[%d].paused_type   server:[%d] local:[%d]\n", p, c1_players[p].paused_type,  c2_players[p].paused_type);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].paused_mode  != c2_players[p].paused_mode)
            {
               sprintf(msg, "player[%d].paused_mode   server:[%d] local:[%d]\n", p, c1_players[p].paused_mode,  c2_players[p].paused_mode);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].paused_mode_count  != c2_players[p].paused_mode_count)
            {
               sprintf(msg, "player[%d].paused_mode_count   server:[%d] local:[%d]\n", p, c1_players[p].paused_mode_count,  c2_players[p].paused_mode_count);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
           if (c1_players[p].PX != c2_players[p].PX)
            {
               sprintf(msg, "player[%d].PX   server:[%f] local:[%f]\n", p, fixtof(c1_players[p].PX), fixtof(c2_players[p].PX));
               add_log_entry2(32, active_local_player, msg); 
            }   
      
            if (c1_players[p].PY  != c2_players[p].PY)
            {
               sprintf(msg, "player[%d].PY   server:[%f] local:[%f]\n", p, fixtof(c1_players[p].PY), fixtof(c2_players[p].PY)  );
               add_log_entry2(32, active_local_player, msg); 
            }   
      
            if (c1_players[p].xinc != c2_players[p].xinc)
            {
               sprintf(msg, "player[%d].xinc server:[%f] local:[%f]\n", p, fixtof(c1_players[p].xinc), fixtof(c2_players[p].xinc)  );
               add_log_entry2(32, active_local_player, msg); 
            }   
      
            if (c1_players[p].yinc != c2_players[p].yinc)
            {
               sprintf(msg, "player[%d].yinc server:[%f] local:[%f]\n", p, fixtof(c1_players[p].yinc), fixtof(c2_players[p].yinc)  );
               add_log_entry2(32, active_local_player, msg); 
            }   
     
            if (c1_players[p].right_xinc != c2_players[p].right_xinc)
            {
               sprintf(msg, "player[%d].right_xinc server:[%f] local:[%f]\n", p, fixtof(c1_players[p].right_xinc), fixtof(c2_players[p].right_xinc)  );
               add_log_entry2(32, active_local_player, msg); 
            }   
      
            if (c1_players[p].left_xinc != c2_players[p].left_xinc)
            {
               sprintf(msg, "player[%d].left_xinc server:[%f] local:[%f]\n", p, fixtof(c1_players[p].left_xinc), fixtof(c2_players[p].left_xinc)  );
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].LIFE != c2_players[p].LIFE)
            {
               sprintf(msg, "player[%d].LIFE   server:[%f] local:[%f]\n", p, fixtof(c1_players[p].LIFE), fixtof(c2_players[p].LIFE));
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].old_LIFE != c2_players[p].old_LIFE)
            {
               sprintf(msg, "player[%d].old_LIFE   server:[%f] local:[%f]\n", p, fixtof(c1_players[p].old_LIFE), fixtof(c2_players[p].old_LIFE));
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].LIVES  != c2_players[p].LIVES)
            {
               sprintf(msg, "player[%d].LIVES   server:[%d] local:[%d]\n", p, c1_players[p].LIVES,  c2_players[p].LIVES);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
   /*
            if (c1_players[p].bitmap_index  != c2_players[p].bitmap_index)
            {
               sprintf(msg, "player[%d].bitmap_index   server:[%d] local:[%d]\n", p, c1_players[p].bitmap_index,  c2_players[p].bitmap_index);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
   
            if (c1_players[p].shape  != c2_players[p].shape)
            {
               sprintf(msg, "player[%d].shape   server:[%d] local:[%d]\n", p, c1_players[p].shape,  c2_players[p].shape);
               add_log_entry2(32, active_local_player, msg); 
            }   
   */
   
   
            if (c1_players[p].color  != c2_players[p].color)
            {
               sprintf(msg, "player[%d].color   server:[%d] local:[%d]\n", p, c1_players[p].color,  c2_players[p].color );
               add_log_entry2(32, active_local_player, msg); 
            }   
   
   
   
      
           if (c1_players[p].door_draw_rot_num_steps  != c2_players[p].door_draw_rot_num_steps)
            {
               sprintf(msg, "player[%d].door_draw_rot_num_steps   server:[%d] local:[%d]\n", p, c1_players[p].door_draw_rot_num_steps,  c2_players[p].door_draw_rot_num_steps);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].door_draw_rot != c2_players[p].door_draw_rot)
            {
               sprintf(msg, "player[%d].door_draw_rot   server:[%f] local:[%f]\n", p, fixtof(c1_players[p].door_draw_rot), fixtof(c2_players[p].door_draw_rot));
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].door_draw_rot_inc != c2_players[p].door_draw_rot_inc)
            {
               sprintf(msg, "player[%d].door_draw_rot_inc   server:[%f] local:[%f]\n", p, fixtof(c1_players[p].door_draw_rot_inc), fixtof(c2_players[p].door_draw_rot_inc));
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].draw_rot != c2_players[p].draw_rot)
            {
               sprintf(msg, "player[%d].draw_rot   server:[%f] local:[%f]\n", p, fixtof(c1_players[p].draw_rot), fixtof(c2_players[p].draw_rot));
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].draw_scale != c2_players[p].draw_scale)
            {
               sprintf(msg, "player[%d].draw_scale   server:[%f] local:[%f]\n", p, fixtof(c1_players[p].draw_scale), fixtof(c2_players[p].draw_scale));
               add_log_entry2(32, active_local_player, msg); 
            }   
   
   
   
            if (c1_players[p].marked_door  != c2_players[p].marked_door)
            {
               sprintf(msg, "player[%d].marked_door   server:[%d] local:[%d]\n", p, c1_players[p].marked_door,  c2_players[p].marked_door);
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].door_item  != c2_players[p].door_item)
            {
               sprintf(msg, "player[%d].door_item   server:[%d] local:[%d]\n", p, c1_players[p].door_item,  c2_players[p].door_item);
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].door_xinc  != c2_players[p].door_xinc)
            {
               sprintf(msg, "player[%d].door_xinc   server:[%d] local:[%d]\n", p, c1_players[p].door_xinc,  c2_players[p].door_xinc);
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].door_yinc  != c2_players[p].door_yinc)
            {
               sprintf(msg, "player[%d].door_yinc   server:[%d] local:[%d]\n", p, c1_players[p].door_yinc,  c2_players[p].door_yinc);
               add_log_entry2(32, active_local_player, msg); 
            }   
            if (c1_players[p].door_num_steps  != c2_players[p].door_num_steps)
            {
               sprintf(msg, "player[%d].door_num_steps   server:[%d] local:[%d]\n", p, c1_players[p].door_num_steps,  c2_players[p].door_num_steps);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].left_right  != c2_players[p].left_right)
            {
               sprintf(msg, "player[%d].left_right   server:[%d] local:[%d]\n", p, c1_players[p].left_right,  c2_players[p].left_right);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].player_ride  != c2_players[p].player_ride)
            {
               sprintf(msg, "player[%d].player_ride   server:[%d] local:[%d]\n", p, c1_players[p].player_ride,  c2_players[p].player_ride);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].carry_item  != c2_players[p].carry_item)
            {
               sprintf(msg, "player[%d].carry_item   server:[%d] local:[%d]\n", p, c1_players[p].carry_item,  c2_players[p].carry_item);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].up  != c2_players[p].up)
            {
               sprintf(msg, "player[%d].up   server:[%d] local:[%d]\n", p, c1_players[p].up,  c2_players[p].up);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].down  != c2_players[p].down)
            {
               sprintf(msg, "player[%d].down   server:[%d] local:[%d]\n", p, c1_players[p].down,  c2_players[p].down);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].left  != c2_players[p].left)
            {
               sprintf(msg, "player[%d].left   server:[%d] local:[%d]\n", p, c1_players[p].left,  c2_players[p].left);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].right  != c2_players[p].right)
            {
               sprintf(msg, "player[%d].right   server:[%d] local:[%d]\n", p, c1_players[p].right,  c2_players[p].right);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].jump  != c2_players[p].jump)
            {
               sprintf(msg, "player[%d].jump   server:[%d] local:[%d]\n", p, c1_players[p].jump,  c2_players[p].jump);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].fire  != c2_players[p].fire)
            {
               sprintf(msg, "player[%d].fire   server:[%d] local:[%d]\n", p, c1_players[p].fire,  c2_players[p].fire);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].fire_held  != c2_players[p].fire_held)
            {
               sprintf(msg, "player[%d].fire_held   server:[%d] local:[%d]\n", p, c1_players[p].fire_held,  c2_players[p].fire_held);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].menu  != c2_players[p].menu)
            {
               sprintf(msg, "player[%d].menu   server:[%d] local:[%d]\n", p, c1_players[p].menu,  c2_players[p].menu);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
     
            if (c1_players[p].bullet_wait_counter  != c2_players[p].bullet_wait_counter)
            {
               sprintf(msg, "player[%d].bullet_wait_counter   server:[%d] local:[%d]\n", p, c1_players[p].bullet_wait_counter,  c2_players[p].bullet_wait_counter);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].request_bullet  != c2_players[p].request_bullet)
            {
               sprintf(msg, "player[%d].request_bullet   server:[%d] local:[%d]\n", p, c1_players[p].request_bullet,  c2_players[p].request_bullet);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].bullet_wait  != c2_players[p].bullet_wait)
            {
               sprintf(msg, "player[%d].bullet_wait   server:[%d] local:[%d]\n", p, c1_players[p].bullet_wait,  c2_players[p].bullet_wait);
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].bullet_speed  != c2_players[p].bullet_speed)
            {
               sprintf(msg, "player[%d].bullet_speed   server:[%d] local:[%d]\n", p, c1_players[p].bullet_speed,  c2_players[p].bullet_speed );
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].num_bullets  != c2_players[p].num_bullets)
            {
               sprintf(msg, "player[%d].num_bullets   server:[%d] local:[%d]\n", p, c1_players[p].num_bullets,  c2_players[p].num_bullets );
               add_log_entry2(32, active_local_player, msg); 
            }   
   
            if (c1_players[p].num_hits  != c2_players[p].num_hits)
            {
               sprintf(msg, "player[%d].num_hits   server:[%d] local:[%d]\n", p, c1_players[p].num_hits,  c2_players[p].num_hits );
               add_log_entry2(32, active_local_player, msg); 
            }   
   /*
            if (c1_players[p].health_display  != c2_players[p].health_display)
            {
               sprintf(msg, "player[%d].health_display   server:[%d] local:[%d]\n", p, c1_players[p].health_display,  c2_players[p].health_display );
               add_log_entry2(32, active_local_player, msg); 
   
            }   
   */
   
         }
         #endif 
      }  
   }
   if (memcmp(c1_Ei, c2_Ei, sizeof(Ei)))
   {
      if (L_LOGGING_NETPLAY_show_dif1)
      {
         #ifdef LOGGING_NETPLAY_show_dif1
         sprintf(msg, "Ei errors detected\n");
         add_log_entry2(31, active_local_player, msg); printf("%s", msg);
         #endif   
      }
      if (L_LOGGING_NETPLAY_show_dif2)
      {
         #ifdef LOGGING_NETPLAY_show_dif2
         for (int e=0; e<100; e++)
            for (int f=0; f<32; f++)
               if (c1_Ei[e][f] != c2_Ei[e][f])
               {
                  sprintf(msg, "Ei[%2d][%2d][t:%2d] server:%d local:%d\n", e, f, c1_Ei[e][0], c1_Ei[e][f], c2_Ei[e][f]); 
                  add_log_entry2(32, active_local_player, msg); 
               }
         #endif   
      }
   }
   if (memcmp(c1_Efi, c2_Efi, sizeof(Efi)))
   {
      if (L_LOGGING_NETPLAY_show_dif1)
      {
         #ifdef LOGGING_NETPLAY_show_dif1
         sprintf(msg, "Efi errors detected\n");
         add_log_entry2(31, active_local_player, msg); printf("%s", msg);
         #endif   
      }
      if (L_LOGGING_NETPLAY_show_dif2)
      {
         #ifdef LOGGING_NETPLAY_show_dif2
         for (int e=0; e<100; e++)
            for (int f=0; f<16; f++)
               if (c1_Efi[e][f] != c2_Efi[e][f])
               {
                  sprintf(msg, "Efi[%2d][%2d][t:%2d] server:%f local:%f\n", e, f, c1_Ei[e][0], fixtof(c1_Efi[e][f]), fixtof(c2_Efi[e][f])); 
                  add_log_entry2(32, active_local_player, msg); 
               }
         #endif   
      }
   } 
   if (memcmp(c1_item, c2_item, sizeof(item)))
   {
      if (L_LOGGING_NETPLAY_show_dif1)
      {
         #ifdef LOGGING_NETPLAY_show_dif1
         sprintf(msg, "item errors detected\n");
         add_log_entry2(31, active_local_player, msg); printf("%s", msg);
         #endif   
      }
      if (L_LOGGING_NETPLAY_show_dif2)
      {
         #ifdef LOGGING_NETPLAY_show_dif2
         for (int e=0; e<500; e++)
            for (int f=0; f<16; f++)
               if (c1_item[e][f] != c2_item[e][f])
               {
                  sprintf(msg, "item[%d][%d][t:%2d] server:%d local:%d\n", e, f, c1_item[e][0], c1_item[e][f], c2_item[e][f]); 
                  add_log_entry2(32, active_local_player, msg);
               }
         #endif  
      } 
   } 
   if (memcmp(c1_itemf, c2_itemf, sizeof(itemf)))
   {
      if (L_LOGGING_NETPLAY_show_dif1)
      {
         #ifdef LOGGING_NETPLAY_show_dif1
         sprintf(msg, "itemf errors detected\n");
         add_log_entry2(31, active_local_player, msg); printf("%s", msg);
         #endif   
      }
      if (L_LOGGING_NETPLAY_show_dif2)
      {
         #ifdef LOGGING_NETPLAY_show_dif2
         for (int e=0; e<500; e++)
            for (int f=0; f<4; f++)
               if (c1_itemf[e][f] != c2_itemf[e][f]) 
               {
                  sprintf(msg, "itemf[%d][%d][t:%2d] server:%f local:%f\n", e, f, c1_item[e][0], fixtof(c1_itemf[e][f]), fixtof(c2_itemf[e][f])); 
                  add_log_entry2(32, active_local_player, msg); 
               }
         #endif   
      }
   } 
   if (memcmp(c1_lifts, c2_lifts, sizeof(lifts)))
   {
      if (L_LOGGING_NETPLAY_show_dif1)
      {
         #ifdef LOGGING_NETPLAY_show_dif1
         sprintf(msg, "lift errors detected\n");
         add_log_entry2(31, active_local_player, msg); printf("%s", msg);
         #endif   
      }
      if (L_LOGGING_NETPLAY_show_dif2)
      {
         #ifdef LOGGING_NETPLAY_show_dif2
         for (int e=0; e<40; e++)
         { 
            if (c1_lifts[e].fx    != c2_lifts[e].fx )    
            {
               sprintf(msg, "lifts[%d].fx server:%f local:%f\n",    e, fixtof(c1_lifts[e].fx),    fixtof(c2_lifts[e].fx)); 
               add_log_entry2(32, active_local_player, msg);
            }
            if (c1_lifts[e].fy    != c2_lifts[e].fy )    
            {
               sprintf(msg, "lifts[%d].fy server:%f local:%f\n",    e, fixtof(c1_lifts[e].fy),    fixtof(c2_lifts[e].fy)); 
               add_log_entry2(32, active_local_player, msg);
            }
            if (c1_lifts[e].fxinc != c2_lifts[e].fxinc ) 
            {
               sprintf(msg, "lifts[%d].fxinc server:%f local:%f\n", e, fixtof(c1_lifts[e].fxinc), fixtof(c2_lifts[e].fxinc)); 
               add_log_entry2(32, active_local_player, msg);
            }
            if (c1_lifts[e].fyinc != c2_lifts[e].fyinc ) 
            {
               sprintf(msg, "lifts[%d].fyinc server:%f local:%f\n", e, fixtof(c1_lifts[e].fyinc), fixtof(c2_lifts[e].fyinc)); 
               add_log_entry2(32, active_local_player, msg);
            }
         }
         #endif   
      }
   } 
   if (memcmp(c1_l, c2_l, sizeof(l)))
   {
      if (L_LOGGING_NETPLAY_show_dif1)
      {
         #ifdef LOGGING_NETPLAY_show_dif1
         sprintf(msg, "block errors detected\n");
         add_log_entry2(31, active_local_player, msg); printf("%s", msg);
         #endif   
      }
      if (L_LOGGING_NETPLAY_show_dif2)
      {
         #ifdef LOGGING_NETPLAY_show_dif2
         for (int e=0; e<100; e++)
            for (int f=0; f<100; f++)
               if (c1_l[e][f] != c2_l[e][f])
               {
                  sprintf(msg, "block[%d][%d] server:%d local:%d\n", e, f, c1_l[e][f], c2_l[e][f] ); 
                  add_log_entry2(32, active_local_player, msg);
               }
         #endif   
      }
   }
}














//char log_msg[10000000]; // for logging
void chop_first_x_char(char *str, int n);



void log_file_viewer(void)
{
   int line_mode = 1;
   int line_pos = 0;


   char fname[1024];
   FILE *filepntr;
   char buff[200];
   char buff2[80];
   int num_lines=0;
   int ch=0;
   sprintf(fname, "logs/");
//   sprintf(fname, "logs/test.txt");
   gui_fg_color = palette_color[13]; gui_bg_color = palette_color[13+224];
   if (file_select_ex("select log file", fname, "txt", 1024, 0, 0))
   {
      filepntr=fopen(fname,"r");
      while(ch != EOF)
      {
         int loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
         {
            if (ch != 13)
            {
               buff[loop] = ch;
               loop++;
            }   
            ch = fgetc(filepntr);
         }
         buff[loop] = 0;
         strcpy (log_lines[num_lines], buff);
         num_lines++;
         // printf("num_lines:%d\n", num_lines);
  
      }
      fclose(filepntr);
      num_lines--; 

      char ctags[100][20];
      int tags[100][5];
      for (int i=0; i<100; i++)
      {
         tags[i][0] = 1;  // show/hide (all on by default)
         tags[i][1] = 15; // color (white by default)
         tags[i][2] = 0;  // number of type
         tags[i][3] = 0;  // key toggle
         tags[i][4] = 0;  // pos in list 
      }

      // always on 
      tags[10][0] = 1; tags[10][1] = 15; // reg netplay
      tags[11][0] = 1; tags[11][1] = 15; // join 
      tags[20][0] = 1; tags[20][1] = 15; // game init stuff 
      tags[22][0] = 1; tags[22][1] = 15; // ending stats


      tags[23][0] = 0; tags[23][1] = 15; tags[23][3] = 66; sprintf(ctags[23], "byts"); // bandwidth    (B) [CS]
      tags[24][0] = 0; tags[24][1] = 15; tags[24][3] = 65; sprintf(ctags[24], "pcks"); // packets      (A) [CS]

      tags[25][0] = 0; tags[25][1] = 5;  tags[25][3] = 84; sprintf(ctags[25], "time"); // timer adjust (T) [C]
      tags[27][0] = 1; tags[27][1] = 13; tags[27][3] = 88; sprintf(ctags[27], "cdf1"); // chdf         (X) [CS]
      tags[28][0] = 0; tags[28][1] = 1;  tags[28][3] = 80; sprintf(ctags[28], "cdfp"); // chdf piece   (P) [CS] 
      tags[29][0] = 0; tags[29][1] = 7;  tags[29][3] = 87; sprintf(ctags[29], "cdfw"); // chdf when    (W) [C]
      tags[31][0] = 0; tags[31][1] = 15; tags[31][3] = 68; sprintf(ctags[31], "dif1"); // show diff1   (D) [C]
      tags[32][0] = 0; tags[32][1] = 15; tags[32][3] = 70; sprintf(ctags[32], "dif2"); // show diff2   (F) [C]
      tags[35][0] = 1; tags[35][1] = 3;  tags[35][3] = 67; sprintf(ctags[35], "cdat"); // cdat         (C) [CS]
      tags[37][0] = 1; tags[37][1] = 9;  tags[37][3] = 83; sprintf(ctags[37], "sdat"); // sdat         (S) [CS]
      tags[38][0] = 0; tags[38][1] = 6;  tags[38][3] = 71; sprintf(ctags[38], "move"); // game move    (G) [C]
      tags[39][0] = 0; tags[39][1] = 6;  tags[39][3] = 75; sprintf(ctags[39], "sdak"); // sdak         (K) [S]

      tags[99][0] = 1; tags[99][1] = 10; // bad tag 


      // find and process tags
      for (int i=0; i<num_lines; i++)
      {
         int bad_tags = 0;
         // get first tag - (type) in the format "[xx]"
         char * pch1 = strchr(log_lines[i], '[');
         char * pch2 = strchr(log_lines[i], ']');
         int p1 = pch1-log_lines[i];
         int p2 = pch2-log_lines[i];
         if ((p1 == 0) && (p2 == 3))
         {
             buff2[0] = log_lines[i][1];
             buff2[1] = log_lines[i][2];
             buff2[2] = 0;
             log_lines_int[i][0] = atoi(buff2); // type 
             chop_first_x_char(log_lines[i], 4);
             tags[ log_lines_int[i][0] ]  [2]  ++; // inc number of this tag

         }     
         else bad_tags = 1;
         if (!bad_tags)
         {
            // get second tag - (player) in the format "[x]"
            char * pch1 = strchr(log_lines[i], '[');
            char * pch2 = strchr(log_lines[i], ']');
            int p1 = pch1-log_lines[i];
            int p2 = pch2-log_lines[i];
            if ((p1 == 0) && (p2 == 2))
            {
                buff2[0] = log_lines[i][1];
                buff2[1] = 0;
                log_lines_int[i][1] = atoi(buff2); // player
                chop_first_x_char(log_lines[i], 3);
            }     
            else bad_tags = 1;
         }
         if (!bad_tags)
         {
            // get third tag - (passcount) in the format "[xxx..]"
            char * pch1 = strchr(log_lines[i], '[');
            char * pch2 = strchr(log_lines[i], ']');
            int p1 = pch1-log_lines[i];
            int p2 = pch2-log_lines[i];
            if ((p1 == 0) && (p2 < 8))
            {
                for(int j=0; j<p2; j++)
                   buff2[j] = log_lines[i][j+1];
                buff2[p2] = 0;
                log_lines_int[i][2] = atoi(buff2); // passcount
                chop_first_x_char(log_lines[i], p2+1);
            }     
            else bad_tags = 1;
         }
         if (bad_tags) 
         {
             log_lines_int[i][0] = 99; 
             tags[99][2]++; // inc number of this tag
         }
      }


      // get start and end passcounts
      int start_pc = log_lines_int[0][2];
      int end_pc = 0;
      for (int i=0; i<num_lines; i++)
         if (log_lines_int[i][2] > end_pc) end_pc = log_lines_int[i][2];

      int pos = 0; // the top passcount line on the screen
      int quit = 0;
      int redraw = 1;
//      clear(screen);



      // find players in this file
      int lp[8][2];
      for (int i=0; i<8; i++)
      {
         lp[i][0] = 0; // show/hide
         lp[i][1] = 0; // num
      }
      for (int i=0; i<num_lines; i++)
      {
         int p = log_lines_int[i][1];
         if ((p >=0) && (p < 7)) 
         {
            lp[p][0] = 1;
            lp[p][1]++;
         }
      }



      while (!quit)
      {
         if (line_mode)
         {
            if (line_pos < 0) line_pos = 0;
            if (line_pos > num_lines) line_pos = num_lines;
            pos = log_lines_int[line_pos][2];
         }
         else // pascount mode
         {
            if (pos < start_pc) pos = start_pc;
            if (pos > end_pc) pos = end_pc;
         }

   
         if (redraw)
         { 
            redraw = 0;
            int ty = 0;
            int color = 15; 
            int first_line = 0;

            if (line_mode)
            {
               first_line = line_pos;
            }
            else // pascount mode
            {
               // find index of first line that is equal to or greater than current passcount 
               for (int i=0; i<num_lines; i++)
                  if (log_lines_int[i][2] >= pos)
                  {
                     first_line = i;
                     break;    
                  } 
               line_pos = first_line;
            }

            int xpos = 760;


            int ly = 20;  
            sprintf(msg, "Log file.........[%s]", get_filename(fname)); 
            textout_ex(scrn_buffer, font, msg, xpos, ly+=8, palette_color[15], 0);
            sprintf(msg, "Number of lines..[%d]", num_lines); 
            textout_ex(scrn_buffer, font, msg, xpos, ly+=8, palette_color[15], 0);
            sprintf(msg, "Starting frame...[%d]", start_pc); 
            textout_ex(scrn_buffer, font, msg, xpos, ly+=8, palette_color[15], 0);
            sprintf(msg, "Ending frame.....[%d]", end_pc); 
            textout_ex(scrn_buffer, font, msg, xpos, ly+=8, palette_color[15], 0);
            ly+=4;
            sprintf(msg, "Current line.....[%d]", first_line); 
            textout_ex(scrn_buffer, font, msg, xpos, ly+=8, palette_color[15], 0);
            sprintf(msg, "Current frame....[%d]", pos); 
            textout_ex(scrn_buffer, font, msg, xpos, ly+=8, palette_color[15], 0);

            ly+=8;

            if (line_mode) sprintf(msg, "Line Mode"); 
            else sprintf(msg, "Passcount Mode"); 
            textout_ex(scrn_buffer, font, msg, xpos, ly+=8, palette_color[15], 0);


            // show tag labels
            int lpos = 100;
            for (int i=23; i<40; i++)
            {
               if (tags[i][2]) // this tag type is present in log 
               {
                  int col = tags[i][1];
                  char tmsg[5];
                  if (tags[i][0]) sprintf(tmsg,"on ");
                  else
                  {
                     sprintf(tmsg,"off");
                     col = 127; //grey 
                  }

                  tags[i][4] = lpos; lpos+=8; // set the ypos
                  sprintf(msg, "%c %s %s num:[%d]", tags[i][3], ctags[i], tmsg, tags[i][2]); 
                  textout_ex(scrn_buffer, font, msg, xpos, lpos, palette_color[col], 0);
               }                 
            }  

            // show players

            lpos+=8;





            for (int i=0; i<8; i++)
               if (lp[i][1])
               {
                  int col = 15;
                  char tmsg[5];
                  if (lp[i][0]) sprintf(tmsg,"on ");
                  else
                  {
                     sprintf(tmsg,"off");
                     col = 127; //grey 
                  }

                  sprintf(msg, "%d plyr:%d %s num:[%d]", i, i, tmsg, lp[i][1]); 
                  textout_ex(scrn_buffer, font, msg, xpos, lpos+=8, palette_color[col], 0);
               }


            // draw all the lines
            int i = first_line;
            int done = 0;
            while (!done)
            {  
               int type = log_lines_int[i][0];
               int p    = log_lines_int[i][1];
               int pc   = log_lines_int[i][2];

               if (type == 99) // bad tags on this line
               {
                  sprintf(msg, "i[%d] t[%d] p[%d] pc[%d] (bad tags)- %s", i, type, p, pc, log_lines[i]); 
                  textout_ex(scrn_buffer, font, msg, 0, ty+=8, palette_color[color], 0);
               }
               else
               {
                  sprintf(msg, "[%3d][%4d][%d]%s", i, pc, p, log_lines[i]); 

                  //sprintf(msg, "i[%d] t[%d] p[%d] pc[%d] - %s", i, type, p, pc, log_lines[i]); 
//                  sprintf(msg, "[%4d][%d]%s", pc, type, log_lines[i]); 
                  //sprintf(msg, "[%4d][%d]%s", pc, p, log_lines[i]); 
//                  sprintf(msg, "[%4d]%s", pc, log_lines[i]); 






                  color = tags[type][1];
                  if ((tags[type][0]) && (lp[p][0])) // tag and player filter
                     textout_ex(scrn_buffer, font, msg, 0, ty+=8, palette_color[color], 0);
               }

               if (++i >= num_lines) done = 1; // no more lines 
               if (ty > SCREEN_H - 20) done = 1; // no more screen  

            }

            blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
            clear(scrn_buffer); 
          }

         if (keypressed())
         {
            redraw = 1;
            int k = readkey();
            k = (k & 0xFF);          // strip upper bits 
            if ((k>31) && (k<128))   // if alphanumeric 
            {
               // toggle tags
               for (int i=23; i<40; i++)
                 if ((tags[i][3] == k) || (tags[i][3] == k-32)) // upper or lower case
                    tags[i][0] = !tags[i][0]; // toggle tag on/off 
               // toggle players
               if ((k > 47) && (k < 56))
               {
                  int p = k - 48;
                  lp[p][0] = !lp[p][0];          
               }               
            }
         }

         if (key[KEY_L])
         {
            while (key[KEY_L]);
            line_mode =! line_mode; 
            redraw = 1;
         }



         if (key[KEY_UP])
         {
            while (key[KEY_UP]);
            if (line_mode) line_pos--;
            else pos--;
            redraw = 1;
         }
         if (key[KEY_DOWN])
         {
            while (key[KEY_DOWN]);
            if (line_mode) line_pos++;
            else pos++;
            redraw = 1;
         }
         if (key[KEY_PGUP])
         {
            while (key[KEY_PGUP]);
            if (line_mode)
            {
               if (key_shifts & KB_CTRL_FLAG) line_pos -= 1000;
               else line_pos-=100;
            } 
            else
            { 
               if (key_shifts & KB_CTRL_FLAG) pos -= 1000;
               else pos-=100;
            }
            redraw = 1;
         }
         if (key[KEY_PGDN])
         {
            while (key[KEY_PGDN]);
            if (line_mode)
            {
               if (key_shifts & KB_CTRL_FLAG) line_pos += 1000;
               else line_pos+=100;
            } 
            else
            { 
               if (key_shifts & KB_CTRL_FLAG) pos += 1000;
               else pos+=100;
            }
            redraw = 1;
         }
         if (key[KEY_HOME])
         {
            while (key[KEY_HOME]);
            if (line_mode) line_pos = 0;
            else pos = 0;
            redraw = 1;
         }
         if (key[KEY_END])
         {
            while (key[KEY_END]);
            if (line_mode) line_pos = num_lines;
            else pos = end_pc;
            redraw = 1;
         }


         if (key[KEY_DEL])
         {
            while (key[KEY_DEL]);
            // draw a graph
            // find the range 0 - end_pc

            // build array of data points 
            int data[10000][4];
            int num_data = 0;
            for (int i=0; i<1000; i++)
               for (int j=0; j<4; j++)
                  data[i][j] = 0; 

            // 0 = passcount
            // 1 = player 
            // 2  tx b
            // 3  rx b

            for (int i=0; i<num_lines; i++)
            {
               int tx = 99;
               int rx = 99;

               int type = log_lines_int[i][0];
               int p = log_lines_int[i][1];
               int pc = log_lines_int[i][2];
               if (type == 23)
               {
                  char tll[200]; // temp log line                                   
                  sprintf(tll, "%s", log_lines[i]);

                  // get first tag - (type) in the format "[xx]"
                  char * pch1 = strchr(tll, '[');
                  char * pch2 = strchr(tll, ']');
      
                  int p1 = pch1-tll;
                  int p2 = pch2-tll;
      
                  if (p2 - p1 < 8)
                  {
                      for(int j=0; j<p2; j++)
                         buff2[j] = tll[j+p1+1];
                      buff2[p2] = 0;
                      tx = atoi(buff2);
                      chop_first_x_char(tll, p2+1);
                  }     


                  // get second tag and discard
                  pch1 = strchr(tll, '[');
                  pch2 = strchr(tll, ']');
      
                  p1 = pch1-tll;
                  p2 = pch2-tll;
      
                  if (p2 - p1 < 8)
                  {
                      for(int j=0; j<p2; j++)
                         buff2[j] = tll[j+p1+1];
                      buff2[p2] = 0;
                      //tx = atoi(buff2); // ignore
                      chop_first_x_char(tll, p2+1);
                  }     

                  // get the third tag
                  pch1 = strchr(tll, '[');
                  pch2 = strchr(tll, ']');
      
                  p1 = pch1-tll;
                  p2 = pch2-tll;
      
                  if (p2 - p1 < 8)
                  {
                      for(int j=0; j<p2; j++)
                         buff2[j] = tll[j+p1+1];
                      buff2[p2] = 0;
                      rx = atoi(buff2);
                      chop_first_x_char(tll, p2+1);
                  }     

                  data[num_data][0] = pc;
                  data[num_data][1] = p;
                  data[num_data][2] = tx;
                  data[num_data][3] = rx;
                  num_data++;

                  // printf("pc:%d  tx:%d  rx:%d\n", pc, tx, rx);
               }
            } 
            // all the data is in the array



            int gquit = 0;
            int redraw = 1; 

            // set the graph width, height and baseline
            int graph_w = SCREEN_W;
            int graph_h = SCREEN_H - 20;

            int gs_pc = 0; // graph start pc


            int bl = graph_h - 20; // baseline 
            float y_scale = 1;
            float p2g = 1;            int old_ix, old_ity, old_iry;

            while (!gquit) 
            {
               if (redraw)
               {
                  if (redraw != 2) // don't auto set scale 
                  { 
                     // find the max value
                     int max = 0; 
                     for (int i=0; i<num_data; i++)
                     {
                        int p = data[i][1];
                        if (lp[p][0]) // only if this player is not hidden
                        {
                           if (data[i][2] > max) max = data[i][2];
                           if (data[i][3] > max) max = data[i][3];
                        } 
                     }
   
                     // set y scale based on graph height and largest value   
                     y_scale = (float)(graph_h-40) / (float)max;
                     // printf("max:%d y_scale:%f\n", max, y_scale);

                     // set x scale based on graph width and end frame
                     p2g = (float)graph_w / (float)end_pc;  // passcount to graph scaler
                     // printf("graph_w:%d / end_pc:%d = p2g:%f\n", graph_w, end_pc, p2g);
                  }      
      
      
/*
                  // draw x scale lines every 1000 frames
                  for (float i=1000; (int)(i*p2g) < graph_w; i+= 1000) 
                  {
                     line(scrn_buffer, (int)(i*p2g), 0, (int)(i*p2g), bl, palette_color[12+48]);
                     sprintf(msg, "%d", (int)i); 
                     textout_ex(scrn_buffer, font, msg, (int)(i*p2g)-16, bl+4,  palette_color[12], 0);
                  }
*/

                  // draw x scale lines every second
                  for (float i=40; (int)((i-gs_pc)*p2g) < graph_w; i+= 40) 
                  {
                     int hx = (int)((i-gs_pc)*p2g);
                     line(scrn_buffer, hx, 0, hx, bl, palette_color[13+96]);
                  }
                  // draw x scale lines every 10 seconds
                  for (float i=400; (int)((i-gs_pc)*p2g) < graph_w; i+= 400) 
                  {
                     int hx = (int)((i-gs_pc)*p2g);

                     line(scrn_buffer, hx, 0, hx, bl, palette_color[13+32]);
                     sprintf(msg, "%ds", (int)(i/40)); 
                     int so = 4 * strlen(msg);  
                     textout_ex(scrn_buffer, font, msg, hx-so, bl+4,  palette_color[13], 0);

                     sprintf(msg, "%d", (int)(i)); 
                     so = 4 * strlen(msg);  
                     textout_ex(scrn_buffer, font, msg, hx-so, bl+12,  palette_color[13], 0);

                     sprintf(msg, "frames"); 
                     so = 4 * strlen(msg);  
                     textout_ex(scrn_buffer, font, msg, hx-so, bl+20,  palette_color[13], 0);

                  }

                  // draw y scale lines every 1000 B/s
                  textout_ex(scrn_buffer, font, "0 B/s", 0, bl-4,  palette_color[11], 0);
                  line(scrn_buffer, 44, bl, graph_w, bl, palette_color[11+48]);
                  for (float i=1000; i*y_scale < graph_h; i+= 1000) 
                  {
                     int y_pos = bl - (int)(i*y_scale);
                     sprintf(msg, "%d B/s", (int)i); 
                     textout_ex(scrn_buffer, font, msg, 0, y_pos-4,  palette_color[11], 0);
                     line(scrn_buffer, 76, y_pos, graph_w, y_pos, palette_color[11+96]);
                  }

      
                  // draw the data one player at a time
                  for (int p=0; p<NUM_PLAYERS; p++)
                  {
                     if (lp[p][0])
                     {
                        int first_time = 1; 
                        for (int i=0; i<num_data; i++)
                        {
                           int pc = data[i][0];
                           int dp = data[i][1];
                           int tx = data[i][2];
                           int ty = data[i][3];
                           int col = players[p].color; 
                           if ((dp == p) &&  (pc >= gs_pc))
                           {
                              int ix = (int) ( (float)(pc-gs_pc) * p2g);
                              int ity = bl - (int) ( (float)tx * y_scale);
                              int iry = bl - (int) ( (float)ty * y_scale);
                              if (first_time) // set previous point to this point
                              {
                                 first_time = 0;
                                 old_ix = ix;
                                 old_ity = ity;
                                 old_iry = iry;
                              }
                              line(scrn_buffer, old_ix, old_iry, ix, iry, palette_color[col-96]);
                              line(scrn_buffer, old_ix, old_ity, ix, ity, palette_color[col]);
                              old_ix = ix;
                              old_ity = ity;
                              old_iry = iry;
                           }
                        }
                     }
                  }


                  int lpos = 20; 
                  for (int i=0; i<8; i++)
                     if (lp[i][1])
                     {
                        int col = players[i].color; 
                        char tmsg[5];
                        if (lp[i][0]) sprintf(tmsg,"on ");
                        else
                        {
                           sprintf(tmsg,"off");
                           col = 127; //grey 
                        }
      
                        sprintf(msg, "player:%d %s", i, tmsg); 
                        textout_ex(scrn_buffer, font, msg, SCREEN_W - 102, lpos+=8, palette_color[col], 0);
                     }


                  blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
                  clear(scrn_buffer); 
                  redraw = 0;     
                        
               } // end of redraw

               if (keypressed())
               {
                  int k = readkey();
                  k = (k & 0xFF);          // strip upper bits 
                  if ((k > 47) && (k < 56))
                  {
                     redraw = 1;
                     int p = k - 48;
                     lp[p][0] = !lp[p][0];          
                  }               
               }

               if (key[KEY_RIGHT])
               {
                  while (key[KEY_RIGHT]);
                  if (key_shifts & KB_CTRL_FLAG)
                  {
                     gs_pc += 100;
                     if (gs_pc > end_pc) gs_pc = end_pc;
                  }                 
                  else if (key_shifts & KB_SHIFT_FLAG)
                  {
                     gs_pc += 1000;
                     if (gs_pc > end_pc) gs_pc = end_pc;
                  }                 
                  else p2g *= 1.1;
                  redraw = 2; 
               }

               if (key[KEY_LEFT])
               {
                  while (key[KEY_LEFT]);
                  if (key_shifts & KB_CTRL_FLAG)
                  {
                     gs_pc -= 100;
                     if (gs_pc < 0) gs_pc = 0;
                  }                 
                  else if (key_shifts & KB_SHIFT_FLAG)
                  {
                     gs_pc -= 1000;
                     if (gs_pc < 0) gs_pc = 0;
                  }                 
                  else p2g *= .9;
                  redraw = 2; 
               }

   
               if (key[KEY_UP])
               {
                  while (key[KEY_UP]);
                  y_scale *= 1.1;
                  redraw = 2; 
               }
               if (key[KEY_DOWN])
               {
                  while (key[KEY_DOWN]);
                  y_scale *= .9;
                  redraw = 2;
               }

     
               while (key[KEY_ESC]) gquit = 1;
            }
         }
         while (key[KEY_ESC]) quit = 1;
      }
   }
}
















extern int sx, sy, gfx_card, color_depth, auto_full_screen;
extern int desktop_sx, desktop_sy, desktop_colordepth;
void proc_screen_change(void);

int st_sr(int sx, int sy, int cd, int gfx_card)
{
   set_color_depth(cd);
   if (set_gfx_mode(gfx_card, sx, sy, 0, 0) == 0)
   { 
      if (gfx_card == 1) sprintf(msg, "[%4d x %4d] %2d bit fullscreen..", sx, sy, cd);
      if (gfx_card == 2) sprintf(msg, "[%4d x %4d] %2d bit windowed....", sx, sy, cd);

      strcat(log_msg, msg);
      printf("%s", msg);
      proc_screen_change();
      return 1;
   }   
   else  // failed
   {
      sprintf(msg, "Error setting: [%d x %d] gfx_card:%d color_depth:%d\n", sx, sy, gfx_card, cd);
      strcat(log_msg, msg);
      printf("%s", msg);
      return 0; 
   }
}


void st_run(void)
{
   load_gm("test1.gm");
   players[0].control_method = 1;
   start_mode = 2; // load level and start, but skip game array erasing
   game_exit = 0;

   int start_timer = clock();
   pm_main();
   int finish_time = clock();
   int time = finish_time - start_timer;

   int cps = CLOCKS_PER_SEC;

   sprintf(msg, "[%3d] Frames per second -- [%dms] per frame\n",(passcount*cps) / time, time/passcount);
   printf("%s", msg);
   strcat(log_msg, msg);

}

void speed_test(void)
{
   sprintf(msg, "\n---------------------------------\n- Speed test for %s\n", local_hostname);
   printf("%s", msg);
   strcpy(log_msg, msg);

   get_desktop_resolution(&desktop_sx, &desktop_sy);
   desktop_colordepth = desktop_color_depth();

   sprintf(msg, "Desktop resolution: [%d x %d] %d bit\n", desktop_sx, desktop_sy, desktop_colordepth);
   printf("%s", msg);
   strcat(log_msg, msg);

   // get operating system type
   show_os_detected();
   strcat(log_msg, msg);
   strcat(log_msg, "\n");

   int cps = CLOCKS_PER_SEC;
   sprintf(msg, "CLOCKS_PER_SEC [%d]\n", cps);
   printf("%s", msg);
   strcat(log_msg, msg);

   // get allegro id
   sprintf(msg, "Allegro version:    [%s]\n\n", allegro_id);
   printf("%s", msg);
   strcat(log_msg, msg);

   speed_testing = 1;
/*
   if (st_sr(desktop_sx, desktop_sy, 32, 1)) st_run();
   if (st_sr(desktop_sx, desktop_sy, 16, 1)) st_run();
   if (st_sr(desktop_sx, desktop_sy, 8, 1)) st_run();

   if (st_sr(1024, 768, 32, 2)) st_run();
   if (st_sr(1024, 768, 16, 2)) st_run();
   if (st_sr(1024, 768, 8, 2)) st_run();



   if (st_sr(1024, 768, 32, 1)) st_run();
   if (st_sr(1024, 768, 16, 1)) st_run();
   if (st_sr(1024, 768, 8, 1)) st_run();

*/

   if (st_sr(800, 600, 32, 2)) st_run();

/*

   if (st_sr(800, 600, 16, 2)) st_run();
   if (st_sr(800, 600, 8, 2)) st_run();

   if (st_sr(800, 600, 32, 1)) st_run();
   if (st_sr(800, 600, 16, 1)) st_run();
   if (st_sr(800, 600, 8, 1)) st_run();

*/

   FILE *filepntr;
   char filename[140];
   sprintf(filename, "logs/speedtest[%s].txt", local_hostname);
   filepntr = fopen(filename,"w");
   fprintf(filepntr, "%s", log_msg);
   fclose(filepntr);
}



int fill_demo_array(const char * filename, int attrib, void *parm)
{
   if (num_demo_filenames > 99) return 0; // only get 100 max
   sprintf(msg, "%s", filename);
   chop_first_x_char(msg, 9); // get rid of dir
   sprintf(demo_filenames[num_demo_filenames], msg);
   demo_played[num_demo_filenames] = 0;
   num_demo_filenames++;
   return 0;
}


void demo_mode(void)
{
   demo_mode_on = 1;
   num_demo_filenames = 0;

   // iterate levels in demo folder and put in filename array
   for_each_file_ex("savegame/demo/*.gm", 0, 0, fill_demo_array, 0);

   //for (int i=0; i< num_demo_filenames; i++)
    // printf("%s\n", demo_filenames[i]);


   if (num_demo_filenames == 0)
   {
      printf("No demo files found.\n");
      demo_mode_on = 0;    
   }

   int prev_lev, lev, pass = 1;
   while (demo_mode_on)   
   {
      if (num_demo_filenames > 1)
      {
         // have all levels this pass been played?
         int all_played = 1;
         for (int i=0; i< num_demo_filenames; i++)
            if (demo_played[i] < pass) all_played = 0;   
         if (all_played == 1) pass++; // next pass

         lev = -1;
         while (lev < 0)
         {
            lev = rand() % num_demo_filenames;      // get random index
            if (demo_played[lev] >= pass) lev = -1; // already been played this pass
            if (prev_lev == lev) lev = -1;          // just previously played
         }  
         demo_played[lev] = pass;
         prev_lev = lev;         
      }
      else lev = 0;

/*     printf("demo level index [%d]\n", lev);
     for (int i=0; i< num_demo_filenames; i++)
        printf("%d demo_played[%d]\n", i, demo_played[i]);
*/

      if (load_gm(demo_filenames[lev]))
      {
         players[0].control_method = 1;
         start_mode = 2; // load level and start, but skip game array erasing
         game_exit = 0;
         pm_main();
         players[0].control_method = 0;
      
         // reset player data
         for (int p=0; p<NUM_PLAYERS; p++)
         {
             players[p].active = 0;
             players[p].control_method = 0;
         }   
         players[0].active = 1;
         active_local_player = 0; 
      }  
   }

   load_level(start_level, 0);
   resume_allowed = 0;   

}









































