#include <allegro.h>
#include "pm.h"

/* sounds
        0 - Player Shoots
        1 - "d'OH"
        2 - bonus
        3 - Fuse hiss
        4 - CFG MIDI la de da  door, key, exit
        5 - explosion noise
        6 - grunt 1
        7 - grunt 2
        8 - phew for enemy killed
*/

extern int sound_on;
extern int st_scaler;
extern int se_scaler;
extern SAMPLE *snd[20];

#ifdef DUMB
extern DUH *myduh;
extern AL_DUH_PLAYER *dp;

void start_music()
{
   float vol = (float)st_scaler/9;
   dp = al_start_duh(myduh, 2, 0, vol, 4096, 22050);
}
#endif


#ifdef SOUND
extern int lit_item;
extern int fuse_loop_playing;
#endif

void proc_sound()  // this is called once for every passcount
{
#ifdef SOUND
   if (sound_on)
   {


#ifdef DUMB
      al_poll_duh(dp);
#endif


      if ((!fuse_loop_playing) && (lit_item))
      {
         fuse_loop_playing = 1;
         play_sample(snd[3], (200*se_scaler)/9, 127, 1000, 1);
      }
      if ((fuse_loop_playing) && (!lit_item))
      {
         fuse_loop_playing = 0;
         stop_sample(snd[3]);
      }
      lit_item = 0;
   }
   #endif
}

void load_sound() // for normal loading of sound driver and samples 
{
#ifdef SOUND
   sound_on = get_config_int("SOUND", "sound_on", 1);
   set_config_int("SOUND", "sound_on", sound_on);

   if (sound_on) sprintf(global_string[8][7],"Sound:On");
   else sprintf(global_string[8][7],"Sound:Off");

   se_scaler = get_config_int("SOUND", "se_scaler", 5);
   set_se_scaler();
#ifdef DUMB
   st_scaler = get_config_int("SOUND", "st_scaler", 5);
   set_st_scaler();
#endif
   if (sound_on)
   {
      #ifdef DUMB
      dumb_register_stdfiles();
      myduh = dumb_load_xm("snd/pm.xm");
      #endif
     
      int num_sounds = 9;
      sprintf(msg, "Initializing Sound Card");
      textout_centre_ex(screen, font, msg, SCREEN_W/2, SCREEN_H/2, palette_color[10], 0);
   
      // if install_sound fails, 'sound_on=0' will be saved in the config file so that the next 
      // time the game is started it won't crash again by trying to load the sound driver
      // (actually fails to write if it causes a crash !!) 
      set_config_int("SOUND", "sound_on", 0);
      if (install_sound(DIGI_AUTODETECT, MIDI_NONE, NULL) == 0)
      {
         sound_on = 1;
         set_config_int("SOUND", "sound_on", sound_on);
         sprintf(global_string[8][7],"Sound:On");
   
         int x;
         for (x=0; x<num_sounds; x++)
         {
            char fn[20] = "snd/snd00.wav";
            char *filename;
            if (x>9)
            {
               fn[3+4] = 49; // 1 
               fn[4+4] = 48 + (x-10);
            }
            else fn[4+4] = 48 + x;
            filename = fn;
            snd[x] = load_sample(filename);
         }
      }
      else
      {
         printf("Failed to intall sound\n");
         sound_on = 0;
         set_config_int("SOUND", "sound_on", sound_on);
         sprintf(global_string[8][7],"Sound:Off");
         clear(screen);
         textout_centre_ex(screen, font, "...Sound Card Not Found...", SCREEN_W/2, SCREEN_H*174/200, palette_color[10], 0);
         rest(2000);
      }
   }   
#endif
}

void set_se_scaler(void)
{
   extern int se_scaler;
   sprintf(global_string[8][8],"Sound Effects Volume:%1d", se_scaler );
   set_config_int("SOUND", "se_scaler", se_scaler);
}

void set_st_scaler(void)
{
   extern int st_scaler;
   sprintf(global_string[8][9],"Sound Track Volume:%1d", st_scaler );
   set_config_int("SOUND", "st_scaler", st_scaler);
}


void sound_toggle(void)
{
#ifdef SOUND
   if (sound_on)
   {
      remove_sound();
      sound_on = 0;
      set_config_int("SOUND", "sound_on", sound_on);
      sprintf(global_string[8][7],"Sound:Off");
   }
   else
   {
      sound_on = 1;
      set_config_int("SOUND", "sound_on", sound_on);
      sprintf(global_string[8][7],"Sound:On");
      load_sound();
   }
#endif
}
