// e_special.cpp (20100220 cleanup)

#include <allegro.h>
#include "pm.h"

void draw_status_window(void) // only at setup 
{
   extern int level_num;
   extern int status_window_w;
   extern int status_window_h;

   status_window_bmp = create_bitmap(status_window_w, status_window_h);
   clear(status_window_bmp);

   textout_ex(status_window_bmp, font, "Draw Item   ", 24, 14, palette_color[15], 0);
   textout_ex(status_window_bmp, font, "mouse", 100, 14, palette_color[14], 0);
   textout_ex(status_window_bmp, font, "b1", 143, 14, palette_color[14], 0);

   textout_ex(status_window_bmp, font, "View Item ", 184, 14, palette_color[15], 0);
   textout_ex(status_window_bmp, font, "mouse", 261, 14, palette_color[14], 0);
   textout_ex(status_window_bmp, font, "b2", 303, 14, palette_color[14], 0);

   rect (status_window_bmp,   0, 12, 159, 42, palette_color[9]);
   rect (status_window_bmp, 160, 12, 319, 42, palette_color[9]);

   rectfill (status_window_bmp, 1, 0, 318, 10,  palette_color[0]);
   sprintf(msg,"Status Window    level:%d ",level_num);
   textout_ex(status_window_bmp, font, msg, 2, 3, palette_color[9], 0);
   sprintf(msg,"level:%d ",level_num);
   textout_ex(status_window_bmp, font, msg, 2+(17*8), 3, palette_color[9], 0);
   sprintf(msg,"%d ",level_num);
   textout_ex(status_window_bmp, font, msg, 2+(23*8), 3, palette_color[15], 0);

}




int process_status_window(void)
{
   extern int draw_item_num;
   extern int draw_item_type;
   extern int point_item_type;
   extern int point_item_num;
   extern int wx, wy;

   extern int status_window_active;
   
   extern int status_window_x;
   extern int status_window_y;
   extern int status_window_w;
   extern int status_window_h;

   blit(status_window_bmp, scrn_buffer, 0, 0, status_window_x, status_window_y, status_window_w, status_window_h);
   draw_item_info(status_window_x+2,   status_window_y+21, 9, draw_item_type, draw_item_num);
   draw_item_info(status_window_x+162, status_window_y+21, 9, point_item_type, point_item_num);

   sprintf(msg, "x:%-2d y:%-2d ",mouse_x/20+wx,mouse_y/20+wy );
   textout_ex(scrn_buffer, font, msg, status_window_x+222, status_window_y+3, palette_color[15], 0);

   textout_ex(scrn_buffer, font, "x:", status_window_x+222, status_window_y+3, palette_color[9], 0);
   textout_ex(scrn_buffer, font, "y:", status_window_x+222+40, status_window_y+3, palette_color[9], 0);


   if ( (mouse_x > status_window_x+310) && (mouse_x < status_window_x+320) && (mouse_y > status_window_y) && (mouse_y < status_window_y+12) )
   {
      textout_ex(scrn_buffer, font, "X", status_window_x+310, status_window_y+3, palette_color[14], 0);
      if (mouse_b & 1)
      {
         while (mouse_b & 1);
         status_window_active = 0;
         return 1001;
      }
   }
   else textout_ex(scrn_buffer, font, "X", status_window_x+310, status_window_y+3, palette_color[9], 0);
   if ( (mouse_x > status_window_x+296) && (mouse_x < status_window_x+304) && (mouse_y > status_window_y) && (mouse_y < status_window_y+12) )
   {
      textout_ex(scrn_buffer, font, "?", status_window_x+296, status_window_y+3, palette_color[14], 0);
      if (mouse_b & 1)
      {
         while (mouse_b & 1);
         help("Status Window");
         return 1001;
      }
   }
   else textout_ex(scrn_buffer, font, "?", status_window_x+296, status_window_y+3, palette_color[9], 0);
 
   if ((mouse_x > status_window_x) && (mouse_x < status_window_x+296) &&  // title bar move 
       (mouse_y > status_window_y) && (mouse_y < status_window_y+12))
   {
      rect (scrn_buffer, status_window_x,   status_window_y, status_window_x+319, status_window_y+12,  palette_color[14]);
      if (mouse_b & 1)
      {
         int tx = (mouse_x-status_window_x); // x offset 
         int ty = (mouse_y-status_window_y); // y offset 
         xor_mode(TRUE);
         while (mouse_b & 1)
         {
            rect(screen, status_window_x, status_window_y, status_window_x+status_window_w-1, status_window_y+status_window_h-1, palette_color[15]);
            rest(5);
            rect(screen, status_window_x, status_window_y, status_window_x+status_window_w-1, status_window_y+status_window_h-1, palette_color[15]);
            show_mouse(screen);
            rest(5);
            show_mouse(NULL);
            status_window_x = mouse_x-tx;
            status_window_y = mouse_y-ty;
         }
         solid_mode();
         return 1001;
      }
   }
   else rect (scrn_buffer, status_window_x,   status_window_y, status_window_x+319, status_window_y+12, palette_color[9]);
   return 1;
}
void draw_select_window(void) 
{
   extern int PDEi[100][32];
   extern int select_window_w;
   extern int select_window_h;

   extern int select_window_block_on;
   extern int swnbl_cur;

   extern int select_window_block_y;
   extern int select_window_special_on;
   extern int select_window_num_special_lines;

   extern int select_window_special_y;
   extern int select_window_text_y;
   extern int swbl[NUM_SPRITES][2];

   int c, a, b=0;

   select_window_h = 200; // for now 
   c = 13;  // first y line of sub-windows 

   set_swbl(0, NUM_SPRITES, 0);  // set swbl 

   // set special start y 
   if (select_window_special_on)
   {
      select_window_special_y = c;
      c = 16 + c + select_window_num_special_lines*20;
   }

   // set special start y 
   if (select_window_block_on)
   {
      select_window_block_y = c;
      c = 16 + c + swnbl_cur*20;
   }
   select_window_text_y = c;
   select_window_h = select_window_text_y;

   // set bmp size and clear 
   destroy_bitmap(select_window_bmp);
   select_window_bmp = create_bitmap(select_window_w, select_window_h);
   clear(select_window_bmp);

   // title 
   rect(select_window_bmp, 0, 0, select_window_w-1, 12, palette_color[9]);
   textout_ex(select_window_bmp, font, "Selection Window", 2, 3, palette_color[9], 0);
   textout_ex(select_window_bmp, font, "Blocks  Special  X", 176, 3, palette_color[9], 0);
   textout_ex(select_window_bmp, font, "?", 172+128, 3, palette_color[9], 0);

   if (select_window_special_on)
   {
      // draw special   
      // title 
      rect(select_window_bmp, 0, select_window_special_y, select_window_w-1,
                             select_window_special_y + 12, palette_color[9]);
      textout_ex(select_window_bmp, font, "Special Items", 2, select_window_special_y+3, palette_color[9], 0);
      textout_ex(select_window_bmp, font, "+ - X", select_window_w-42, select_window_special_y+3, palette_color[9], 0);
   
      // special and frame 
      rect(select_window_bmp, 0, select_window_special_y+13, select_window_w-1,
                             select_window_special_y + select_window_num_special_lines*20+2+13, palette_color[9]);
      for (c=0; c<16*select_window_num_special_lines; c++)
      {
         if (c < 100) a = PDEi[c][1]; // bmp or ans 
         else a = 0;
         if (a < NUM_SPRITES) b = a; // bmp 
         if (a > 999) b = zz[5][a-1000]; // ans 
         draw_sprite(select_window_bmp, memory_bitmap[b], (c-((c/16)*16) )*20+1, 14+select_window_special_y+1+(c/16*20) );
      }

   }
   if (select_window_block_on)
   {
      // title 
      rect(select_window_bmp, 0, select_window_block_y, select_window_w-1,
                              select_window_block_y + 12, palette_color[9]);

      sprintf(msg, "Block Selection ");
      textout_ex(select_window_bmp, font, msg , 2, select_window_block_y+3, palette_color[9], 0);
      textout_ex(select_window_bmp, font, "+ - X", select_window_w-42, select_window_block_y+3, palette_color[9], 0);
   
      // blocks and frame 
      rect(select_window_bmp, 0, select_window_block_y+13, select_window_w-1, select_window_block_y + swnbl_cur*20+1+14, palette_color[9]);
      for (c=0; c<16*swnbl_cur; c++)
         draw_sprite(select_window_bmp, memory_bitmap[swbl[c][0]], (c-((c/16)*16) )*20+1, select_window_block_y+1+14+(c/16*20) );
   }
}


int process_select_window(void)
{
   extern int PDEi[100][32];
   extern char PDEt[100][20][40];
   int x;
   extern int select_window_active;
   
   extern int select_window_x;
   extern int select_window_y;
   extern int select_window_w;
   extern int select_window_h;
   extern int select_window_text_y;
   
   extern int select_window_block_on;
   extern int swnbl;
   extern int swnbl_cur;

   extern int select_window_block_y;
   extern int btext_draw_flag;
   
   extern int select_window_special_on;
   extern int select_window_num_special_lines;
   extern int select_window_special_y;
   extern int stext_draw_flag;
   extern int swbl[NUM_SPRITES][2];

   extern int sw_mouse_gone;

   blit(select_window_bmp, scrn_buffer, 0, 0, select_window_x, select_window_y, select_window_w, select_window_h);

   // check for mouse on whole window 
   if ((mouse_x > select_window_x) && (mouse_x < select_window_x + select_window_w)
      && (mouse_y > select_window_y) && (mouse_y < select_window_y + select_window_h))
   {

      int sys = select_window_y + select_window_special_y;
      int syb = select_window_y + select_window_block_y;
      int syt = select_window_y + select_window_text_y;
      int sxw = select_window_x + select_window_w-1;
      int vx = (mouse_x-select_window_x-2)/20; // column 
      sw_mouse_gone = 0;

      // check for mouse on top title bar 
      if (mouse_y < 14 + select_window_y)
      {
         rect(scrn_buffer, select_window_x, select_window_y, select_window_x + select_window_w-1, select_window_y + 12, palette_color[14]);
         textout_ex(scrn_buffer, font, "Selection Window", select_window_x+2, select_window_y+3, palette_color[14], 0);

         if ((mouse_x > sxw-8) && (mouse_x < sxw))  // close whole sw X 
         {
            textout_ex(scrn_buffer, font, "X", sxw-9, select_window_y+3, palette_color[14], 0);
            if (mouse_b & 1)
            {
               while (mouse_b & 1);  // wait for release 
               select_window_active = 0;
               return 1001;
            }
         }
         else textout_ex(scrn_buffer, font, "X", sxw-9, select_window_y+3, palette_color[9], 0);
         if ((mouse_x > sxw-21) && (mouse_x < sxw-13))
         {
            textout_ex(scrn_buffer, font, "?", sxw-21, select_window_y+3, palette_color[14], 0);
            if (mouse_b & 1)
            {
               while (mouse_b & 1);  // wait for release 
               help("Selection Window");
               return 1001;
            }
         }
         else textout_ex(scrn_buffer, font, "?", sxw-21, select_window_y+3, palette_color[9], 0);
         if ((mouse_x > sxw-81) && (mouse_x < sxw-25))  // Special button 
         {
            textout_ex(scrn_buffer, font, "Special", sxw-81, select_window_y+3, palette_color[14], 0);
            if (mouse_b & 1)
            {
               while (mouse_b & 1);  // wait for release 
               select_window_special_on = !select_window_special_on;
               draw_select_window();
               return 1001;
            }
         }
         else textout_ex(scrn_buffer, font, "Special", sxw-81, select_window_y+3, palette_color[9], 0);
         if ((mouse_x > sxw-144) && (mouse_x < sxw-88))  // Block button 
         {
            textout_ex(scrn_buffer, font, "Blocks", sxw-145, select_window_y+3, palette_color[14], 0);
            if (mouse_b & 1)
            {
               while (mouse_b & 1);  // wait for release 
               select_window_block_on = !select_window_block_on;
               draw_select_window();
               return 1001;
            }
         }
         else textout_ex(scrn_buffer, font, "Blocks", sxw-145, select_window_y+3, palette_color[9], 0);

         // title bar drag move! 
         if (mouse_b & 1)
         {
            int tx = (mouse_x-select_window_x); // x offset 
            int ty = (mouse_y-select_window_y); // y offset 
            xor_mode(TRUE);
            while (mouse_b & 1)
            {
               rect(screen, select_window_x, select_window_y, select_window_x + select_window_w,select_window_y + select_window_h, palette_color[9]);
               rest(5);
               rect(screen, select_window_x, select_window_y, select_window_x + select_window_w,select_window_y + select_window_h, palette_color[9]);
            // textout_ex(screen, font, "Selection Window", select_window_x+2, select_window_y+3, 9, 0);
               show_mouse(screen);
               rest(5);
               show_mouse(NULL);
               select_window_x = mouse_x-tx;
               select_window_y = mouse_y-ty;
            }
            solid_mode();
            draw_select_window();
            return 1001;
         }
      } // end of if mouse on title bar 
      else
      {
         rect(scrn_buffer, select_window_x, select_window_y, select_window_x + select_window_w-1, select_window_y + 12, palette_color[9]);
         textout_ex(scrn_buffer, font, "Selection Window", select_window_x+2, select_window_y+3, palette_color[9], 0);
         textout_ex(scrn_buffer, font, "Blocks  Special  X", sxw - 145, select_window_y+3, palette_color[9], 0);
         textout_ex(scrn_buffer, font, "?", sxw - 145+124, select_window_y+3, palette_color[9], 0);
      }
      // check for mouse on special window title bar
      if (select_window_special_on)
      {
         if ((mouse_y > sys) && (mouse_y < 14 + sys)) // on s title bar 
         {
            rect(scrn_buffer, select_window_x, sys, sxw, sys + 12, palette_color[14]);
            textout_ex(scrn_buffer, font, "Special Items", select_window_x+2, sys+3, palette_color[14], 0);

            if ((mouse_x > sxw-8) && (mouse_x < sxw))  // close special sub window 
            {
               textout_ex(scrn_buffer, font, "X", sxw-9, sys+3, palette_color[14], 0);
               if (mouse_b & 1)
                  {
                     while (mouse_b & 1);  // wait for release 
                     select_window_special_on = 0;
                     draw_select_window();
                     return 1001;
                  }
            }
            else textout_ex(scrn_buffer, font, "X", sxw-9, sys+3, palette_color[9], 0);
                    
            if ((mouse_x > sxw-25) && (mouse_x < sxw-17))  // Special button 
            {
               textout_ex(scrn_buffer, font, "-", sxw-25, sys+3, palette_color[14], 0);
               if (mouse_b & 1)
                  {
                     while (mouse_b & 1);  // wait for release 
                     if (--select_window_num_special_lines < 1 )
                     {
                        select_window_num_special_lines++;
                        select_window_special_on = 0;
                     }
                     draw_select_window();
                     return 1001;
                  }
            }
            else textout_ex(scrn_buffer, font, "-", sxw-25, sys+3, palette_color[9], 0);
            if ((mouse_x > sxw-41) && (mouse_x < sxw-33))  // Special button 
            {
               textout_ex(scrn_buffer, font, "+", sxw-41, sys+3, palette_color[14], 0);
               if (mouse_b & 1)
               {
                  while (mouse_b & 1);  // wait for release 
                  if (++select_window_num_special_lines > 4 )
                        select_window_num_special_lines = 4;
                  draw_select_window();
                  return 1001;
               }
            }
            else textout_ex(scrn_buffer, font, "+", sxw-41, sys+3, palette_color[9], 0);
         }
         else // not on s title bar 
         {
            rect(scrn_buffer, select_window_x, sys, sxw, sys + 12, palette_color[9]);
            textout_ex(scrn_buffer, font, "Special Items", select_window_x+2, sys+3, palette_color[9], 0);
         }
      } // end of if special select window on
      // check for mouse on block window title bar
      if (select_window_block_on)
      {
         if ( (mouse_y > syb) && (mouse_y < 14 + syb) ) // on title bar 
         {
            rect(scrn_buffer, select_window_x, syb, sxw, syb + 12, palette_color[14]);
            textout_ex(scrn_buffer, font, "Block Selection", select_window_x+2, syb+3, palette_color[14], 0);
            if ((mouse_x > sxw-8) && (mouse_x < sxw))  // close special sub window 
            {
               textout_ex(scrn_buffer, font, "X", sxw-9, syb+3, palette_color[14], 0);
               if (mouse_b & 1)
                  {
                     while (mouse_b & 1);  // wait for release 
                     select_window_block_on = 0;
                     draw_select_window();
                     return 1001;
                  }
            }
            else textout_ex(scrn_buffer, font, "X", sxw-9, syb+3, palette_color[9], 0);
            if ((mouse_x > sxw-25) && (mouse_x < sxw-17))  // - button 
            {
               textout_ex(scrn_buffer, font, "-", sxw-25, syb+3, palette_color[14], 0);

               if (mouse_b & 1)
               {
                  while (mouse_b & 1);  // wait for release 
                  if (--swnbl_cur < 1 )
                  {
                     swnbl_cur++;
                     select_window_block_on = 0;
                  }
                  draw_select_window();
                  return 1001;
               }

            }
            else textout_ex(scrn_buffer, font, "-", sxw-25, syb+3, palette_color[9], 0);
            if ((mouse_x > sxw-41) && (mouse_x < sxw-33))  // + button 
            {
               textout_ex(scrn_buffer, font, "+", sxw-41, syb+3, palette_color[14], 0);

               if (mouse_b & 1)
               {
                  while (mouse_b & 1);  // wait for release 
                  if (++swnbl_cur > swnbl) swnbl_cur = swnbl;
                  draw_select_window();
                  return 1001;
               }

            }
            else textout_ex(scrn_buffer, font, "+", sxw-41, syb+3, palette_color[9], 0);
         }
         else   // not on title bar 
         {
             rect(scrn_buffer, select_window_x, syb, sxw, syb + 12, palette_color[9]);
             textout_ex(scrn_buffer, font, "Block Selection", select_window_x+2, syb+3, palette_color[9], 0);
         }
      } // end of if (select_window_block_on)


      // check for mouse on special window 
      if ( (select_window_special_on) && (mouse_y > 15 + sys) && (mouse_y < 16 + sys + select_window_num_special_lines * 20) )
      {
         int vy = (mouse_y-sys-15)/20; // row 
         int ret = vy*16+vx;
         int tl = 0; // text lines 
         if (ret < 100) // dont try to show anything above PDE[99]
         {         
            // set  text length (number of lines) 
            for (x=0; x<20; x++)
               if (strcmp(PDEt[ret][x],"<end>") == 0) tl = x;
            if (tl<5) tl = 5;

            // erase and frame 
            rectfill(scrn_buffer, select_window_x, syt, sxw, 12+syt+3+(8*tl), palette_color[0]);
            rect(scrn_buffer, select_window_x, syt, sxw, 12+syt+3+(8*tl), palette_color[9]);

            // title and frame 
            rect(scrn_buffer, select_window_x, syt, sxw, syt+12, palette_color[9]);

            sprintf(msg, "Description " );
            textout_ex(scrn_buffer, font, msg,select_window_x+2, syt+3, palette_color[9], 0);

            // draw text for this pde 
            stext_draw_flag=1;
            for (x=0; x<tl; x++)
               textout_ex(scrn_buffer, font, PDEt[ret][x], select_window_x+2, select_window_y + select_window_text_y+14+(x*8), palette_color[15], 0);

   
            if (mouse_b & 1)
            {
               while (mouse_b & 1); // wait for release 
               if (PDEi[ret][0] < 200) return 3000+ret; // PUT ITEM OR ENEMY 
      
               if (PDEi[ret][0] > 199) // Creator 
               {
                  switch (PDEi[ret][0]-199)
                  {
                     case 1: create_obj(2, 1, 0); break; // type 200 - door 
                     case 2: create_obj(2, 5, 0); break; // type 201 - start 
                     case 3: create_obj(2, 3, 0); break; // type 202 - exit 
                     case 4: create_obj(2, 4, 0); break; // type 203 - key 
                     case 5: create_obj(3, 7, 0); break; // type 204 - pod 
                     case 7: create_obj(2, 10,0); break; // type 206 - msg 
                     case 8: create_obj(3, 9, 0); break; // type 207 - cloner 
                     case 9: if (create_lift()) object_viewer(4, num_lifts-1); break; // type 208 - lift 
                     int create_door(int);
                     case 10: create_door(1); break; // type 209 - 1 way fixed exit door 
                     case 11: create_door(2); break; // type 210 - 1 way linked exit door 
                     case 12: create_door(3); break; // type 211 - 2 way door set


                  }
                  draw_big(1);
                  return 1001;
               } // end of if creator
            } // end of if (mouse_b & 1)  
         }
      }  // end of mouse on special
      else // mouse not on special 
      {
         if (stext_draw_flag)
         {
            stext_draw_flag = 0;
            return 1001;
         }
      }

      // check for mouse on block window 
      if ( (select_window_block_on) && (mouse_y > 14 + syb) && (mouse_y < 14 + syb + swnbl_cur * 20))
      {
         int vy = (mouse_y-syb-14)/20; // row 
         int ret = vy*16+vx;
         int tl = 3; // text lines 
         ret = swbl[ret][0];

         // frame 
         rect(scrn_buffer, select_window_x, syt, sxw, 12+syt+3+(8*tl), palette_color[9]);

         // title and frame 
         rect(scrn_buffer, select_window_x, syt, sxw, syt+12, palette_color[9]);
         textout_ex(scrn_buffer, font, "Description",select_window_x+2, syt+3, palette_color[9], 0);

         // draw text for this pde 
         char t[80];
         btext_draw_flag=1;
         if ((ret > 127 ) && (ret < NUM_SPRITES ))
            sprintf(t,"solid");
         if ((ret > 95 ) && (ret < 128 ))
            sprintf(t,"breakable");
         if ((ret > 63 ) && (ret < 96 ))
            sprintf(t,"bombable");
         if ((ret > 31  ) && (ret < 64 ))
            sprintf(t,"semi-solid ");
         if (ret < 32 )
            sprintf(t,"empty");
         if (ret == 169 )
            sprintf(t,"map translucent");

         sprintf(msg,"Block %d - %s ", ret, t);
         textout_ex(scrn_buffer, font, msg, select_window_x+2, select_window_y + select_window_text_y+14+(1*8), palette_color[15], 0);

         textout_ex(scrn_buffer, font, "-----------------------",select_window_x+2, select_window_y + select_window_text_y+14+(0*8), palette_color[15], 0);
         textout_ex(scrn_buffer, font, "-----------------------",select_window_x+2, select_window_y + select_window_text_y+14+(2*8), palette_color[15], 0);

         if (mouse_b & 1)
         {
            while (mouse_b & 1); // wait for release 
            return ret;
         }
      } // end of mouse on block 
      else // mouse not on block 
      {
         if (btext_draw_flag)
         {
            btext_draw_flag = 0;
            return 1001;
         }
      }
   } // end of if mouse on whole window 
   else
   {
      sw_mouse_gone++;
      if (stext_draw_flag)
      {
         stext_draw_flag = 0;
         return 1001;
      }
      if (btext_draw_flag)
      {
         btext_draw_flag = 0;
         return 1001;
      }
   }
return 999;
}
