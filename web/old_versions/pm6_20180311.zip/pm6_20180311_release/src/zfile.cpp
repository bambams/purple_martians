#include <allegro.h>
#include "pm.h"

extern FILE *filepntr;

char tmp[100];

char* cmtos(int cm)
{
   sprintf(tmp, " ");
   if (cm > 31) // fire
   {
      cm -= 32;
      strcat(tmp, "[FIRE]"); 
   }
   else strcat(tmp, "[    ]");
   if (cm > 15) // jump
   {
      cm -= 16;
      strcat(tmp, "[JUMP]"); 
   }
   else strcat(tmp, "[    ]");
   if (cm > 7) // down
   {
      cm -= 8;
      strcat(tmp, "[DOWN]"); 
   }
   else strcat(tmp, "[    ]");
   if (cm > 3) // up
   {
      cm -= 4;
      strcat(tmp, "[UP]"); 
   }
   else strcat(tmp, "[  ]");
   if (cm > 1) // right
   {
      cm -= 2;
      strcat(tmp, "[RIGHT]"); 
   }
   else strcat(tmp, "[     ]");
   if (cm > 0) // left
   {
      cm -= 1;
      strcat(tmp, "[LEFT]"); 
   }
   else strcat(tmp, "[    ]");
   return tmp;  
}

void save_gm_txt(char *sfname)
{
   FILE *filepntr;
   char fname[80];
   sprintf(fname, "savegame/%s", sfname);

   replace_extension(fname, fname, "txt", sizeof(fname) );

   filepntr = fopen(fname,"w");

   fprintf(filepntr,"number of entries %d\n", game_move_entry_pos ); 
   fprintf(filepntr,"[ gm][  pc][p][cm]\n"); 

   for (int x=0; x<game_move_entry_pos; x++)
   {
      fprintf(filepntr,"[%3d][%4d]", x, game_moves[x][0]); 
      {
         if (game_moves[x][1] == 0)          
            fprintf(filepntr,"-------------START (level:%d)------------- ", game_moves[x][2]); 

         if (game_moves[x][1] == 1)
         {
            int val = game_moves[x][3];
            int p = game_moves[x][2];
            if ((val > 0) && (val < 16)) fprintf(filepntr,"-------------PLAYER %d ACTIVE (color:%d)-- ", p, val); 
            if (val > 63) fprintf(filepntr,"-------------PLAYER %d INACTIVE----------- ", p); 
         } 

         if (game_moves[x][1] == 6)          
            fprintf(filepntr,"-------------LEVEL DONE!------------------ "); 

         if (game_moves[x][1] == 5)
         {
            fprintf(filepntr,"[%d][%2d] ", game_moves[x][2], game_moves[x][3]); 
            char *tmp = cmtos(game_moves[x][3]);                          
            fprintf(filepntr,"%s", tmp); 
         }   
      }
      fprintf(filepntr,"\n"); 
   }      
   fclose(filepntr);
}

void save_gm_gm(char *sfname)
{
   char fname[80];
   sprintf(fname, "savegame/%s", sfname);
   filepntr = fopen(fname,"w");
   fprintf(filepntr,"%d\n", game_move_entry_pos);  // num_entries first
   for (int x=0; x<game_move_entry_pos; x++)
      for (int y=0; y<4; y++)
         fprintf(filepntr,"%d\n", game_moves[x][y]); 
   fclose(filepntr);
}

void save_gm()
{
   gui_fg_color = palette_color[14]; gui_bg_color = palette_color[14+224];
   char fname[1024];
   sprintf(fname, "savegame/");
   if (file_select_ex("save game filename", fname, "gm", 1024, 0, 0))
   {   
      save_gm_gm(get_filename(fname));
      save_gm_txt(get_filename(fname));
   }      
}

int load_gm(char *sfname )
{
   char fname[1024];

   sprintf(fname, "savegame/%s", sfname);
   if (!exists(fname))
   {
      //printf("%s does not exist\n", fname);
      gui_fg_color = palette_color[12]; gui_bg_color = palette_color[12+224];
      if (file_select_ex("run game filename", fname, "gm", 1024, 0, 0) == 0) return 0;
   }   

   // after all that above; do we now have a valid filename?
   if (exists(fname))
   {
      //printf("%s exists\n", fname);
      //erase old gm
      for (int x=0; x<10000; x++)
         for (int y=0; y<4; y++)
            game_moves[x][y] = 0;
      game_move_entry_pos = 0;

      int loop, ch;
      char buff[2000];
      if (filepntr=fopen(fname, "r"))
      {
         // first get number of entries
         loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
         {
            buff[loop] = ch;
            loop++;
            ch = fgetc(filepntr);
         }
         buff[loop] = 0;
         game_move_entry_pos = atoi(buff);
   
         // then get all the entries
         for (int x=0; x<game_move_entry_pos; x++)
            for (int y=0; y<4; y++)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
               {
                  buff[loop] = ch;
                  loop++;
                  ch = fgetc(filepntr);
               }
               buff[loop] = 0;
               game_moves[x][y] = atoi(buff);
            }   
         fclose(filepntr);
   
         // set play level         
         for (int x=0; x<game_move_entry_pos; x++)
            if (game_moves[x][0] == 0) // passcount 0
               if (game_moves[x][1] == 0) // type 0
               {
                  extern int play_level;
                  play_level = game_moves[x][2];
                  break; 
               }
         // init all
         for (int p=0; p<NUM_PLAYERS; p++) init_player(p, 1);
    
         // set all but 0 to inactive
         for (int p=1; p<NUM_PLAYERS; p++) players[p].active = 0;
         return 1;
      }
   }
   return 0;
}

void blind_save_game_moves(int d) 
{
   int do_save = 0;
   if ((d == 1) && (auto_save_game_on_level_done)) do_save = 1;
   if ((d == 2) && (auto_save_game_on_exit)) do_save = 1;
   if ((d == 3) && (auto_save_game_on_exit)) do_save = 1;
   if (do_save) 
   {
      char filename1[80];
      char filename2[80];
      struct tm *timenow;
      time_t now = time(NULL);
      timenow = localtime(&now);
      if (d == 1) strftime(filename1, sizeof(filename1), "level_done_%Y%m%d-%H%M%S", timenow);
      if (d == 2) strftime(filename1, sizeof(filename1), "game_exit_%Y%m%d-%H%M%S", timenow);
      if (d == 3) strftime(filename1, sizeof(filename1), "bad_exit_%Y%m%d-%H%M%S", timenow);

     // first save as a playable *.gm
      sprintf(filename2, "%s-lev%d.gm", filename1, play_level);
      save_gm_gm(filename2);

      // then as a human readable text file
      save_gm_txt(filename2);
   }
}

void save_log_file(void)
{
   if (L_LOGGING)
   {
      FILE *filepntr;
      char filename[40];
      struct tm *timenow;
      time_t now = time(NULL);
      timenow = localtime(&now);
      
      strftime(filename, sizeof(filename), "logs/%Y%m%d-%H%M%S.txt", timenow);
   
      if (strlen(log_msg) > 0)
      {
         filepntr = fopen(filename,"w");
         fprintf(filepntr, log_msg);
         fclose(filepntr);
         printf("%s saved \n", filename); 
      }   
      log_msg[0] = 0; 

   }
}


void add_log_entry_sdat_rx_and_game_move_entered(int type, int player)
{
   add_log_entry_centered_text(type, player, 76, "", "+", "-");

   int st = players1[player].sdat_total;
   int ss = players1[player].sdat_skipped;
   float sdpc=0;                 // % skipped
   if (st != 0) // prevent divide by zero
   {
      sdpc = (float)ss * 100 / (float)st;
   }   
   sprintf(msg,"sdat packets rx'd:[%3d]  skipped:[%3d][%4.1f%%%%]", st, ss, sdpc);
   add_log_entry_position_text(type, player, 76, 10, msg, "|", " ");


   int mt = players1[player].moves_entered + players1[player].moves_skipped; // moves total
   int ms = players1[player].moves_skipped;                             // moves skipped
   float mspc=0;                 // % skipped
   if (mt != 0) // prevent divide by zero
   {
      mspc = (float)ms * 100 / (float)mt;
   }   
   sprintf(msg,"moves entered:    [%3d]  skipped:[%3d][%4.1f%%%%]", mt, ms, mspc);
   add_log_entry_position_text(type, player, 76, 10, msg, "|", " ");

   add_log_entry_centered_text(type, player, 76, "", "+", "-");




}

void add_log_entry(char *txt)
{
   strcat(log_msg, txt);

 //  printf(log_msg);
}


void add_log_entry2(int type, int player, char *txt)
{
   char tmsg[200];
   sprintf(tmsg, "[%2d][%d][%d]%s", type, player, passcount, txt);
   // strcat(log_msg, tmsg);

   memcpy(log_msg + log_msg_pos, tmsg, strlen(tmsg));
   log_msg_pos += strlen(tmsg);
   log_msg[log_msg_pos+1] = 0; // NULL terminate



//   sprintf(log_msg, "%s", txt);
//   printf("%s", tmsg);
}


void add_log_entry_position_text(int type, int player, int width, int pos, char *txt, char *border, char *fill)
{
   int l = strlen(txt);
   int j1 = pos-2;
   int j2 = width - l - pos;
   char p[200];

   if (pos > 1)
   {
      strcpy(p, border);
      for (int i=0; i<j1; i++) strcat(p, fill);
      strcat(p, txt);
      for (int i=0; i<j2; i++) strcat(p, fill);
      strcat(p, border);
      strcat(p, "\n");
   }

   if (pos == 1)
   {
      j2--;
      strcpy(p, border);
      for (int i=0; i<j1; i++) strcat(p, fill);
      strcat(p, txt);
      for (int i=0; i<j2; i++) strcat(p, fill);
      strcat(p, border);
      strcat(p, "\n");
   }

   if (pos == 0)
   {
      strcpy(p, "");
      j2--;
      for (int i=0; i<j1; i++) strcat(p, fill);
      strcat(p, txt);
      for (int i=0; i<j2; i++) strcat(p, fill);
      strcat(p, border);
      strcat(p, "\n");
   }
   add_log_entry2(type, player, p);
}

void add_log_entry_centered_text(int type, int player, int width, char *txt, char *border, char *fill)
{
   int l = strlen(txt);
   int j1 = (width-l)/2 - 1;
   int j2 = j1 + 1;
   if (l % 2 == 0) j2 = j1;

   char p[200];

   strcpy(p, border);
   for (int i=0; i<j1; i++) strcat(p, fill);
   strcat(p, txt);
   for (int i=0; i<j2; i++) strcat(p, fill);
   strcat(p, border);

   strcat(p, "\n");
   add_log_entry2(type, player, p);
}

void add_log_entry_header(int type, int player, char *txt, int blank_lines)
{
   char htext[80]; // make a copy so that doesn't get overwritten
   sprintf(htext, "%s", txt);

   add_log_entry_centered_text(type, player, 76, "", "+", "-");

   for (int i=0; i<blank_lines; i++) 
      add_log_entry_centered_text(type, player, 76, "", "|", " ");

   add_log_entry_centered_text(type, player, 76, htext, "|", " ");

   for (int i=0; i<blank_lines; i++) 
      add_log_entry_centered_text(type, player, 76, "", "|", " ");

   add_log_entry_centered_text(type, player, 76, "", "+", "-");
}












































