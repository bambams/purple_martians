// e_bitmap.cpp (20100220 cleanup)
#include <allegro.h>
#include "pm.h"

// fnx prototypes 
int draw_current_bitmap(int msg, DIALOG *d, int c);
int new_draw_csp(int msg, DIALOG *d, int c);
int show_draw_mode(int msg, DIALOG *d, int c);

extern int bcmt[NUM_SPRITES];
extern int swbl[NUM_SPRITES][2];
extern int swnbl;

int show_draw_mode(int msg, DIALOG *d, int c) // show draw mode 
{
   extern int line_draw_mode;
   extern int old_line_draw_mode;

   switch (msg)
   {
      case MSG_IDLE:
         if (line_draw_mode != old_line_draw_mode)
         {
            old_line_draw_mode = line_draw_mode;
            show_mouse(NULL);
            SEND_MESSAGE(d, MSG_DRAW, 0);
            show_mouse(screen);
         }
      break;
      case MSG_DRAW:
      {
         char fmsg[80];
         // clear old 
         sprintf(fmsg,"                    ");
         textout_ex(screen, font, fmsg, 5, 230, palette_color[11], 0);
         
         // find mode 
         if (line_draw_mode == 0) sprintf(fmsg,"Point Draw");
         if (line_draw_mode == 1) sprintf(fmsg,"Line Draw");
         if (line_draw_mode == 2) sprintf(fmsg,"Framed Rectangle");
         if (line_draw_mode == 3) sprintf(fmsg,"Filled Rectangle");
         if (line_draw_mode == 4) sprintf(fmsg,"Framed Circle");
         if (line_draw_mode == 5) sprintf(fmsg,"Filled Circle");
         if (line_draw_mode == 6) sprintf(fmsg,"Flood Fill");
         if (line_draw_mode == 7) sprintf(fmsg,"Replace Color");
         if (line_draw_mode == 8) sprintf(fmsg,"New Selection");
         
         // draw it on screen 
         int tl = (strlen(fmsg)*8);
         
         int x1 = 83-tl/2;
         int x2 = 83+tl/2 + 2;
         
         int y1 = 220;
         int y2 = y1+18;
         int color = 9;
         
         // erase 
         rect(screen, 3, y1, 160, y2, palette_color[0]);
         
         rect(screen, x1, y1, x2, y2, palette_color[14]);
         textout_centre_ex(screen, font, "Draw Mode", 83+2, y1+2, palette_color[14], 0);
         textout_centre_ex(screen, font, fmsg, 83+2, y1+10, palette_color[color], 0);
         
      }
      break;
   } // end of switch case 
   return D_O_K;
}
int draw_current_bitmap(int msg, DIALOG *d, int c)
{
   extern int old_px;
   extern int old_py;
   extern int bmp_index;
   extern int cbx, cby, cbs;
   extern int slx0, sly0, slx1, sly1;

   extern int b1_color;
   extern int grid_flag;
   char tmsg[80];
   int x, y;
   switch (msg)
   {
      case MSG_IDLE:
         if ((mouse_x > cbx) && (mouse_x < cbx + (20 * cbs)) && (mouse_y > cby) && (mouse_y < cby + (20 * cbs)))
         {
            x = ((mouse_x-cbx)/cbs);
            y = ((mouse_y-cby)/cbs);
            if ((old_px != x) || (old_py != y)) // not same as last 
            {
               old_px = x;
               old_py = y;
               show_mouse(NULL);
               SEND_MESSAGE(d, MSG_DRAW, 0);
               show_mouse(screen);
            }
         }
      break;
      case MSG_DRAW:
      {
         // im going to assume cbs is always going to be 20 
         BITMAP* tmp = create_bitmap(402, 423);
         clear(tmp); 

         if ((mouse_x > cbx) && (mouse_x < cbx + (20 * cbs)) && (mouse_y > cby) && (mouse_y < cby + (20 * cbs)))
         {
            x = ((mouse_x-cbx)/cbs);
            y = ((mouse_y-cby)/cbs);

            sprintf(tmsg,"x:%-2d ",x);
            textout_ex(tmp, font, tmsg, 1+1, 12+(20*cbs)+2, palette_color[15], 0);
            sprintf(tmsg,"y:%-2d ",y);
            textout_ex(tmp, font, tmsg, 1+40, 12+(20*cbs)+2, palette_color[15], 0);
            c = getpixel(memory_bitmap[bmp_index], x, y);
            sprintf(tmsg,"color:%-2d ",c);
            textout_ex(tmp, font, tmsg, 1+80, 12+(20*cbs)+2, palette_color[15], 0);

            // show color 
            rectfill(tmp, 1+156, 12+(20*cbs)+1, 1+195, 12+(20*cbs)+10, palette_color[c]);

            // frame all 
            rect(tmp, 1-1, 12+(20*cbs), 1+196, 12+(20*cbs)+10, palette_color[15]);

         }
         else rectfill(tmp, 1-1, 12+(20*cbs)+1, 1+180, 12+(20*cbs)+11, palette_color[0]);
   
         c = bcmt[bmp_index];
         sprintf(tmsg,"map color:%-2d ",c);
         textout_ex(tmp, font, tmsg, 1+252, 12+(20*cbs)+2, palette_color[15], 0);
   
         // show color 
         rectfill(tmp, 1+360, 12+(20*cbs)+1, 1+399, 12+(20*cbs)+10, palette_color[c]);
   
         // frame all 
         rect(tmp, 1+250, 12+(20*cbs), 1+400, 12+(20*cbs)+10, palette_color[15]);
   
   
         // title and frame 
         sprintf(tmsg,"Bitmap # %-3d ",bmp_index);
         textout_ex(tmp, font, tmsg, 1+1,12-9, palette_color[15], 0);
         rect(tmp, 1+100, 12-11, 1-1, 12-1, palette_color[15]);
         rect(tmp, 1-1, 12-1, 1+(20*cbs), 12+(20*cbs), palette_color[15]);

         for (y=0; y<20; y++)  // draw the big image 
            for (x=0; x<20; x++)
            {
               rectfill(tmp,((x*cbs)+1),(y*cbs)+12,((x*cbs)+1+cbs-1),((y*cbs)+12+cbs-1),getpixel(memory_bitmap[bmp_index],x,y));
               if (grid_flag) rect(tmp,((x*cbs)+1),(y*cbs)+12,((x*cbs)+1+cbs),((y*cbs)+12+cbs),palette_color[15+128] );
            }
         // show selection 
         for (c=0; c<4; c++)
            rect(tmp, 1+(slx0*cbs)+c, 12+(sly0*cbs)+c, 1+(slx1*cbs)-1-c, 12+(sly1*cbs)-1-c, palette_color[14+(c*32)] );

//         show_mouse(NULL);
         blit(tmp, screen, 0, 0, cbx-1, cby-12, 402, 423);
//         show_mouse(screen);
         destroy_bitmap(tmp);

      }
      break;
      case MSG_CLICK:
         x = ((mouse_x-cbx)/cbs);
         y = ((mouse_y-cby)/cbs);
         if (mouse_b & 1)
         {
            extern int line_draw_mode;
            extern int zzindx;

            BITMAP *temp = NULL;
            extern int cbx;
            extern int cby;
            extern int cbs;
            int omx, omy;
            int x1, y1, x2, y2;

            if (key[KEY_M] )  // set map color 
            {
               bcmt[bmp_index] = b1_color;
               return D_REDRAW;
            }

            temp = create_bitmap(20,20);
            set_clip_rect(temp, 0,0,20,20);
            clear(temp);
            omx = mouse_x;
            omy = mouse_y;

            x1 = x; x2 = x;
            y1 = y; y2 = y;

            while (mouse_b  & 1)
            {
               int x4, y4;

               x2 = x1 - (omx - mouse_x)/cbs;
               y2 = y1 - (omy - mouse_y)/cbs;
               clear(temp);

               int sel_color = b1_color;

               if (b1_color == 0) sel_color = 15+128;

               switch (line_draw_mode)
               {
                  case 1: line       (temp, x1, y1, x2, y2, sel_color); break;
                  case 2: rect       (temp, x1, y1, x2, y2, sel_color); break;
                  case 3: rectfill   (temp, x1, y1, x2, y2, sel_color); break;
                  case 4: circle     (temp, x2, y1, y2-y1, sel_color); break;
                  case 5: circlefill (temp, x2, y1, y2-y1, sel_color); break;
               }
               show_mouse(NULL);

               // draw original on screen 
               for (x4=0; x4<20; x4++)
                  for (y4=0; y4<20; y4++)
                     rectfill(screen,((x4*cbs)+cbx), (y4*cbs)+cby, (x4*cbs)+cbx+cbs-1, (y4*cbs)+cby+cbs-1, getpixel(memory_bitmap[bmp_index],x4,y4) );

               if (line_draw_mode != 8)
               {
                  // draw temp on screen 
                  for (x4=0; x4<20; x4++)
                     for (y4=0; y4<20; y4++)
                        if (getpixel(temp,x4,y4)) rectfill(screen,((x4*cbs)+cbx), (y4*cbs)+cby, (x4*cbs)+cbx+cbs-1, (y4*cbs)+cby+cbs-1, getpixel(temp,x4,y4) );
                  show_mouse(screen);
               }

               if (line_draw_mode == 8)
               {
                  if (x1>19) x1 = 19;
                  if (y1>19) y1 = 19;
                  if (x2>19) x2 = 19;
                  if (y2>19) y2 = 19;
                  if (x1<0) x1 = 0;
                  if (y1<0) y1 = 0;
                  if (x2<0) x2 = 0;
                  if (y2<0) y2 = 0;
                  // show selection 
                  for (c=0; c<4; c++)
                     rect(screen, cbx+(x1*cbs)+c, cby+(y1*cbs)+c, cbx+((x2+1)*cbs)-1-c, cby+((y2+1)*cbs)-1-c, palette_color[14+(c*32)]);
                  rest(100);
               }

               if ((mouse_b & 2) || (key[KEY_ESC]))
               {
                  destroy_bitmap(temp);
                  return D_REDRAW;
               }

            } // end of while mouse b1
            switch (line_draw_mode)
            {
               case 0: putpixel  (memory_bitmap[bmp_index], x, y, b1_color); break;
               case 1: line      (memory_bitmap[bmp_index], x1, y1, x2, y2, b1_color); break;
               case 2: rect      (memory_bitmap[bmp_index], x1, y1, x2, y2, b1_color); break;
               case 3: rectfill  (memory_bitmap[bmp_index], x1, y1, x2, y2, b1_color); break;
               case 4: circle    (memory_bitmap[bmp_index], x2, y1, y2-y1, b1_color); break;
               case 5: circlefill(memory_bitmap[bmp_index], x2, y1, y2-y1, b1_color); break;
               case 6: floodfill (memory_bitmap[bmp_index], x1, y1, b1_color); break;
               case 8: // new selection 
               {
                  if (x1>x2)
                  {
                     int ti = x2;
                     x2 = x1;
                     x1 = ti;
                  }
                  if (y1>y2)
                  {
                     int ti = y2;
                     y2 = y1;
                     y1 = ti;
                  }

                  if (x1>19) x1 = 19;
                  if (y1>19) y1 = 19;
                  if (x2>19) x2 = 19;
                  if (y2>19) y2 = 19;
                  if (x1<0) x1 = 0;
                  if (y1<0) y1 = 0;
                  if (x2<0) x2 = 0;
                  if (y2<0) y2 = 0;

                  slx0 = x1;
                  sly0 = y1;
                  slx1 = x2+1;
                  sly1 = y2+1;
               }
               break;
               case 7: // replace color 
               {
                  int rc, xx, yy, azz, bzz;
                  rc = getpixel(memory_bitmap[bmp_index], x, y);
                  line_draw_mode = 0;
                  for (bzz=0; bzz<16; bzz++)
                     if ((zz[4][zzindx]) > (bzz - 1))  // is shape in seq? 
                     {
                        azz=zz[ 5+bzz][zzindx];
                        for (yy=0; yy<20; yy++)
                           for (xx=0; xx<20; xx++)
                              if (getpixel(memory_bitmap[azz], xx, yy) == rc)
                                  putpixel(memory_bitmap[azz], xx, yy, b1_color);
                     }
                  for (yy=0; yy<20; yy++) // do the current in case its not in seq 
                     for (xx=0; xx<20; xx++)
                        if (getpixel(memory_bitmap[bmp_index], xx, yy) == rc)
                           putpixel(memory_bitmap[bmp_index], xx, yy, b1_color);
                  while (mouse_b  & 1); // wait for release 
                  return D_REDRAW;
               }
               break;
            } // end of switch (line_draw_mode) 
            destroy_bitmap(temp);
            return D_REDRAW;
         }  // end of if (mouse_b & 1) 
         if (mouse_b & 2)
         {
            while (mouse_b  & 2); // wait for release 
            b1_color = getpixel(memory_bitmap[bmp_index], x, y);
            return D_REDRAW;
         }
      break; // end of case MSG_CLICK
   }
   return D_O_K;
}
int new_draw_csp(int msg, DIALOG *d, int c)
{
   extern int cspx, cspy, csps;
   extern int b1_color;
   char tmsg[80];
   int x,y;
   switch (msg)
   {
      case MSG_DRAW:
      { 
         // assume csps is always 10
         BITMAP* tmp = create_bitmap(162, 184);
         clear(tmp); 
         for (y=0; y<16; y++)
            for (x=0; x<16; x++)
               rectfill(tmp, 1+(x*csps), 12+(y*csps), 1+((x+1)*csps), 12+((y+1)*csps), palette_color[(y*16)+x]);
  
         rect(tmp, 1-1, 12-1, 1+(16*csps), 12+(16*csps),palette_color[11]);
         rect(tmp, 1-1, 12-1, 1+(16*csps), 12+(16*csps)+10,palette_color[15]);
         rect(tmp, 1+60, 12-11, 1-1, 12-1, palette_color[15]);
         textout_ex(tmp, font, "Palette", 1+1,12-9, palette_color[15], 0);
        
         sprintf(tmsg,"Color=%-3d",b1_color);
         textout_ex(tmp, font, tmsg, 1+1, 12+(16*csps)+2, 15, 0);
         rectfill(tmp, 1+(8*9), 12+(16*csps)+1,1+(16*csps)-1, 12+(16*csps)+9, palette_color[b1_color]);
 
         blit(tmp, screen, 0, 0, cspx-1, cspy-12, 162, 184);
         destroy_bitmap(tmp);
      }
      break;
      case MSG_CLICK:
         b1_color = ((mouse_x-cspx) / csps) + ((mouse_y - cspy) / csps) * 16;
         while (mouse_b & 1); // wait for release 
         return D_REDRAW;
      break;
   }
   return D_O_K;
}






















































int draw_animation(int msg, DIALOG *d, int c)
{
   extern int zzindx;
   extern int bmp_index;
   char tmsg[80];
   int e;
   switch (msg)
   {
      case MSG_DRAW:
         sprintf(tmsg,"Animation Sequence # %-2d ",zzindx);
         textout_ex(screen, font, tmsg, 4,446, palette_color[15], 0);
         rect(screen, 190, 443, 2, 454, palette_color[15]);
         rect(screen, 2, 454, 323, 476, palette_color[15]);
         for (e = 0; e < 16; e++)   // show current seq shapes 
            if ((zz[4][zzindx]) > (e - 1))  // is shape in seq? 
               blit(memory_bitmap[zz[ 5+e][zzindx]],screen,0,0,3+e*20,456,20,20);
      break;
      case MSG_CLICK:
         bmp_index = zz[5 + ((mouse_x-3)/20)][zzindx];
         return D_REDRAW;
      break;
   }
   return D_O_K;
}
int color_bars(int msg, DIALOG *d, int c)
{
   extern PALLETE pallete;
   extern int b1_color;
   char tmsg[80];
   int e;
   switch (msg)
   {
      case MSG_DRAW:
         pallete[252].r = pallete[b1_color].r; // set temp color to red value 
         pallete[252].g = 0;
         pallete[252].b = 0;
         pallete[253].r = 0;
         pallete[253].g = pallete[b1_color].g; // set temp color to green value 
         pallete[253].b = 0;
         pallete[254].r = 0;
         pallete[254].g = 0;
         pallete[254].b = pallete[b1_color].b; // set temp color to blue value 
         
         set_pallete(pallete);
         
         rectfill(screen, 320, 60,  639, 99,  palette_color[252]);
         rect    (screen, 320, 60,  639, 99,  palette_color[15] );
         
         rectfill(screen, 320, 100, 639, 139, palette_color[253]);
         rect    (screen, 320, 100, 639, 139, palette_color[15] );
         
         rectfill(screen, 320, 140, 639, 179, palette_color[254]);
         rect    (screen, 320, 140, 639, 179, palette_color[15] );
         
         sprintf(tmsg,"Red   = %-2d",pallete[b1_color].r);
         textout_ex(screen, font, tmsg, 220, 75, palette_color[15], 0);
         e = (pallete[b1_color].r * 5) + 320;
         rectfill(screen, e, 60, e+3, 99, palette_color[15]);
         
         
         sprintf(tmsg,"Green = %-2d",pallete[b1_color].g);
         textout_ex(screen, font, tmsg, 220, 115, palette_color[15], 0);
         e = (pallete[b1_color].g * 5) + 320;
         rectfill(screen, e, 100, e+3, 139, palette_color[15]);

         
         sprintf(tmsg,"Blue  = %-2d",pallete[b1_color].b);
         textout_ex(screen, font, tmsg, 220, 155, palette_color[15], 0);
         e = (pallete[b1_color].b * 5) + 320;
         rectfill(screen, e, 140, e+3, 179, palette_color[15]);
         
         rectfill (screen, 320, 200, 639, 380, palette_color[b1_color]);
         
      break;

      case MSG_CLICK:
         // get rid of bars 
         rectfill(screen, 320, 60,  639, 99,  palette_color[252]);
         rect    (screen, 320, 60,  639, 99,  palette_color[15] );
         
         rectfill(screen, 320, 100, 639, 139, palette_color[253]);
         rect    (screen, 320, 100, 639, 139, palette_color[15] );
         
         rectfill(screen, 320, 140, 639, 179, palette_color[254]);
         rect    (screen, 320, 140, 639, 179, palette_color[15] );
         while (mouse_b & 1)
         {
            if ((mouse_y >  60) && (mouse_y < 100) ) pallete[b1_color].r = ((mouse_x - 320) / 5 );// red bar 
            if ((mouse_y > 100) && (mouse_y < 140) ) pallete[b1_color].g = ((mouse_x - 320) / 5 );// green bar 
            if ((mouse_y > 140) && (mouse_y < 180) ) pallete[b1_color].b = ((mouse_x - 320) / 5 );// blue bar 
            
            if (pallete[b1_color].r > 63) pallete[b1_color].r = 63;
            if (pallete[b1_color].g > 63) pallete[b1_color].g = 63;
            if (pallete[b1_color].b > 63) pallete[b1_color].b = 63;
            show_mouse(NULL);
            
            sprintf(tmsg,"Red   = %-2d",pallete[b1_color].r);
            textout_ex(screen, font, tmsg, 220, 75, palette_color[15], 0);
            
            xor_mode(TRUE);
            e = (pallete[b1_color].r * 5) + 320;
            rectfill(screen, e, 60, e+3, 99, palette_color[127]);
            rest(10);
            e = (pallete[b1_color].r * 5) + 320;
            rectfill(screen, e, 60, e+3, 99, palette_color[127]);
            xor_mode(FALSE);
            
            
            sprintf(tmsg,"Green = %-2d",pallete[b1_color].g);
            textout_ex(screen, font, tmsg, 220, 115, palette_color[15], 0);
            
            xor_mode(TRUE);
            e = (pallete[b1_color].g * 5) + 320;
            rectfill(screen, e, 100, e+3, 139, palette_color[127]);
            rest(10);
            e = (pallete[b1_color].g * 5) + 320;
            rectfill(screen, e, 100, e+3, 139, palette_color[127]);
            xor_mode(FALSE);
            
            
            sprintf(tmsg,"Blue  = %-2d",pallete[b1_color].b);
            textout_ex(screen, font, tmsg, 220, 155, palette_color[15], 0);
            
            xor_mode(TRUE);
            e = (pallete[b1_color].b * 5) + 320;
            rectfill(screen, e, 140, e+3, 179, palette_color[127]);
            rest(10);
            e = (pallete[b1_color].b * 5) + 320;
            rectfill(screen, e, 140, e+3, 179, palette_color[127]);
            xor_mode(FALSE);
            
            show_mouse(screen);


            pallete[252].r = pallete[b1_color].r; // set temp color to red value 
            pallete[252].g = 0;
            pallete[252].b = 0;
            pallete[253].r = 0;
            pallete[253].g = pallete[b1_color].g; // set temp color to green value 
            pallete[253].b = 0;
            pallete[254].r = 0;
            pallete[254].g = 0;
            pallete[254].b = pallete[b1_color].b; // set temp color to blue value 
            
            
            set_pallete(pallete);
         }
         return D_REDRAW;
      break;
   }
   return D_O_K;
}

int fade_proc(int msg, DIALOG *d, int c)
{
   extern int b1_color;
   extern PALLETE pallete;
   int ret;
   ret =  d_button_proc(msg, d, c);
   if (ret == D_CLOSE)
   {
      if (b1_color < 16)
      {
         int x;
         int cn = b1_color;
         float ns = 15;
         for (x=0; x<ns; x++)
         {
            pallete[cn+(x*16)].r = (unsigned char) ( pallete[cn].r * (1 - (x/ns)) );
            pallete[cn+(x*16)].g = (unsigned char) ( pallete[cn].g * (1 - (x/ns)) );
            pallete[cn+(x*16)].b = (unsigned char) ( pallete[cn].b * (1 - (x/ns)) );
         }
         set_pallete(pallete);
      }
      return D_REDRAW;
   }
   return ret;
}

int select_bitmap_ans()
{
   extern int bmp_index;
   int quit = 0;
   textout_ex(scrn_buffer, font, "Select a Bitmap with b1 ", 0, 700,  palette_color[9], 0);
   textout_ex(scrn_buffer, font, "b2 or ESC to exit              ", 0, 710,  palette_color[9], 0);
   // draw 32x32 bitmaps
   for (int y = 0; y < 32; y++)
      for (int x = 0; x < 32; x++)
         blit(memory_bitmap[x+(y*32)], scrn_buffer, 0, 0, (x*20), (y*20), 20, 20);
   blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
   show_mouse(screen);
   while (!quit)
   {
      if ((mouse_y < 640) && (mouse_x < 640))
      {
         int pointer = (mouse_x/20) + (mouse_y/20) * 32 ;
         sprintf(msg,"pointer %-2d  ", pointer );
         textout_ex(scrn_buffer, font, msg, 0, 680, palette_color[4], 0);
         blit (memory_bitmap[pointer], scrn_buffer, 0, 0, 95, 671, 20, 20);

         if (mouse_b & 1)
         {
            while (mouse_b & 1);
            bmp_index = pointer;
            return 1;
         }
      }   
      while ((key[KEY_ESC]) || (mouse_b & 2)) quit = 1; 
   } // end of while not quit
   show_mouse(NULL);
   return -1;
}
int animation_proc()
{
   extern int zzindx;
   extern int bmp_index;
   int pointer = zzindx;
   int as_quit = 0;
   int quit = 0;
   int c, x;
   show_mouse(NULL);
   clear(screen);
   clear(scrn_buffer);

   while (!quit)
   {
      sprintf(msg,"Animation Sequence Editor");
      textout_centre_ex(scrn_buffer, font, msg, 320, 20, palette_color[10], 0);
      sprintf(msg,"Get New Shapes");
      textout_ex(scrn_buffer, font, msg, 0, 260, palette_color[10], 0);
      sprintf(msg,"Passcount Delay %d  ",zz[3][zzindx]);
      textout_ex(scrn_buffer, font, msg, 0, 280, palette_color[9], 0);
      if (key[KEY_DEL])
      {
         for (c=0;c<20;c++)
            zz[c][zzindx] = 0;
         clear(scrn_buffer);
      }
      if ((mouse_y < 190)  && (mouse_x < 642))
      {
         pointer = (mouse_x-2) / 20 + (mouse_y-30) / 20 * 32;
         if (pointer < 0) pointer = 0;
         if (pointer > NUM_ANS-1) pointer = NUM_ANS-1;
      }
      if (mouse_b & 1)
      {
         if ((mouse_y < 190)  && (mouse_x < 642))
         {
            zzindx = pointer;
            clear(scrn_buffer);
         }
         // edit delay 
         if ( (mouse_y > 280) && (mouse_y < 288) && (mouse_x < 150) )
            if (edit_int(128, 280, zz[3][zzindx], 1, 0, 100))
               zz[3][zzindx] = edit_int_retval;

         if ( (mouse_y > 260) && (mouse_y < 268) && (mouse_x < 120) )
         {   // get new shapes  
            while (mouse_b & 1);
            zz[4][zzindx] = 0;
            as_quit = 0;
            while (!as_quit)
            {
               clear(scrn_buffer);
               sprintf(msg, "Get Shape #%d ", zz[4][zzindx] );
               textout_ex(scrn_buffer, font, msg, 0, 620, palette_color[10], 0);
    
               x = select_bitmap_ans();
               if (x == 1) // good return b1 
               {
                  zz[5 + zz[4][zzindx]][zzindx] = bmp_index;
                  //rest(300); // to prevent repeat 
                  zz[4][zzindx]++; // set last shape to point at next 
               }
               if (x == -1)  // abort esc 
               {
                  zz[4][zzindx]--;
                  as_quit=1;
               }
            }
            clear(scrn_buffer);
         }
      }
      for (c = 0; c < zz[4][zzindx] + 1; c++)   // show current seq shapes 
         if (( zz[5+c][zzindx] < NUM_SPRITES) && (zz[5+c][zzindx] > 0))
            blit(memory_bitmap[ zz[5+c][zzindx] ], scrn_buffer, 0, 0, c*20, 220, 20, 20);
      sprintf(msg,"Current Sequence %d  ",zzindx);
      textout_ex(scrn_buffer, font, msg, 0, 210, palette_color[13], 0);
      sprintf(msg,"Pointer %d  ",pointer );
      textout_ex(scrn_buffer, font, msg, 0, 194, palette_color[9], 0);
      rect(scrn_buffer, 0, 219, 322, 240, palette_color[13]);
      rect(scrn_buffer, 0, 29, 642, 190, palette_color[9]);

      for (c=0; c < 32; c++)   // draw 32x8 
         for (x=0; x < 8; x++)
            if (zz[4][c + (x * 32)] != 0)
               if ((zz[0][c + (x * 32)] < NUM_SPRITES) && (zz[0][c + (x * 32)] > 0 ))
                  blit(memory_bitmap[zz[0][c + (x * 32)]], scrn_buffer, 0, 0, 2+c*20, 30+x*20, 20, 20);
      update_animation();

      show_mouse(scrn_buffer);
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      clear(scrn_buffer);
      show_mouse(NULL);
      rest(20);

      while ((key[KEY_ESC]) || (mouse_b & 2)) quit = 1;
   }
   return D_REDRAW;
}


int select_bitmap_proc()
{
   extern int bmp_index;
   int x, y;
   int quit = 0;
   int redraw = 1;
   int view_attrib = 0;
   int button_x1 = 400;
   int button_x2 = 639;
   int button_xc = 520;
   int button_y = 650;
   int jh;
   int b2mode = 0;

   show_mouse(NULL);
   clear(screen);
   clear(scrn_buffer);

   while (!quit)
   {
      if (redraw)
      {
         textout_ex(scrn_buffer, font, "Select a Bitmap 333with b1 ", 0, 700, palette_color[9], 0);
         redraw = 0; 

         // draw 32x32 bitmaps  
         for (x = 0; x < 32; x++)
            for (y = 0; y < 32; y++)
            {
               int color = 240; // normal color = white 
               blit(memory_bitmap[x+(y*32)], scrn_buffer, 0, 0, (x*20), (y*20), 20, 20);
               if (view_attrib)
               {
                  if (sa[x+(y*32)][1]) color = 10; // locked color = red 
                  if (sa[x+(y*32)][0] == 0) textout_ex(scrn_buffer, font, "E", (x*20)+4, (y*20)+4, palette_color[color], 0);
                  if (sa[x+(y*32)][0] == 1) textout_ex(scrn_buffer, font, "B", (x*20)+4, (y*20)+4, palette_color[color], 0);
                  if (sa[x+(y*32)][0] == 2) textout_ex(scrn_buffer, font, "S", (x*20)+4, (y*20)+4, palette_color[color], 0);
               }
            }
      }   
      if ((mouse_y < 640) && (mouse_x < 640))
      {
         int pointer = (mouse_x/20) + (mouse_y/20) * 32 ;
         sprintf(msg,"pointer %-2d  ", pointer );
         textout_ex(scrn_buffer, font, msg, 0, 680, palette_color[4], 0);
         blit (memory_bitmap[pointer], scrn_buffer, 0, 0, 95, 671, 20, 20);
         if (mouse_b & 1)
         {
            redraw = 1; 
            if (view_attrib)
            {
               int bx1 = mouse_x/20;
               int by1 = mouse_y/20;
               int bx2 = mouse_x/20;
               int by2 = mouse_y/20;
               int old_mouse_x = mouse_x;
               int old_mouse_y = mouse_y;
               int cx;
               int cy;
               xor_mode(TRUE);
               while (mouse_b & 1) // trap while b1 is held 
               {
                  bx2 = bx1 + ((mouse_x - old_mouse_x)/20);
                  by2 = by1 + ((mouse_y - old_mouse_y)/20);

                  rect(scrn_buffer, (bx1)*20, (by1)*20, (bx2)*20, (by2)*20, palette_color[15]);
                  show_mouse(scrn_buffer);
                  blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
                  show_mouse(NULL);

                  rest(mouse_loop_pause);

                  rect(scrn_buffer, (bx1)*20, (by1)*20, (bx2)*20, (by2)*20, palette_color[15]);
                  show_mouse(scrn_buffer);
                  blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
                  show_mouse(NULL);

                  rest(mouse_loop_pause);

               }
               xor_mode(FALSE);
               // limits 
               if (bx1>32) bx1 = 32;
               if (bx2>32) bx2 = 32;
               if (by1>32) by1 = 32;
               if (by2>32) by2 = 32;
               // ensure top-right, bottom left format 
               if (bx1 > bx2)
               {
                  int temp = bx2;
                  bx2 = bx1;
                  bx1= temp;
               }
               if (by1 > by2)
               {
                  int temp = by2;
                  by2 = by1;
                  by1= temp;
               }
               // cycle the selection 
               for (cx = bx1; cx < bx2; cx++)
                  for (cy = by1; cy < by2; cy++)
                  {
                     if (b2mode< 3) sa[cx+(cy*32)][0] = b2mode;
                     if ((b2mode> 2) && (b2mode < 5)) sa[cx+(cy*32)][1] = b2mode-3;
                  }
            }
            if (!view_attrib)  // old b1 behaviour 
            {
               bmp_index = (mouse_x/20) + (mouse_y/20) * 32;
               quit = 1;
            }
         }
      }
      else rectfill(scrn_buffer, 0, 351, 115, 371, palette_color[0]);


      jh=1;
      rect(scrn_buffer, button_x1, button_y+(jh*12), button_x2, button_y+(jh*12)+10, palette_color[15]);
      if (view_attrib) sprintf(msg,"View Attributes:ON ");
      else sprintf(msg,"View Attributes:OFF");
      textout_centre_ex(scrn_buffer, font, msg, button_xc, button_y+(jh*12)+2, palette_color[13], 0);

      jh=2;
      rect(scrn_buffer, button_x1, button_y+(jh*12), button_x2, button_y+(jh*12)+10, palette_color[15]);
      if (b2mode == 0) sprintf(msg,"  Empty  ");
      if (b2mode == 1) sprintf(msg,"  Block  ");
      if (b2mode == 2) sprintf(msg," Special ");
      if (b2mode == 3) sprintf(msg," Unlock ");
      if (b2mode == 4) sprintf(msg,"  Lock  ");
      textout_centre_ex(scrn_buffer, font, msg, button_xc, button_y+(jh*12)+2, palette_color[13], 0);
   
      if (mouse_b & 1) 
      {
         redraw = 1;
         while (mouse_b & 1); // wait for release 
         if ((mouse_x > button_x1) && (mouse_x < button_x2) && (mouse_y > button_y) && (mouse_y < button_y+(4*12) ))
         {
            int mb = (mouse_y - button_y) / 12;
            switch(mb)
            {
               case 1: view_attrib = !view_attrib; break;
               case 2: if (++b2mode>4) b2mode = 0; break;
               break;
            }
         }
      }  
      show_mouse(scrn_buffer);
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      show_mouse(NULL);
      rest(mouse_loop_pause);
      while ((key[KEY_ESC]) || (mouse_b & 2)) quit = 1; 
   }
   return D_REDRAW;
}

int copy_bitmap_proc()
{
   extern int bmp_index;
   int quit = 0;
   int redraw = 1;

   show_mouse(NULL);
   clear(screen);
   clear(scrn_buffer);

   while (!quit)
   {
      if (redraw)
      {
         textout_ex(scrn_buffer, font, "b1 to put   ", 0, 694, palette_color[9], 0);
         textout_ex(scrn_buffer, font, "b2 to get   ", 0, 702, palette_color[9], 0);
         textout_ex(scrn_buffer, font, "esc to quit ", 0, 710, palette_color[9], 0);

         redraw = 0;
         // draw 32x32 bitmaps  
         for (int y = 0; y < 32; y++)
            for (int x = 0; x < 32; x++)
               blit(memory_bitmap[x+(y*32)], scrn_buffer, 0, 0, (x*20), (y*20), 20, 20);
      }

      if ((mouse_y < 640) && (mouse_x < 640))
      {
         int pointer = (mouse_x/20) + (mouse_y/20) * 32 ;
         sprintf(msg,"pointer %-2d  ", pointer );
         textout_ex(scrn_buffer, font, msg, 0, 680, palette_color[4], 0);
         blit (memory_bitmap[pointer], scrn_buffer, 0, 0, 95, 671, 20, 20);
         if (mouse_b & 2) bmp_index = pointer;
         if (mouse_b & 1)
         {
            blit (memory_bitmap[bmp_index], memory_bitmap[pointer], 0, 0, 0, 0, 20, 20);
            redraw = 1;
         }  
      }
      else rectfill(scrn_buffer, 0, 351, 115, 371, palette_color[0]);


      show_mouse(scrn_buffer);
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      show_mouse(NULL);
      rest(mouse_loop_pause);
      while (key[KEY_ESC]) quit = 1;
   }
   return D_REDRAW;
}

DIALOG edit_pallete_dialog[] =
{
   // (dialog proc)     (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)  (d2)  (dp) 
   { d_clear_proc,      0,    0,    192,  172,  255,  0,    0,    0,       0,    0,    NULL },
   { d_ctext_proc,      320,  1,   0,     0,    10,   0,    0,    0,       0,    0,    (void *)"Pallete Editor" },
   { new_draw_csp,      3,     40,  160,  160,  9,    0,    0,    0,       0,    0,    NULL },
   { color_bars,        320,   60,  320,  120,  9,    0,    0,    0,       0,    0,    NULL },
   { fade_proc,         180,  400,  160,  48,   9,    0,    0,    D_EXIT,  0,    0,    (void *)"Fade" },
   { d_button_proc,     360,  400,  160,  48,   9,    0,    0,    D_EXIT,  0,    0,    (void *)"Exit" },
   { NULL,              0,    0,    0,    0,    0,    0,    0,    0,       0,    0,    NULL }
};

int edit_pallete_proc()
{
   do_dialog(edit_pallete_dialog, -1);
   return D_REDRAW;
}


MENU next_bitmap_menu[] =
{
   { "Select Bitmap",         select_bitmap_proc,     NULL },
   { "Copy Bitmap",           copy_bitmap_proc,       NULL },
   { NULL,                       NULL,                  NULL }
};

MENU modify_selection_menu[] =
{
   { "Mirror X",                bm_flip_x_axis_proc,    NULL },
   { "Mirror Y",                bm_flip_y_axis_proc,    NULL },
   { "Scroll Up",               bm_scroll_up_proc,      NULL },
   { "Scroll Down",             bm_scroll_down_proc,    NULL },
   { "Scroll Left",             bm_scroll_left_proc,    NULL },
   { "Scroll Right",            bm_scroll_right_proc,   NULL },
   { "Rotate 90 deg",           bm_rot_proc,            NULL },
   { NULL,                      NULL,                   NULL }
};
MENU bitmap_file_menu[] =
{
   { "&Load Sprit File",         load_sprit_proc,     NULL },
   { "&Save Sprit File",         save_sprit_proc,     NULL },
   { "&Palette",                 edit_pallete_proc,   NULL },
   { "&Animation",               animation_proc,      NULL },
   { NULL,                       NULL,                NULL }
};
MENU selection_menu[] =
{
   { "New Selection",         new_selection_proc,    NULL },
   { "Select All",            select_all_proc,       NULL },
   { "Gridlines",             gridlines_proc,         NULL },
   { NULL,                       NULL,                NULL }
};
MENU draw_mode_menu1[] =
{
   { "Replace Color",         replace_color_proc,     NULL },
   { "Line Draw",             line_draw_proc,         NULL },
   { "Rectangle Draw",        rect_draw_proc,         NULL },
   { "Filled Rectangle",      rectfill_draw_proc,     NULL },
   { "Circle Draw",           circle_draw_proc,       NULL },
   { "Filled Circle",         circlefill_draw_proc,   NULL },
   { "Floodfill",             floodfill_draw_proc,    NULL },

   { NULL,                       NULL,                NULL }
};
MENU top_bitmap_menu[] =
{
   { "&File",                    NULL,              bitmap_file_menu },
   { "&Bitmap"  ,                NULL,              next_bitmap_menu },
   { "&Draw Mode"  ,             NULL,              draw_mode_menu1 },
   { "&Selection"  ,             NULL,              selection_menu },
   { "&Modify Selection"  ,      NULL,              modify_selection_menu },
   { "&Quit",                    quit_proc,         NULL },
   { NULL,                       NULL,              NULL }
};
DIALOG bitmap_dialog[] =
{
   // (dialog proc)       (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)  (d2)  (dp) 
   { d_clear_proc,        0,     0,   0,     0,    0,  0,    0,    0,       0,    0,    NULL },
   { d_ctext_proc,      320,     0,   0,     0,    10, 0,    0,    0,       0,    0,    (void *)" Bitmap Editor" },
   { d_menu_proc,         1,    10,   0,     0,    9,  0,    0,    0,       0,    0,    top_bitmap_menu },

   { show_draw_mode,      3,   220,  160,  160,    9,  0,    0,    0,       0,    0,    NULL },


   { rb1_proc,           20,   244,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    (void *)"Point Draw" },
   { rb2_proc,           20,   256,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    (void *)"Line Draw" },
   { rb3_proc,           15,   268,  130,    10,  9,  0,    0,    D_EXIT,  0,    0,    (void *)"Framed Rectangle" },
   { rb4_proc,           15,   280,  130,    10,  9,  0,    0,    D_EXIT,  0,    0,    (void *)"Filled Rectangle" },
   { rb5_proc,           20,   292,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    (void *)"Framed Circle" },
   { rb6_proc,           20,   304,  120,    10,  9,  0,    0,    D_EXIT,  0,    0,    (void *)"Filled Circle" },

   { ar1_proc,           20,   345,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    (void *)"Scroll Up" },
   { ar2_proc,           20,   360,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    (void *)"Scroll Down" },
   { ar3_proc,           20,   375,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    (void *)"Scroll Left" },
   { ar4_proc,           20,   390,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    (void *)"Scroll Right" },
   { ar5_proc,           20,   405,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    (void *)"Mirror X Axis" },
   { ar6_proc,           20,   420,  120,    10,  13,  0,    0,    D_EXIT,  0,    0,    (void *)"Mirror Y Axis" },

   { new_draw_csp,           3,     40,  160,  160,  9,  0,    0,    0,       0,    0,    NULL },

   { draw_current_bitmap,  220,     40,  400,  400,  9,  0,    0,    0,       0,    0,    NULL },
   { draw_animation,         3,    456,  320,   20,  9,  0,    0,    0,       0,    0,    NULL },

   { NULL,                   0,      0,    0,    0,  0,  0,    0,    0,       0,    0,    NULL }
};
void bitmap_main(void)
{
   do_dialog(bitmap_dialog, -1);
}




