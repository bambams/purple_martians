// e_nlv.cpp (20100220 cleanup)

#include <allegro.h>
#include "pm.h"

char fst[80];

// function prototypes 
void set_lift(int lift, int step);
void draw_lift_mp(int);
void insert_steps_until_quit(int lift, int step);
void redraw_lift_viewer(int lift, int step);
void set_bts(int lift);
extern int bts;     


DIALOG edit_text_line[] =
{
   // (dialog proc)     (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)       (d2)   (dp)           (dp2)      (dp3) 
   { d_box_proc,        100,  100,  200,  100,  255,  0,    0,     0,       0,          0,    NULL,         NULL,      NULL  },
   { d_ctext_proc,      200,  110,    0,    0,   13,  0,    0,     0,       0,          0,    (char *) "Edit Lift Name" },
   { d_edit_proc,       110,  130,  180,  10,   255,  173,  0,     0,       sizeof(fst)-1,    0,            fst,   NULL  },
   { d_button_proc,     110,  175,  80,  20,    11,  0,    13,    D_EXIT,  0,          0,    (char *)"OK",      NULL, NULL  },
   { d_button_proc,     210,  175,  80,  20,    10,  0,    27,    D_EXIT,  0,          0,    (char *)"Cancel",  NULL, NULL  },
   { NULL,              0,    0,    0,    0,      0,  0,    0,     0,       0,         0,     NULL,       NULL, NULL  },
};

DIALOG edit_text_line_16[] =
{
   // (dialog proc)     (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)       (d2)   (dp)           (dp2)      (dp3) 
   { d_box_proc,        100,  100,  200,  100,  63355,     0,    0,     0,       0,          0,    NULL,         NULL,      NULL  },
   { d_ctext_proc,      200,  110,    0,    0,  63355,     0,    0,     0,       0,          0,    (char *) "Edit Lift Name" },
   { d_edit_proc,       110,  130,  180,  10,   63355,    650,   0,     0,       sizeof(fst)-1,    0,            fst,   NULL  },
   { d_button_proc,     110,  175,  80,  20,    2031,      0,    13,    D_EXIT,  0,          0,    (char *)"OK",      NULL, NULL  },
   { d_button_proc,     210,  175,  80,  20,    63488,     0,    27,    D_EXIT,  0,          0,    (char *)"Cancel",  NULL, NULL  },
   { NULL,              0,    0,    0,    0,      0,       0,    0,     0,       0,          0,     NULL,       NULL, NULL  },
};

DIALOG edit_text_line_32[] =
{
   // (dialog proc)     (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)       (d2)   (dp)           (dp2)      (dp3) 
   { d_box_proc,        100,  100,  200,  100,  16777215,  0,    0,     0,       0,          0,    NULL,         NULL,      NULL  },
   { d_ctext_proc,      200,  110,    0,    0,  16777215,  0,    0,     0,       0,          0,    (char *) "Edit Lift Name" },
   { d_edit_proc,       110,  130,  180,  10,   16777215,  20817, 0,     0,       sizeof(fst)-1,    0,            fst,   NULL  },
   { d_button_proc,     110,  175,  80,  20,    65405,     0,    13,    D_EXIT,  0,          0,    (char *)"OK",      NULL, NULL  },
   { d_button_proc,     210,  175,  80,  20,    16711680,  0,    27,    D_EXIT,  0,          0,    (char *)"Cancel",  NULL, NULL  },
   { NULL,              0,    0,    0,    0,      0,       0,    0,     0,       0,          0,     NULL,       NULL, NULL  },
};



void show_all_lifts(void)
{
   int text_pos = 0;
   clear(screen);
   show_mouse(NULL);

   sprintf(msg,"number of lifts:%d", num_lifts);
   textout_ex(screen, font, msg, 10, text_pos*8, palette_color[13], 0);
   text_pos++;
   for (int l=0; l<num_lifts; l++) // iterate lifts
   {
      int w    = lifts[l].width; 
      int h    = lifts[l].height;
      int col  = lifts[l].color; 
      sprintf(msg,"lift:%-2d w:%-2d h:%-2d col:%-2d ns:%-2d  name:%s  ", l, w, h, col, lifts[l].num_steps, lifts[l].lift_name);
      textout_ex(screen, font, msg, 10, text_pos*8, palette_color[10], 0);
      text_pos++;

      int x1 = lifts[l].x1; 
      int y1 = lifts[l].y1;
      int x2 = lifts[l].x2; 
      int y2 = lifts[l].y2;
      sprintf(msg,"x1:%d y1:%d x2:%d y2:%d", x1, y1, x2, y2);
      textout_ex(screen, font, msg, 10, text_pos*8, palette_color[10], 0);
      text_pos++;

      for (int s=0; s<lifts[l].num_steps; s++) // iterate steps
      {
         int x    = lift_steps[l][s].x; 
         int y    = lift_steps[l][s].y;
         int val  = lift_steps[l][s].val; 
         int type = lift_steps[l][s].type; 
         int color = 9; 
         char typemsg[10];
         if ((type >0) && (type < 5))
         {
            sprintf(typemsg,"%s", lift_step_type_name[type] );
            if (type == 1) color = 9; // green for move
            if (type == 2) color = 6; // tan for wait
            if (type == 3) color = 6; // tan for prox
            if (type == 4) color = 5; // green for loop
         }  
         else
         { 
            sprintf(typemsg,"bad step !!!");
            color = 14;
         }  

         sprintf(msg," step:%-2d x:%-4d y:%-4d val:%-4d type:%d (%s)", s, x, y, val, type, typemsg );
         textout_ex(screen, font, msg, 10, text_pos*8, palette_color[color], 0);
         text_pos++;
      }
   }
   tsw(); // wait for keypress
}

int construct_lift(int l, char* lift_name, int width, int height, int color, int num_steps)
{
   strcpy(lifts[l].lift_name, lift_name);
   lifts[l].width = width;
   lifts[l].height = height;
   lifts[l].color = color;
   lifts[l].num_steps = num_steps;
   lifts[l].x1 = 0;
   lifts[l].y1 = 0;
   lifts[l].x2 = 0;
   lifts[l].y2 = 0;
   lifts[l].current_step = 0;
   lifts[l].limit_type = 0;
   lifts[l].limit_counter = 0;
   return 1;
}

void clear_lift(int l)
{
   lifts[l].width = 0;
   lifts[l].height = 0;
   lifts[l].color = 0;
   lifts[l].num_steps = 0;
   lifts[l].x1 = 0;
   lifts[l].y1 = 0;
   lifts[l].x2 = 0;
   lifts[l].y2 = 0;
   lifts[l].current_step = 0;
   lifts[l].limit_type = 0;
   lifts[l].limit_counter = 0;
   strcpy(lifts[l].lift_name, "");
}

int construct_lift_step(int lift, int step, int x, int y, int val, int type)
{
   lift_steps[lift][step].x    = x;
   lift_steps[lift][step].y    = y;
   lift_steps[lift][step].val  = val;
   lift_steps[lift][step].type = type;
   return 1;
}

void clear_lift_step(int lift, int step)
{
   lift_steps[lift][step].x    = 0;
   lift_steps[lift][step].y    = 0;
   lift_steps[lift][step].val  = 0;
   lift_steps[lift][step].type = 0;
}

void erase_lift(int lift)
{
   for (int a=lift; a<num_lifts; a++) // slide down to close hole in array
   {
      lifts[a] = lifts[a+1];
      for (int b=0; b<40; b++)
         lift_steps[a][b] = lift_steps[a+1][b];
   }
   clear_lift(num_lifts);                                  // clear last lift
   for (int a=0; a<40; a++) clear_lift_step(num_lifts, a); // clear last lift's steps
   num_lifts--;                                            // one less lift
}

void delete_lift_step(int lift, int step)
{
   for (int x=step; x<lifts[lift].num_steps-1; x++)   // slide all down
   {
      lift_steps[lift][x].x    = lift_steps[lift][x+1].x ;
      lift_steps[lift][x].y    = lift_steps[lift][x+1].y ;
      lift_steps[lift][x].val  = lift_steps[lift][x+1].val ;
      lift_steps[lift][x].type = lift_steps[lift][x+1].type ;
   }
   lifts[lift].num_steps--;
}

void lift_setup(void)
{
   // set all lifts to step 0
   for (int d=0; d<num_lifts; d++) set_lift(d, 0);
}

void set_lift(int lift, int step)
{
   // searches back from passed step until a move step is found or step 0 is reached
   // sets coordinates in lift from that step
   // then sets the current step in lift to one previous than that (or 0 if no prev)
   // set the type and val to immediately advance to the next step when run

   while ((lift_steps[lift][step].type != 1) && (step > 0) ) step--;

   lifts[lift].x1 = lift_steps[lift][step].x; 
   lifts[lift].y1 = lift_steps[lift][step].y; 
   lifts[lift].x2 = lifts[lift].x1 + lifts[lift].width*20; 
   lifts[lift].y2 = lifts[lift].y1 + lifts[lift].height*20; 
   lifts[lift].fx = itofix(lifts[lift].x1); 
   lifts[lift].fy = itofix(lifts[lift].y1); 
   lifts[lift].fxinc = itofix(0); 
   lifts[lift].fyinc = itofix(0); 

   int c = step-1;
   if (c < 0) c = 0;
   lifts[lift].current_step = c;   // initial step
   lifts[lift].limit_type = 5;     // type wait for time
   lifts[lift].limit_counter = 0;  // 0 = no wait! immediate next mode
}

void draw_step_button(int xa, int xb, int ty, int ty2, int lift, int step, int rc)
{
   switch (lift_steps[lift][step].type)
   {
      case 1: mdw_slider(xa, ty, xb, ty2, 71, step, lift, 0, 0, rc, 15, 15, 1,0,0,0); break;
      case 2: mdw_slider(xa, ty, xb, ty2, 72, step, lift, 0, 0, rc, 15, 15, 1,0,0,0); break;
      case 3: mdw_slider(xa, ty, xb, ty2, 73, step, lift, 0, 0, rc, 15, 15, 1,0,0,0); break;
      case 4: mdw_button(xa, ty, xb, ty2, 74, step, lift, 0, 0, rc, 15, 0,  1,0,0,0); break;
   }
}

void draw_steps(int step_ty, int lift, int current_step, int highlight_step)
{
   int ty  = step_ty;
   int jh = 0;

//   int xa = txc-98;
//   int xb = txc+96;
   int xa = SCREEN_W-(SCREEN_W-(db*100))+1+10;  
   int xb = SCREEN_W-3-10;



   // faded title bar
   title(scrn_buffer, "List of Steps", ty + jh*bts,  15,  12 );

   // title button
   mdw_button(xa, ty+(jh+1)*bts, xb, ty+(jh+2)*bts-1, 70, 0, 0, 0, 0, 8, 15, 0, 1,0,0,0);

   // draw steps
   for (int step=0; step<lifts[lift].num_steps; step++)
      if (lift_steps[lift][step].type) // step is valid 
      {
         int color = 3;   
         if (step == current_step) color = 13;
         if (step == highlight_step) color = 12;
         draw_step_button(xa, xb, ty+(jh+2+step)*bts, ty+(jh+3+step)*bts-1, lift, step, color);
      }
}

void highlight_current_lift(BITMAP *b, int lift)
{
   int color = lifts[lift].color; 
   int x3 = lifts[lift].width * 20; 
   int y3 = lifts[lift].height * 20;
   int x1 = lifts[lift].x1 + 4;   
   int y1 = lifts[lift].y1 + 4;
   int x2 = x1 + x3-4;         
   int y2 = y1 + y3-4;
   
   set_clip_rect(b, 1, 1, db*100-2, db*100-2);

   // mark current lift with crosshairs and rect
   vline(b, ((x1+x2)/2)*db/20, 1, db*100-2, palette_color[10]); 
   hline(b, 1, ((y1+y2)/2)*db/20, db*100-2, palette_color[10]);
   rect(b, (x1*db/20)-1, (y1*db/20)-1, (x2*db/20)+1, (y2*db/20)+1, palette_color[15]);

   // draw lift
   int a;  
   for (a=0; a<10; a++)
      rect(b, (x1+a)*db/20, (y1+a)*db/20, (x2-a)*db/20, (y2-a)*db/20, palette_color[color+ (9-a)*16] );
   rectfill(b, (x1+a)*db/20, (y1+a)*db/20, (x2-a)*db/20, (y2-a)*db/20, palette_color[color] );

   if ((lifts[lift].width == 1) && (lifts[lift].height > 1)) // rotate lift name for vertical lifts
      rtextout_centre(b, lifts[lift].lift_name, ((x1+x2)/2)*db/20, ((y1+y2)/2)*db/20, color+160, (float)db/20, 64);
   else rtextout_centre(b, lifts[lift].lift_name, ((x1+x2)/2)*db/20, ((y1+y2)/2)*db/20, color+160, (float)db/20, 0);

   set_clip_rect(b, 0, 0, SCREEN_W, SCREEN_H);

}

void draw_lift_mp(int lift) // draws the current lift on mp 
{
   int a, d = lift;
   int color = lifts[d].color;
   int szx   = lifts[d].width;
   int szy   = lifts[d].height;
   BITMAP *mp_big = NULL;
   mp_big = create_bitmap(szx*20, szy*20);
   clear(mp_big);
   clear(mp);
   for (a=0; a<10; a++)
      rect(mp_big, a, a, (lifts[d].width*20)-1-a, (lifts[d].height*20)-1-a, palette_color[color+((9-a)*16)] );
   rectfill(mp_big, a, a, (lifts[d].width*20)-1-a, (lifts[d].height*20)-1-a, palette_color[color]);

   if ((lifts[d].width == 1) && (lifts[d].height > 1)) // rotate lift name for vertical lifts
      rtextout_centre(mp_big, lifts[d].lift_name, (lifts[d].width*10)-2, (lifts[d].height*10)-2, color+160, 1, 64);
   else textout_centre_ex(mp_big, font, lifts[d].lift_name, (lifts[d].width*10)-2, (lifts[d].height*10)-2, palette_color[color+160], -1);

   stretch_sprite(mp, mp_big, 0, 0, szx*db, szy*db);
   destroy_bitmap(mp_big);
}

int create_lift(void)
{
   int step = 0;
   if (num_lifts < NUM_LIFTS) 
   {
      num_lifts++; 
      int lift = num_lifts-1;
  
      sprintf(msg, "new lift %d", lift);
      construct_lift(lift, msg, 6, 1, 10, 1);
      construct_lift_step(lift, step, 0, 0, 20, 1);
   
      if (getxy("Set initial position", 4, lift, step) == 1)
      {
         // set step 0 and main x y
         lifts[lift].x1 = lift_steps[lift][step].x = get100_x * 20;
         lifts[lift].y1 = lift_steps[lift][step].y = get100_y * 20;

         // set size
         lifts[lift].x2 = lifts[lift].x1 + (lifts[lift].width*20)-1;
         lifts[lift].y2 = lifts[lift].y1 + (lifts[lift].height*20)-1;
   
         step++;
         construct_lift_step(lift, step, 0, 0, 20, 4); // type 4 - loop to step zero
         lifts[lift].num_steps++; // add one to steps
   
         set_lift(lift, 0); // set step 0 for lift
         insert_steps_until_quit(lift, step);
         return 1;
      }
      else
      {
         erase_lift(lift);
         return 0;
      }
   }
   else
   {
      gui_fg_color = palette_color[14]; gui_bg_color = palette_color[14+224];
      alert("Error creating lift",  "", "40 lifts is the maximum", "OK", (char)NULL, (char)NULL, (char)NULL);
      gui_fg_color = palette_color[9];  gui_bg_color = palette_color[0];
      return 0;
   }   
}

void move_lift_step(int lift, int step)
{
   if (lift_steps[lift][step].type == 1) // only if type = move
   {
      int nx = ((lift_steps[lift][step].x + lifts[lift].width  * 10) *db)/20; 
      int ny = ((lift_steps[lift][step].y + lifts[lift].height * 10) *db)/20;
      position_mouse(nx, ny);
      getxy("Set new location", 4,  lift, step);
   }
}

int get_new_lift_step(int lift, int step)
{
   // step is a new blank step already created for us
   // if we return 99 the step will be erased

   // position the menu on top of the step we are inserting before
   int sty = 53 + (step + 9) * bts;
   if (sty > SCREEN_H-60) sty = SCREEN_H-60;

   int fc = 14; // frame color
   int tc = 15; // text color
   int bc = 6;  // button color

   show_mouse(NULL);

   // draw the menu
   rectfill(screen, txc-98, sty-8, txc+96, sty+(7*12)-22, palette_color[fc+192]); // erase to background color

   rect (screen, txc-98, sty-8, txc+96, sty+2, palette_color[fc]); // frame
   sprintf(msg, "Insert New Step %d", step);
   textout_centre_ex(screen, font, msg, txc, sty-6,  palette_color[fc], -1);

   rect (screen, txc-98, sty-8, txc+96, sty+(7*12)-22, palette_color[fc]); // frame
   textout_centre_ex(screen, font, "Select Step Type", txc, sty+5, palette_color[tc], -1);

   int jh = 1;
   sprintf(msg, "Move");
   rectfill(screen, txc-21, sty+(jh*12)+2, txc+18, sty+(jh*12)+12, palette_color[bc+128]);
   textout_centre_ex(screen, font, msg, txc, sty+(jh*12)+4,  palette_color[tc], -1);
       rect(screen, txc-21, sty+(jh*12)+2, txc+18, sty+(jh*12)+12, palette_color[bc]);

   jh = 2;
   sprintf(msg, "Wait For Time");
   rectfill(screen, txc-57, sty+(jh*12)+2, txc+54, sty+(jh*12)+12, palette_color[bc+128]);
   textout_centre_ex(screen, font, msg, txc, sty+(jh*12)+4,  palette_color[tc], -1);
       rect(screen, txc-57, sty+(jh*12)+2, txc+54, sty+(jh*12)+12, palette_color[bc]);

   jh = 3;
   sprintf(msg, "Wait For Prox");
   rectfill(screen, txc-57, sty+(jh*12)+2, txc+54, sty+(jh*12)+12, palette_color[bc+128]);
   textout_centre_ex(screen, font, msg, txc, sty+(jh*12)+4,  palette_color[tc], -1);
       rect(screen, txc-57, sty+(jh*12)+2, txc+54, sty+(jh*12)+12, palette_color[bc]);

   jh = 4;
   textout_centre_ex(screen, font, "Cancel", txc, sty+(jh*12)+4, palette_color[10], -1);

   // position and show the mouse
   position_mouse(txc, sty+24);
   show_mouse(screen);

   int quit = 0;
   while (!quit)
   {
      rest(20);

      // redraw menu with no highlighted items
      rect(screen, txc-21, sty+(1*12)+2, txc+18, sty+(1*12)+12, palette_color[bc]);
      rect(screen, txc-57, sty+(2*12)+2, txc+54, sty+(2*12)+12, palette_color[bc]);
      rect(screen, txc-57, sty+(3*12)+2, txc+54, sty+(3*12)+12, palette_color[bc]);
      textout_centre_ex(screen, font, "Cancel", txc, sty+(jh*12)+4, palette_color[10+48], -1);


      if ((mouse_b & 2) || (key[KEY_ESC])) quit = 99;
      if ((mouse_x > txc-95) && (mouse_x < txc+95))
      {
         int selection = (mouse_y-sty-3)/12-1;     // get selection based on mouse y
         if ((selection > -1 ) && (selection < 4)) // check if selection valid
            switch (selection)                     // show highlight on step
            {
               case 0: rect(screen, txc-21, sty+(1*12)+2, txc+18, sty+(1*12)+12, palette_color[14]); break;
               case 1: rect(screen, txc-57, sty+(2*12)+2, txc+54, sty+(2*12)+12, palette_color[14]); break;
               case 2: rect(screen, txc-57, sty+(3*12)+2, txc+54, sty+(3*12)+12, palette_color[14]); break;
               case 3: textout_centre_ex(screen, font, "Cancel", txc, sty+(jh*12)+4, palette_color[10], -1); break;
            }
         if (mouse_b & 1)
         {
            while(mouse_b & 1);                                 // wait for release
            if ((selection < 0 ) || (selection > 3)) quit = 99; // check if selection invalid
            else 
            {  
               quit = 1;
               switch (selection)
               {
                  case 0:
                     construct_lift_step(lift, step, 0, 0, 20, 1);              // set move step
                     if (getxy("Set lift position", 4, lift, step) == 1)        // set location
                     {
                        lift_steps[lift][step].x = get100_x * 20;
                        lift_steps[lift][step].y = get100_y * 20;
                     }
                     else quit = 99;
                  break;
                  case 1: construct_lift_step(lift, step, 0, 0, 100, 2); break; // set wait step
                  case 2: construct_lift_step(lift, step, 0, 0, 80,  3); break; // set prox step
                  case 3: quit=99; break; // cancel
               } // end of switch selection
            } // end of if selection valid
         }  // end of if mouse_b 1
      }  // end of mouse on menu
   } // end of while (!quit)
   return quit;
}

int insert_lift_step(int lift, int step) // inserts a step in 'lift' before 'step'
{
   int ret = 0;
   redraw_lift_viewer(lift, step);

   // increment the number of steps
   if (++lifts[lift].num_steps > 40)
   {
      lifts[lift].num_steps--;
      ret = 0;
      gui_fg_color = palette_color[14];  gui_bg_color = palette_color[14+224];
      alert("Error creating lift step:", (char)NULL, "40 steps is the maximum", "OK", (char)NULL, (char)NULL, (char)NULL);
      gui_fg_color = palette_color[9]; gui_bg_color = palette_color[0];
   }        
   else
   {

      // slide steps down to make room for new step
      for (int x=lifts[lift].num_steps-2; x>=step; x--)
      {
         lift_steps[lift][x+1].x    = lift_steps[lift][x].x;
         lift_steps[lift][x+1].y    = lift_steps[lift][x].y;
         lift_steps[lift][x+1].val  = lift_steps[lift][x].val;
         lift_steps[lift][x+1].type = lift_steps[lift][x].type;
      }

      // do this after creating a new lift step so stuff lines up...
      set_bts(lift);
      int step_ty = 46 + 7 * bts;
      draw_steps(step_ty, lift, step, step);     // show lift steps


      if (get_new_lift_step(lift, step) == 99) // cancelled
      {
         delete_lift_step(lift, step);
         ret = 0;
      } 
      else ret = 1;
      redraw_lift_viewer(lift, step);
   }   
   return ret;
}

void insert_steps_until_quit(int lift, int step)
{
   while (insert_lift_step(lift, step)) step++;
}   

void step_popup_menu(int lift, int step)
{
   int mx, my;
   if ((mouse_x < db*100) && (mouse_x < db*100)) // called from map
   {
      mx = mouse_x;
      int lift_ypos = lifts[lift].y2;
      my = lift_ypos*db/20 + 27; 
   }
   else // called from step buttons
   {
      mx = txc;
      my = 86 + (step + 9) * bts;
   }        

   if (mx > SCREEN_W-100) mx = SCREEN_W-100;
   if (my > SCREEN_H-100) my = SCREEN_H-100;
   if (mx < 100) mx = 100;
   if (my < 30) my = 30;
   position_mouse(mx, my);   

   sprintf(global_string[6][0],"Lift:%d Step:%d", lift+1, step);
   sprintf(global_string[6][1],"---------------");
   sprintf(global_string[6][2],"Cancel");
   sprintf(global_string[6][3],"Move Step %d", step);
   sprintf(global_string[6][4],"Delete Step %d", step);
   sprintf(global_string[6][5],"Insert Steps");
   sprintf(global_string[6][6],"end");

   // special case for first step (don't allow delete or insert, only move )
   if (step == 0) 
   {
      // set menu text
      sprintf(global_string[6][3],"Move Step %d", step);
      sprintf(global_string[6][4],"end");

      // blank and frame for menu
      rectfill(screen, mx-70, my-24, mx+70, my+14, palette_color[0]);
          rect(screen, mx-70, my-24, mx+70, my+14, palette_color[13]);

      // call the menu
      if (pmenu(6) == 3) move_lift_step(lift, step);
   }

   // special case for last step (don't allow move or delete, only insert)
   else if (step == lifts[lift].num_steps-1)
   {
      // set menu text
      strcpy (global_string[6][3],"Insert Steps");
      sprintf(global_string[6][4],"end");

      // blank and frame for menu
      rectfill(screen, mx-70, my-24, mx+70, my+14, palette_color[0]);
          rect(screen, mx-70, my-24, mx+70, my+14, palette_color[13]);

      // call the menu
      if (pmenu(6) == 3) insert_steps_until_quit(lift, step); 
   }

   // regular step (not first or last)
   else
   {
      if (lift_steps[lift][step].type == 1) // only allow move for step type 1 
      {
         // set menu text
         sprintf(global_string[6][3],"Move Step %d", step);
         sprintf(global_string[6][4],"Delete Step %d", step);
         sprintf(global_string[6][5],"Insert Steps");
         sprintf(global_string[6][6],"end");

         // blank and frame for menu
         rectfill(screen, mx-70, my-24, mx+70, my+30, palette_color[0]);
             rect(screen, mx-70, my-24, mx+70, my+30, palette_color[13]);

         // call the menu
         int msel = pmenu(6);
   
         // do the action    
         switch (msel)
         {
            case 3: move_lift_step(lift, step); break;
            case 4: delete_lift_step(lift, step); break;
            case 5: insert_steps_until_quit(lift, step); break;
         }         
      }   
      else 
      {
         // set menu text
         sprintf(global_string[6][3],"Delete Step %d", step);
         sprintf(global_string[6][4],"Insert Steps");
         sprintf(global_string[6][5],"end");

         // blank and frame for menu
         rectfill(screen, mx-70, my-24, mx+70, my+14, palette_color[0]);
             rect(screen, mx-70, my-24, mx+70, my+22, palette_color[13]);

         // call the menu
         int msel = pmenu(6);

         // do the action    
         switch (msel)
         {
            case 3: delete_lift_step(lift, step); break;
            case 4: insert_steps_until_quit(lift, step); break;
         }         
      }
   }       
}       

void set_bts(int lift)
{                                      // get button y size 
   int ns = lifts[lift].num_steps + 9; // number of steps for this lift
   int sp = SCREEN_H - 46;             // how much vertical screen space
   bts = sp/ns;                        // adjust button size so they all will fit
   if (bts > 16) bts = 16;             // max button size
   if (bts < 8) bts = 8;               // min button size
}

void redraw_lift_viewer(int lift, int step)
{
   set_lift(lift, step);               // set current step in current lift
   draw_big(1);                        // update the map bitmap
   title_obj(scrn_buffer, 4, lift, 0, 0, 15);       // show title and map on screen
   highlight_current_lift(scrn_buffer, lift);       // crosshairs and rect on current lift
   set_bts(lift);
   int step_ty = 46 + 7 * bts;
   draw_steps(step_ty, lift, step, step); // show lift steps
}     



int lift_editor(int lift)
{
   int current_step = 0;
   int step_pointer=0;
   extern int ty;   

   // button x position
   int xa = SCREEN_W-(SCREEN_W-(db*100))+1;  
   int xb = SCREEN_W-3;

   int ret = 0;
   int quit = 0;
   while (!quit)
   {
      set_bts(lift);
      int step_ty = 46 + 7 * bts;


      redraw_lift_viewer(lift, current_step);



      // draw current lift on menu
      if (bts == 16) // only if max button size
      {
         int a;
         int x1 = (SCREEN_H/100)*100+22;
         int x2 = x1 + (lifts[lift].width * 20) -1;
         int y1 = step_ty + (lifts[lift].num_steps+3) * bts; // only see in 2 highest screen modes
         int y2 = y1 + (lifts[lift].height * 20) -1;
         int color = lifts[lift].color;
         for (a=0; a<10; a++)
            rect(scrn_buffer, x1+a, y1+a, x2-a, y2-a, palette_color[color + ((9 - a)*16)] );
         rectfill(scrn_buffer, x1+a, y1+a, x2-a, y2-a, palette_color[color] );

        if ((lifts[lift].width == 1) && (lifts[lift].height > 1)) // rotate lift name for vertical lifts
           rtextout_centre(scrn_buffer, lifts[lift].lift_name, ((x1+x2)/2), ((y1+y2)/2)+1, color+160, 1, 64);

        else textout_centre_ex(scrn_buffer, font, lifts[lift].lift_name, ((x1+x2)/2), ((y1+y2)/2)-2, palette_color[color+160], -1);
      }



 
   
      while (key[KEY_ESC]) quit = 1;       
      int mb = 0; // return value from buttons
      while (key[KEY_DEL])   mb = 20;
      while (key[KEY_RIGHT]) mb = 21;
      while (key[KEY_LEFT])  mb = 22;




      int a = 0;  // keep track of button y spacing

      int x12 = xa + 1 * (xb-xa) / 2; // 1/2          // split into half  
      int x13 = xa + 1 * (xb-xa) / 3; // 1/3          // split into thirds  
      int x23 = xa + 2 * (xb-xa) / 3; // 2/3
      int x27 = xa + 2 * (xb-xa) / 7; // 2/7          // split into sevenths  
      int x57 = xa + 5 * (xb-xa) / 7; // 5/7
      
      int lc = 6; // lock_color;
      if (Viewer_lock) lc = 7;

      if (mdw_button(xa,    ty+a*bts, x27-1, ty+(a+1)*bts-2, 23, lift, 0, 0, 0,  9, 15, 0, 1,0,0,0)) mb = 22;  // prev 
          mdw_button(x27,   ty+a*bts, x57-1, ty+(a+1)*bts-2, 56, lift, 0, 0, 0, lc, 15, 0, 1,0,0,0);           // lock 
      if (mdw_button(x57, ty+a++*bts, xb,    ty+(a+1)*bts-2, 22, lift, 0, 0, 0,  9, 15, 0, 1,0,0,0)) mb = 21;  // next 
      if (mdw_button(xa,    ty+a*bts, x13-1, ty+(a+1)*bts-2, 28, lift, 0, 0, 0, 13, 15, 0, 1,0,0,0)) mb = 18;  // move
      if (mdw_button(x13,   ty+a*bts, x23-1, ty+(a+1)*bts-2, 20, lift, 0, 0, 0, 14, 15, 0, 1,0,0,0)) mb = 19;  // create 
      if (mdw_button(x23, ty+a++*bts, xb,    ty+(a+1)*bts-2, 21, lift, 0, 0, 0, 10, 15, 0, 1,0,0,0)) mb = 20;  // delete 
      if (mdw_button(xa,    ty+a*bts, x12-1, ty+(a+1)*bts-2, 25, lift, 0, 0, 0, 1,  15, 0, 1,0,0,0)) mb = 24;  // viewer help 
      if (mdw_button(x12, ty+a++*bts, xb,    ty+(a+1)*bts-2, 57, lift, 0, 0, 0, 1,  15, 0, 1,0,0,0)) mb = 25;  // lift help 
          mdw_slider(xa,  ty+a++*bts, xb,    ty+(a+1)*bts-2, 43, lift, 0, 0, 0, 12, 15, 15, 1,0,0,0);          // lift width
          mdw_slider(xa,  ty+a++*bts, xb,    ty+(a+1)*bts-2, 44, lift, 0, 0, 0, 12, 15, 15, 1,0,0,0);          // lift height
          mdw_colsel(xa,  ty+a++*bts, xb,    ty+(a+1)*bts-2,  4, lift, 0, 0, 0, 15, 13, 14, 0,0,0,0);          // lift color
      if (mdw_button(xa,  ty+a++*bts, xb,    ty+(a+1)*bts-2, 29, lift, 0, 0, 0,  4, 15,  0, 1,0,0,0)) mb = 26; // lift name

      draw_steps(step_ty, lift, current_step, step_pointer);




      // this is the awesome section that lets you move steps on the map just by clicking and dragging
      if ((mouse_x < db*100)  && (mouse_x < db*100) )        // is mouse x on map ?
      {
         int mouse_on_lift = 0;
         int mouse_on_moveable_step = 0;
         for (int x=0; x<num_lifts; x++)  // cycle lifts
            for (int y=0; y<lifts[x].num_steps; y++)  // cycle steps
               if (lift_steps[x][y].type == 1) // look for move step
               {
                  int nx = ((lift_steps[x][y].x + lifts[x].width  * 10) *db)/20; 
                  int ny = ((lift_steps[x][y].y + lifts[x].height * 10) *db)/20;
                  int w = lifts[x].width  * 10 * db / 20 + 1;
                  int h = lifts[x].height * 10 * db / 20 + 1;
                  // is mouse on this step ?
                  if ((mouse_x > nx - w)  && (mouse_x < nx + w) && (mouse_y > ny - h)  && (mouse_y < ny + h))
                  {
                     mouse_on_lift = 1;
                     if ((key[MAP_LOCK_KEY]) || (Viewer_lock)) // locked to current lift
                     {
                        if (lift == x) // are we on current lift?
                        {
                           mouse_on_moveable_step = 1;
                           if (current_step != y) // same lift, different step
                           {
                              current_step = y;
                           }   
                        }   
                     }
                     else // no lock
                     {
                        mouse_on_moveable_step = 1;
                        if ((lift != x) || (current_step != y)) // no lock, different lift or step
                        {
                           lift = x;
                           current_step = y;
                        }   
                     }   
                     if (mouse_on_moveable_step)
                     {
                        if (mouse_b & 2)
                        {
                           step_popup_menu(x, y);
                        }
                        // first time only to snap to middle of lift step we're moving
                        if (mouse_b & 1) position_mouse(nx+w/2, ny+h/2);
                        while (mouse_b & 1)
                        {
                           rest(10);
                           nx = mouse_x;
                           ny = mouse_y;
                            
                           int jnx = (nx - w) / db * 20;
                           int jny = (ny - h) / db * 20;
   
                           if (jnx > 1979) jnx = 1979;
                           if (jny > 1979) jny = 1979;
                           if (jnx < 0) jnx = 0;
                           if (jny < 0) jny = 0;
      
                           lift_steps[x][y].x = jnx;
                           lift_steps[x][y].y = jny;
     
                           set_lift(lift, current_step);   // set current step in current lift

                           set_clip_rect(scrn_buffer, 1, 1, db*100-2, db*100-2);
                           draw_big(1);
                           show_big(scrn_buffer);
                           highlight_current_lift(scrn_buffer, lift);   // crosshairs and rect on current lift
                           blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);

                           
                        } // end of while mouse b1 pressed     
                        set_clip_rect(scrn_buffer, 0, 0, SCREEN_W, SCREEN_H);
                     } // end of mouse on moveable step
                  } // end of mouse on this step  
               }  // end of cycle move steps



         // if mouse was not on any lift steps, see if we can switch to another object
         if ((!mouse_on_lift) && (!key[MAP_LOCK_KEY]) && (!Viewer_lock))
         {
            int mx = mouse_x / db;
            int my = mouse_y / db;

            // is mouse on any enemy?
            for (int e=0; e<500; e++)
            {
               int x0 = fixtoi(Efi[e][0]);
               int y0 = fixtoi(Efi[e][1]);
               if ((Ei[e][0]) && (x0 == mx*20) && (y0 == my*20))
               {
                   quit = 1;
                   ret = e + 1000;
               }   
            }
            // is mouse on any item?
            if (!quit) for (int x=0; x<500; x++)
            {
               int x0 = item[x][4];
               int y0 = item[x][5];
               if ((item[x][0]) && (x0 == mx*20) && (y0 == my*20))
               {
                   quit = 1;
                   ret = x + 2000;
               }   
            } 
         }
      } // end of mouse on map  
      // mouse x on step buttons
      if ((mouse_x > xa + 10) && (mouse_x < xb -10) && (quit != 1) )
      {
         // calculate step
         int step = (mouse_y - step_ty) / bts -2;
         if (mouse_b & 1)
         {
            current_step = step;
         }

         // is step valid
         if ((step >= 0) && (step < lifts[lift].num_steps))
         {
            step_pointer = step;
            if (mouse_b & 2) // button pop up menu
            {
              step_popup_menu(lift, step);
            }
         } // end of valid step
         else step_pointer = -1;// step not valid
      }
      else step_pointer = -1;// // not on buttons at all



      if (mb)
      {
         while (mouse_b & 1); // wait for release
         switch (mb)
         {
            case 19: create_lift(); break;                                // create new
            case 21: if (++lift > num_lifts-1) lift = num_lifts-1; break; // next 
            case 22: if (--lift < 0) lift++; break;                       // previous 
            case 24: help("Viewer Basics"); break;                        // help viewer 
            case 25: help("Lift Viewer"); break;                          // help lifts
            case 20:  // delete 
               erase_lift(lift);
               if (--lift < 0) lift = 0;    // set to prev lift or zero 
               if (num_lifts < 1) quit = 1; // if erased last lift; exit lift viewer
            break;
            case 26:  // new name
            {
               strcpy(fst, lifts[lift].lift_name);
               int ret = 0;
               if (get_color_depth()== 8) ret = popup_dialog(edit_text_line, 2);
               if (get_color_depth()== 16) ret = popup_dialog(edit_text_line_16, 2);
               if (get_color_depth()== 32) ret = popup_dialog(edit_text_line_32, 2);
               if (ret == 3) strcpy(lifts[lift].lift_name, fst);
               clear_keybuf();
            }
            break;
            case 18:  // run lifts
            {
               while (!key[KEY_ESC])
               {
                  for (int t=0; t<8; t++) move_lifts(1);                   // move lifts for 8 frames
                  draw_big(1);                                             // update the map bitmap
                  show_big(scrn_buffer);                                              // show the map
                  highlight_current_lift(scrn_buffer, lift);                            // highlight current lift
                  draw_steps(step_ty, lift, lifts[lift].current_step, -1); // show lift steps
                  blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
               }
               while (key[KEY_ESC]); // wait for release
               lift_setup(); // reset all lifts to step 0
            }  
            break;
         } // end if switch (mb) 
      } // end of if (mb)   


/*
      // this way has a flickering mouse
      // but no old mouse pointer when adjusting sliders 
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      show_mouse(screen);
      rest(20);      
      show_mouse(NULL); 
      clear(scrn_buffer); 
*/


/*
      // this way has the mouse nice and solid
      // but leaves frozen old mouse pointer when adjusting sliders
      show_mouse(scrn_buffer);
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      show_mouse(NULL);
      rest(10);      
      clear(scrn_buffer); 

*/

      // this way has the mouse nice and solid
      if (Redraw == 2) // mouse on slider bar will draw the mouse
      {
         Redraw = 0;
         blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
         clear(scrn_buffer); 
      } 
      else
      {
         show_mouse(scrn_buffer);
         if (Redraw == 1) Redraw = 0; // don't draw this screen_buffer, it has old slider positions
         else blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
         show_mouse(NULL);
         rest(mouse_loop_pause);
         clear(scrn_buffer); 
      }






   } // end of while !quit
   lift_setup();
   draw_big(1);
   return ret;
}


























