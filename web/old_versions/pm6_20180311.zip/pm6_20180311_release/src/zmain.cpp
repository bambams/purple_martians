#include <allegro.h>
#include "pm.h"
#include <zlib.h>  



#ifdef DUMB
DUH *myduh;
AL_DUH_PLAYER *dp;
#endif


// --------------- Global Variables ---------------
// all global variables should be declared here and externed in pm.h

char demo_filenames[100][256];

int demo_played[100];



int num_demo_filenames = 0;

int demo_mode_on = 0;
int demo_mode_countdown;




char local_hostname[80];
char version_string[80];



int TCP = 0;

int L_LOGGING = 0;
int L_LOGGING_NETPLAY = 0;
int L_LOGGING_NETPLAY_JOIN = 0;
int L_LOGGING_NETPLAY_bandwidth = 0;
int L_LOGGING_NETPLAY_client_timer_adjust = 0;
int L_LOGGING_NETPLAY_cdat = 0;
int L_LOGGING_NETPLAY_game_move = 0;
int L_LOGGING_NETPLAY_sdat = 0;
int L_LOGGING_NETPLAY_sdak = 0;
int L_LOGGING_NETPLAY_chdf = 0;
int L_LOGGING_NETPLAY_chdf_all_packets = 0;
int L_LOGGING_NETPLAY_chdf_when_to_apply = 0;
int L_LOGGING_NETPLAY_show_dif1 = 0;
int L_LOGGING_NETPLAY_show_dif2 = 0;




// server chdf
char client_chdf[8][2][CHUNK_SIZE]; 
int client_chdf_id[8][2]; // passcount id

// client chdf
char chdf[CHUNK_SIZE];         // for client chdf building
int chdf_pieces[16];

char clientl_chdf[CHUNK_SIZE]; // last ack state for diffing 
int clientl_chdf_id;           // passcount id of last state

char dif[CHUNK_SIZE];
int dif_id[2]; //   (0 = src, 1 = dst)

int zlib_cmp = 7;
int chdf_freq = 40;
int control_lead_frames = 3;
int server_lead_frames = 1;

int deathmatch_pbullets = 0;
int deathmatch_pbullets_damage = 5;
int suicide_pbullets = 0;


int mouse_loop_pause = 0;

char msg[256];


struct player players[NUM_PLAYERS];
struct player1 players1[NUM_PLAYERS];

int l[100][100];    // level
int Ei[100][32];    // enemy ints
fixed Efi[100][16]; // enemy fixeds 
int item[500][16];  // item ints
fixed itemf[500][4]; // item fixed points

int num_lifts;
struct lift lifts[NUM_LIFTS];
struct lift_step lift_steps[NUM_LIFTS][40];



int db;  // level editor zoom fullscreen double
int md;         // menu map double
int map_double; // level editor map double
int map_x = BORDER_WIDTH;
int map_y = BORDER_WIDTH;
int map_size = 0;
int new_size = 0;
int txc;



int Redraw = 1;
int Num_legend_lines = 2;
int Viewer_lock = 0;


int menu_map_x;
int menu_map_y;
int menu_map_size;

int item_num_of_type[20];


int ssfnsn = 0; // screen shot file name sequence number
int making_video = 0;
int speed_testing = 0;



struct screen_msg screen_msgs[100];

char log_msg[100000000]; // for logging
int log_msg_pos = 0;
char log_lines[1000000][100]; // for log file viewer
int log_lines_int[1000000][3]; // for log file viewer


int log_timer;

int KEY_F1_held = 0;
int KEY_F2_held = 0;
int KEY_F3_held = 0;
int KEY_F4_held = 0;
int KEY_F5_held = 0;
int KEY_F6_held = 0;
int KEY_F7_held = 0;
int KEY_F8_held = 0;
int KEY_F10_held = 0;
int KEY_PRTSCR_held = 0;


int test_int = 3;






// timer variables
volatile int timer_passcount = 0;
volatile int last_fps_passcount = 0;
volatile int fps;
volatile int last_frames_skipped = 0;
volatile int frames_skipped_last_second;


int ima_server = 0;
int ima_client = 0;
int active_local_player = 0;


char m_serveraddress[256] = "192.168.1.2";


int game_moves[1000000][4];
int game_move_entry_pos = 0;
int game_move_current_pos = 0; // for savegame running only


char enemy_name[50][32];
char lift_step_type_name[10][10];

char color_name[16][20];

int pm_bullet_collision_box = 8;
int map_on = 0;
int show_debug_overlay = 0;

int show_player_join_quit_timer = 0;
int show_player_join_quit_player = 0;
int show_player_join_quit_jq = 0;


float scale_factor = 1.0;
float scale_factor_current  = 1.0;
float scale_factor_inc = 0.03;
int show_scale_factor;

// ---------- all global BITMAP declarations here --------
PALLETE pallete;
BITMAP *memory_bitmap[NUM_SPRITES];
BITMAP *player_bitmap[16][32];
BITMAP *door_bitmap[2][16][8];

BITMAP *l2000 = NULL;
BITMAP *level_buffer = NULL;
BITMAP *scrn_buffer = NULL;
BITMAP *dtemp = NULL; // temp draw
BITMAP *lefsm = NULL; // level editor fullscreen map


BITMAP *mp = NULL;     //  mouse_pointer 
BITMAP *ft_bmp = NULL;  //  file temp paste bmp 
BITMAP *select_window_bmp = NULL;
BITMAP *status_window_bmp = NULL;



int show_splash_screen = 1;
int auto_save_game_on_exit = 0;
int auto_save_game_on_level_done = 0;



int mdw_an_seq = 0; // mdw animation sequence number
int points[10][8]; // for mdw logo
int mdw_map_logo_x = 100;
int mdw_map_logo_y = 140;
int mdw_map_logo_th = 1;
float mdw_map_logo_scale = .3;

float mdw_splash_logo_x;
float mdw_splash_logo_y;
int mdw_splash_logo_th;
float mdw_splash_logo_scale;


float mdw_logo_scale_dec;
float mdw_logo_x_dec;
float mdw_logo_y_dec;



// other global variables

SAMPLE *snd[20];
char global_string[20][25][80]; 

int tmy;   // menu pos
int tmtx, tmty; // text position
int mx, my;
float steps;
int num_sounds;
int lit_item;
int fuse_loop_playing;
int sample_delay[8];
int se_scaler=5;
int st_scaler=5;

int bcmt[NUM_SPRITES];
int sa[NUM_SPRITES][2];

int desktop_sx;
int desktop_sy; 
int desktop_colordepth;

int sx=640;
int sy=480;
int gfx_card = 2;
int color_depth = 32;
int auto_full_screen = 1;


int level_num;
char level_filename[80];

int level_header[20];
char* pmsg[500];


int zz[20][NUM_ANS];
int passcount;
int draw_frame;

int speed = 40;
int play_level;
int start_mode = 1;
int valid_level_loaded = 0;


int resume_allowed=0;
int top_menu_sel = 3;
int level_time;
int LIVES;

int start_level=1;
int sound_on = 0;
int passcount_timer_fps= 20;

int pbullet[50][6];

int e_bullet_active[50], e_bullet_shape[50];
fixed e_bullet_fx[50], e_bullet_fy[50], e_bullet_fxinc[50], e_bullet_fyinc[50];

int level_done = 0;
int game_exit = 1;
int num_enemy;


// counters and temp string
char b_msg[40][80];
int bottom_msg=0;

int game_map_on = 0;



// ------------- global variables from old e_main---------------------------


// enemies
int e_num_of_type[50];
int e_first_num[50];
int PDEi[100][32];
fixed PDEfx[100][16];
char PDEt[100][20][40];
char eftype_desc[50][16][40];   
char eitype_desc[50][32][40];   

// items
int item_first_num[20];
int item_coloc_num;
int item_coloc_x;
int item_coloc_y;
char item_edit_text[80];
char item_desc[20][5][40];

int swbl[NUM_SPRITES][2];
int swbn;


int ty = 46;   // button start 
int tw = 94;   // button width 
int bts = 12;  // button spacing 


char sel_filename[500];

int exit_link = 0;
int bx1, bx2, by1, by2;
int slx0=0, sly0=0, slx1=20, sly1=20;


int bmp_index = 255; // used by edit menu 
int zzindx = 3; 
int b1_color = 3, bs_win = 0;

int get100_x, get100_y; // used by edit functions 
int edit_int_retval;

// zoom full screen stuff
int stx=10;  // selection window 
int sty=10;
int sux=40;
int suy=30;

int copy_blocks=1;
int copy_enemies=1;
int copy_items=1;
int copy_lifts=1;
int copy_mode = 0;
int brf_mode =0;

int lc;


int ft_level_header[20];
int ft_l[100][100];
int ft_item[500][16];
char* ft_pmsg[500];
int ft_Ei[100][32];
fixed ft_Efi[100][16];

char ft_ln[NUM_LIFTS][80];
int ft_lift[NUM_LIFTS][4];
int ft_ls[NUM_LIFTS][40][4];

// gui stuff   
int text_draw_flag=0;

int wx=0;
int wy=0;

int draw_item_num;
int draw_item_type;
int point_item_num;
int point_item_type;

int old_line_draw_mode;

int line_draw_mode;
int grid_flag = 0;


int pop_msg_viewer_pos;


// status window
int status_window_active = 1;
int status_window_x;
int status_window_y = 35;
int status_window_w = 320;
int status_window_h = 43;

// select window
int select_window_active = 1;
int select_window_x;
int select_window_y = 100;
int select_window_w = 322;
int select_window_h;
int select_window_text_y;
int select_window_block_on = 1;
int swnbl;
int swnbl_cur = 0;

int select_window_block_y;
int btext_draw_flag;
int select_window_special_on = 1;
int select_window_num_special_lines = 3;
int select_window_special_y;
int stext_draw_flag;
int sw_mouse_gone = 0;

// color selection pallete
int cs=0;
int cspx = 3;   // color selection pallete 
int cspy = 40;
int csps = 10;
int cspf = 0;

int cbx = 220; // current bitmap  for gui
int cby = 40;
int cbs = 20;
int old_px;
int old_py;

int cols;   // number of columns for solid blocks in block editor 
int fw = 4; // frame width for block editor 

// end of global from old e_main





void inc_timer_passcount()
{
   timer_passcount++;
}
END_OF_FUNCTION(inc_timer_passcount);

void second_timer()
{
   fps = passcount - last_fps_passcount;
   last_fps_passcount = passcount;

   frames_skipped_last_second = (players1[active_local_player].frames_skipped - last_frames_skipped); 
   last_frames_skipped = players1[active_local_player].frames_skipped;
}
END_OF_FUNCTION(second_timer);


void final_wrapup(void)
{


   for (int x=0; x<16; x++) // player bitmaps 
      for (int y=0; y<32; y++)
         destroy_bitmap( player_bitmap[x][y] );

   for (int c=0; c<NUM_SPRITES; c++)
      destroy_bitmap(memory_bitmap[c]);
   destroy_bitmap(l2000);
   destroy_bitmap(level_buffer);
   destroy_bitmap(scrn_buffer);
   destroy_bitmap(dtemp);

   destroy_bitmap(lefsm);

   extern BITMAP * grid_bmp;
   destroy_bitmap(grid_bmp);



#ifdef SOUND
   for (int c=0; c<num_sounds; c++)
      destroy_sample(snd[c]);
#endif


#ifdef DUMB
   al_stop_duh(dp);
   unload_duh(myduh);
   dumb_exit();
#endif


   allegro_exit();
}



void fast_exit(int why)
{
   // don't overwrite if zero
   if (why != 0) players1[active_local_player].quit_reason = why;

   void log_ending_stats(void);
   void log_ending_stats_server(void);

   if (ima_client) log_ending_stats();
   if (ima_server) log_ending_stats_server();

   save_log_file();
   blind_save_game_moves(3); 
   final_wrapup();
   exit(0);
}


void get_hostname(void)
{
   sprintf(msg, "hostname");
   FILE *fp;
   fp = popen(msg,"r"); 

   int loop = 0;
   int ch = fgetc(fp);
   while((ch != '\n') && (ch != EOF))
   {
      local_hostname[loop] = ch;
      loop++;
      ch = fgetc(fp);
   }
   local_hostname[loop] = 0;
   fclose(fp);
}


void get_config_values(void)
{
   players[0].color = get_config_int("GAME", "color", 8);
   set_config_int("GAME", "color", players[0].color);

   start_level = get_config_int("GAME", "start_level", 1); 
   set_start_level(start_level);
   
//   speed = get_config_int("GAME", "speed", 40);
   set_speed();

   scale_factor = get_config_float("SCREEN", "scale_factor", 1.0);
   set_scale_factor(1);

   load_sound();

   load_keys();
   save_keys();

   show_splash_screen = get_config_int("SCREEN", "show_splash_screen", 1); 
   set_config_int("SCREEN", "show_splash_screen", show_splash_screen);

   if (show_splash_screen) sprintf(global_string[8][11], "Splash Screen:ON ");
   else sprintf(global_string[8][11], "Splash Screen:OFF");

   strcpy(m_serveraddress, get_config_string("NETWORK", "server_IP", "192.168.1.100"));
   set_config_string("NETWORK", "server_IP", m_serveraddress);

   TCP = get_config_int("NETWORK", "TCP", 0); 
   set_config_int("NETWORK", "TCP", TCP);
     
   deathmatch_pbullets = get_config_int("NETWORK", "deathmatch_pbullets", 1); 
   set_config_int("NETWORK", "deathmatch_pbullets", deathmatch_pbullets);

   deathmatch_pbullets_damage = get_config_int("NETWORK", "deathmatch_pbullets_damage", 5); 
   set_config_int("NETWORK", "deathmatch_pbullets_damage", deathmatch_pbullets_damage);

   suicide_pbullets = get_config_int("NETWORK", "suicide_pbullets", 1); 
   set_config_int("NETWORK", "suicide_pbullets", suicide_pbullets);

   control_lead_frames = get_config_int("NETWORK", "control_lead_frames", 3); 
   set_config_int("NETWORK", "control_lead_frames", control_lead_frames);

   server_lead_frames = get_config_int("NETWORK", "server_lead_frames", 1); 
   set_config_int("NETWORK", "server_lead_frames", server_lead_frames);

   chdf_freq = get_config_int("NETWORK", "chdf_freq", 40); 
   set_config_int("NETWORK", "chdf_freq", chdf_freq);

   zlib_cmp = get_config_int("NETWORK", "zlib_cmp", 7); 
   set_config_int("NETWORK", "zlib_cmp", zlib_cmp);

   auto_save_game_on_level_done = get_config_int("LOGGING", "auto_save_game_on_level_done", 0); 
   set_config_int("LOGGING", "auto_save_game_on_level_done", auto_save_game_on_level_done);

   auto_save_game_on_exit = get_config_int("LOGGING", "auto_save_game_on_exit", 0); 
   set_config_int("LOGGING", "auto_save_game_on_exit", auto_save_game_on_exit);

   L_LOGGING = get_config_int("LOGGING", "LOGGING", 0); 
   set_config_int("LOGGING", "LOGGING", L_LOGGING);

   L_LOGGING_NETPLAY = get_config_int("LOGGING", "LOGGING_NETPLAY", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY", L_LOGGING_NETPLAY);

   L_LOGGING_NETPLAY_JOIN = get_config_int("LOGGING", "LOGGING_NETPLAY_JOIN", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_JOIN", L_LOGGING_NETPLAY_JOIN);

   L_LOGGING_NETPLAY_bandwidth = get_config_int("LOGGING", "LOGGING_NETPLAY_bandwidth", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_bandwidth", L_LOGGING_NETPLAY_bandwidth);

   L_LOGGING_NETPLAY_client_timer_adjust = get_config_int("LOGGING", "LOGGING_NETPLAY_client_timer_adjust", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_client_timer_adjust", L_LOGGING_NETPLAY_client_timer_adjust);

   L_LOGGING_NETPLAY_cdat = get_config_int("LOGGING", "LOGGING_NETPLAY_cdat", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_cdat", L_LOGGING_NETPLAY_cdat);

   L_LOGGING_NETPLAY_game_move = get_config_int("LOGGING", "LOGGING_NETPLAY_game_move", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_game_move", L_LOGGING_NETPLAY_game_move);

   L_LOGGING_NETPLAY_sdat = get_config_int("LOGGING", "LOGGING_NETPLAY_sdat", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_sdat", L_LOGGING_NETPLAY_sdat);

   L_LOGGING_NETPLAY_sdak = get_config_int("LOGGING", "LOGGING_NETPLAY_sdak", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_sdak", L_LOGGING_NETPLAY_sdak);

   L_LOGGING_NETPLAY_chdf = get_config_int("LOGGING", "LOGGING_NETPLAY_chdf", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_chdf", L_LOGGING_NETPLAY_chdf);

   L_LOGGING_NETPLAY_chdf_all_packets = get_config_int("LOGGING", "LOGGING_NETPLAY_chdf_all_packets", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_chdf_all_packets", L_LOGGING_NETPLAY_chdf_all_packets);

   L_LOGGING_NETPLAY_chdf_when_to_apply = get_config_int("LOGGING", "LOGGING_NETPLAY_chdf_when_to_apply", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_chdf_when_to_apply", L_LOGGING_NETPLAY_chdf_when_to_apply);

   L_LOGGING_NETPLAY_show_dif1 = get_config_int("LOGGING", "LOGGING_NETPLAY_show_dif1", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_show_dif1", L_LOGGING_NETPLAY_show_dif1);

   L_LOGGING_NETPLAY_show_dif2 = get_config_int("LOGGING", "LOGGING_NETPLAY_show_dif2", 0); 
   set_config_int("LOGGING", "LOGGING_NETPLAY_show_dif2", L_LOGGING_NETPLAY_show_dif2);

}


int initial_setup(void)
{
   // set version name
   #ifdef VERSION_HACK
   #include "../pm_private.h"
      sprintf(version_string, "Beta Version %s", VER_STRING);
   #else
      sprintf(version_string, "Version 6.00");
   #endif

   sprintf(msg, "Purple Martians %s", version_string);
   set_window_title(msg);

   int title_len = strlen(msg);

   printf("\n%s\n", msg);
   for (int i=0; i<title_len; i++)  printf("-");
   printf("\n");

   if (L_LOGGING)
   {  
      #ifdef LOGGING
      add_log_entry_centered_text(20, 0, 76, "", "+", "-");
      add_log_entry_position_text(20, 0, 76, 10, msg, "|", " ");
      add_log_entry_centered_text(20, 0, 76, "", "+", "-");
      #endif
   }

   // get operating system type
   show_os_detected();

   // get allegro id
   sprintf(msg, "Allegro version:    [%s]", allegro_id);
   printf("%s\n", msg);
   if (L_LOGGING)
   {  
      #ifdef LOGGING
      add_log_entry_position_text(20, 0, 76, 10, msg, "|", " ");
      #endif
   }


   // get hostname
   get_hostname();

/*
   sprintf(msg, "Local hostname:     [%s]",local_hostname);
   printf("%s\n", msg);
   #ifdef LOGGING
   add_log_entry_position_text(20, 0, 76, 10, msg, "|", " ");
   #endif

*/

   menu_setup();

   if (!init_screen()) return 0;


   if (L_LOGGING)
   {  
      #ifdef LOGGING
      add_log_entry_centered_text(20, 0, 76, "", "+", "-");
      #endif
   }

/*

   // show time and date stamp
   char tmsg[80];
   struct tm *timenow;
   time_t now = time(NULL);
   timenow = localtime(&now);
   strftime(tmsg, sizeof(tmsg), "%Y-%m-%d  %H:%M:%S", timenow);
   sprintf(msg, "Date and time:      [%s]",tmsg);
   printf("%s\n", msg);

   #ifdef LOGGING
   add_log_entry_position_text(20, 0, 76, 10, msg, "|", " ");
   add_log_entry_centered_text(20, 0, 76, "", "+", "-");
   #endif

*/

   for (int i=0; i<title_len; i++)  printf("-");
   printf("\n");

   get_config_values();

   if (install_keyboard() < 0)
   {
      sprintf(msg, "Error loading keyboard\n");
      printf("%s", msg);
      if (L_LOGGING)
      {  
         #ifdef LOGGING
         add_log_entry2(20, 0, msg);
         #endif
      }
   }

   if (install_timer() < 0)
   {
      sprintf(msg, "Error loading timer\n");
      printf("%s", msg);
      if (L_LOGGING)
      {  
         #ifdef LOGGING
         add_log_entry2(20, 0, msg);
         #endif
      }
   }
   if (install_mouse() < 0)
   {
      sprintf(msg, "Error loading mouse\n");
      printf("%s", msg);
      if (L_LOGGING)
      {  
         #ifdef LOGGING
         add_log_entry2(20, 0, msg);
         #endif
      }
   }


   show_mouse(NULL);

   seed_mdw();  // for mdw logo
   fill_mdw();

   load_keys();

   if (install_joystick(JOY_TYPE_AUTODETECT))
   {
      sprintf(msg, "Error loading joystick\n");
      printf("%s", msg);
      if (L_LOGGING)
      {  
         #ifdef LOGGING
         add_log_entry2(20, 0, msg);
         #endif
      }
   }

   LOCK_VARIABLE(timer_passcount);
   LOCK_FUNCTION(inc_timer_passcount);

   LOCK_VARIABLE(fps);
   LOCK_VARIABLE(last_fps_passcount);

   // this is for the fps
   LOCK_FUNCTION(second_timer);
   install_int_ex(second_timer, BPS_TO_TIMER(1));

   // init all
   for (int p=0; p<NUM_PLAYERS; p++) init_player(p, 1);

   // set all but 0 to inactive
   for (int p=1; p<NUM_PLAYERS; p++) players[p].active = 0;


   for (int c=0; c<100; c++) // clear block array
      for (int y=0; y<100; y++) l[c][y]=0;

   for (int i=0; i < 500; i++) // clear items
   {
      for (int y=0; y<16; y++) item[i][y] = 0;
      for (int y=0; y<4; y++) itemf[i][y] = itofix(0); 
   } 

   for (int EN=0; EN < 100; EN++) // clear enemies
   {
       for (int y=0; y < 32; y++) Ei[EN][y]  = 0;
       for (int y=0; y < 16; y++) Efi[EN][y] = itofix(0);
   }

   for (int li=0; li < NUM_LIFTS; li++) // clear lifts
   {
      clear_lift(li);
      for (int step=0; step<40; step++) clear_lift_step(li, step);
   } 
   num_lifts = 0;

   for (int c = 0; c < NUM_SPRITES; c++)
      bcmt[c] = 0;

   reset_animation_sequence_passcounts(0);
   clear(screen);
   return 1;
}



void splash_screen(void)
{
   char msg2[80];
   sprintf(msg, "Purple");
   sprintf(msg2, "Martians!");

   int ms = SCREEN_W/(16*8); // large text size
   int y_shift = 0;
   int y_co = ms*3; // center offset

   int quit = 0;
   int a = 0;
   int c = 0;


   if (!quit)
      for (float i=ms; i>.6; i*= .8)
      {
         int col = 8 + (ms - (int)i) * 16; // text color_shift
         y_shift += (int)(i * 10);          // text y_shift
         int limit = (SCREEN_H/2 - a - (int)(i*10) ); // screen edge limit
         if (y_shift < limit)
         {
            rtextout_centre(scrn_buffer, msg, SCREEN_W/2, SCREEN_H/2 - y_shift + y_co, col, i, 0);
            rtextout_centre(scrn_buffer, msg2, SCREEN_W/2, SCREEN_H/2 + y_shift - y_co, col, i, 0);
   
            rect(scrn_buffer, 0+a, 0+a, SCREEN_W-a-1, SCREEN_H-a-1, palette_color[8+(c*16)]);
            a++;
            rect(scrn_buffer, 0+a, 0+a, SCREEN_W-a-1, SCREEN_H-a-1, palette_color[8+(c*16)]);
            a++;
            rect(scrn_buffer, 0+a, 0+a, SCREEN_W-a-1, SCREEN_H-a-1, palette_color[8+(c*16)]);
            a++;
            rect(scrn_buffer, 0+a, 0+a, SCREEN_W-a-1, SCREEN_H-a-1, palette_color[8+(c*16)]);
            a++;
            c++;
   
            blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
            rest(60);

         } 

         if (keypressed())
         {
            quit = 1;
            i = 0; // to quit loop
         } 
      }

   if (!quit)
      for (int i=0; i<50; i++)
      {
         rest(5);
         if (keypressed())
         {
            quit = 1;
            i = 1000;
         } 
      }

   sprintf(msg, "created by:");
   rtextout_centre(scrn_buffer, msg, SCREEN_W/2, SCREEN_H/2, 15, 2, 0);
   blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);

   if (!quit)
      for (int i=0; i<160; i++)
      {
         rest(10);
         if (keypressed())
         {
            quit = 1;
            i = 1000;
         } 
      }

   while (!quit)
   {
      clear(scrn_buffer);
      quit = mdw_an2();
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      rest(10);
      if (keypressed()) quit = 1;
   }
   mdw_an_seq = 0;
}

void splash_toggle(void)
{
   show_splash_screen = get_config_int("SCREEN", "show_splash_screen", 1); 
 
   if (show_splash_screen)
   {
      show_splash_screen = 0;
      set_config_int("SCREEN", "show_splash_screen", show_splash_screen);
      sprintf(global_string[8][11], "Splash Screen:OFF");
   }
   else
   {
      show_splash_screen = 1;
      set_config_int("SCREEN", "show_splash_screen", show_splash_screen);
      sprintf(global_string[8][11], "Splash Screen:ON ");
      if (keypressed()) clear_keybuf();
      mdw_an_seq = 0;
      splash_screen(); // show it now....
   }
}




void game_menu(void)
{ 
   if (show_splash_screen)
   {
      show_splash_screen = 0;
      splash_screen();
   }

   load_level(start_level, 0);
   do
   {
      top_menu_sel = zmenu(7, top_menu_sel, tmy);

      // this must be before 3 because sometimes 3 calls 4 immed
      if ((top_menu_sel == 4) && (resume_allowed)) // resume game
      {
         start_mode = 0;
         timer_passcount = passcount; // sync timer_passcount to actual
         game_exit = 0;
#ifdef DUMB
         start_music();
#endif
         pm_main();
      }


      if (top_menu_sel == 3) // start new game
      {
         play_level = start_level;
         start_mode = 1; // load level and start
         game_exit = 0;
         pm_main();
      }


      if (top_menu_sel == 2) // start level 
      {
         int visual_level_select(void);
         int pl = visual_level_select();
         if (pl)
         {
            play_level = pl;
            set_start_level(pl);
            printf("lev selected level:%d\n", play_level);
            top_menu_sel = 3;
         }
         else
         {              
            resume_allowed = 0;   
            top_menu_sel = 15; // dummy mode to redraw
         }
      }



#ifdef NETPLAY
      if (top_menu_sel == 5) // host network game
      {
         play_level = start_level; 
         if (server_init())
         {
            start_mode = 1; // load level and start
            game_exit = 0;
            pm_main();
            server_exit(); 
         } 
         else server_exit(); 
         resume_allowed = 0;   
      }   
      if (top_menu_sel == 6) // join network game
      {
         if (client_init())
         {            
            start_mode = 1; // load level and start
            game_exit = 0;
            pm_main();
            client_exit(); 
         } 
         else client_exit(); 
         resume_allowed = 0;   
      }   
#endif

      if (top_menu_sel == 9) // demo mode
      {
         demo_mode();
      }  

      if (top_menu_sel == 8) // level editor
      {
         play_level = edit_menu(start_level);
         start_mode = 1;
         game_exit = 0;

         // restore menu items
         sprintf(global_string[8][7], "Screen Mode:%dx%d", sx, sy);
         set_start_level(play_level);
         set_speed();
         pm_main();
      }


      if (top_menu_sel == 10) help(""); // help


      if (top_menu_sel == 15) // dummy mode to redraw
      {
         load_level(start_level, 0);
         top_menu_sel = 2;
      }


      if (top_menu_sel == 7) // options menu
      {
         int options_menu_sel = 2;
         do
         {
            options_menu_sel = zmenu(8, options_menu_sel, tmy + 16);
            if (options_menu_sel == 7) sound_toggle();

            if (options_menu_sel == 11) splash_toggle();

            if (options_menu_sel == 10) run_dialog_netgame_conf(); // netgame configuration

            if (options_menu_sel == 12) // save game
            {
               save_gm();
            }   
            if (options_menu_sel == 13) // run game
            {
               if (load_gm(" "))
               {
                  players[0].control_method = 1;
                  start_mode = 2; // load level and start, but skip game array erasing
                  game_exit = 0;
                  pm_main();
                  players[0].control_method = 0;
      
                  // reset player data
                  for (int p=0; p<NUM_PLAYERS; p++)
                  {
                      players[p].active = 0;
                      players[p].control_method = 0;
                  }   
                  players[0].active = 1;
                  active_local_player = 0; 
               }
            }   

            if (options_menu_sel == 5) // controller setup menu
            {
               // set up menu here
               set_controller_menu_keys();
               int p1_menu_sel = 2;
               do
               {
                  p1_menu_sel = zmenu(9, p1_menu_sel, tmy+16);

                  if (p1_menu_sel == 3) test_keys();

                  if (p1_menu_sel == 4) get_all_keys(0);
      
                  if (p1_menu_sel == 5) // set all to joy1
                  {
                     players1[0].up_key = 128;
                     players1[0].down_key = 129; 
                     players1[0].right_key = 131;
                     players1[0].left_key = 130;
                     players1[0].jump_key = 133;
                     players1[0].fire_key = 132;
                     players1[0].menu_key = 135;
                  }  
      
                  if (p1_menu_sel == 6) // set all to joy2
                  {
                     players1[0].up_key = 148;
                     players1[0].down_key = 149; 
                     players1[0].right_key = 151;
                     players1[0].left_key = 150;
                     players1[0].jump_key = 153;
                     players1[0].fire_key = 152;
                     players1[0].menu_key = 155;
                  }  
      
                  if (p1_menu_sel == 7) // set all to arrows
                  {
                     players1[0].up_key = 84;
                     players1[0].down_key = 85; 
                     players1[0].right_key = 83;
                     players1[0].left_key = 82;
                     players1[0].jump_key = 75;
                     players1[0].fire_key = 3;
                     players1[0].menu_key = 59;
                  }  
      
                  if (p1_menu_sel == 8) // set all to IJKL
                  {
                     players1[0].up_key = 9;
                     players1[0].down_key = 11;
                     players1[0].right_key = 12;
                     players1[0].left_key = 10;
                     players1[0].jump_key = 75;
                     players1[0].fire_key = 3;
                     players1[0].menu_key = 59;
                  }  
      
                  if (p1_menu_sel == 10) players1[0].up_key =    my_readkey();
                  if (p1_menu_sel == 11) players1[0].down_key =  my_readkey();
                  if (p1_menu_sel == 12) players1[0].right_key = my_readkey();
                  if (p1_menu_sel == 13) players1[0].left_key =  my_readkey();
                  if (p1_menu_sel == 14) players1[0].jump_key =  my_readkey();
                  if (p1_menu_sel == 15) players1[0].fire_key =  my_readkey();
                  if (p1_menu_sel == 16) players1[0].menu_key =  my_readkey();
      
                  set_controller_menu_keys();
                  save_keys();
      
                  if ( (p1_menu_sel >= 100) && (p1_menu_sel < 200) ) p1_menu_sel -= 100; // right
                  if ( (p1_menu_sel >= 200) && (p1_menu_sel < 300) ) p1_menu_sel -= 200; // left          
      
               }  while (p1_menu_sel != 2); 
               rest(100);
               clear(screen);
            }










            if (options_menu_sel == 3) // set screen mode
            {
               void set_screen_auto_fs_desktop();
               void set_screen_manual(void);
               gui_fg_color = palette_color[14]; gui_bg_color = palette_color[14+224-32];
               int g = alert3("Screen Setup", "Auto - Desktop Resolution", "Manual - Choose Resolution", "Auto", "Manual", "Cancel", 'A', 'M', 'C');
               if (g == 1) set_screen_auto_fs_desktop();
               if (g == 2) set_screen_manual();
            }



            if ( (options_menu_sel >= 100) && (options_menu_sel < 200) )  // right
            {
               options_menu_sel -= 100;           

               if (options_menu_sel == 4) // color inc
               {
                  int zombie_allowed = 0;  
                  int p = 0;  
                  if (zombie_allowed)
                  {
                     if (++players[p].color > 15) players[p].color = 0;
                     players[p].bitmap_index = players[p].color - 1;
                     if (players[p].bitmap_index < 0 ) players[p].bitmap_index = 15;
                  }   
                  else
                  {
                     if (++players[p].color > 15) players[p].color = 1;
                     players[p].bitmap_index = players[p].color - 1;
                  }   
                  set_config_int("GAME", "color", players[p].color);
               }











               if (options_menu_sel == 6) // speed ++
               {
                  if (++speed > 500) speed = 500;
                  set_speed();
               }
               #ifdef SOUND
               if (options_menu_sel == 8) // sound effects vol ++
               {
                  extern int se_scaler;
                  if (++se_scaler > 9) se_scaler = 9;
                  set_se_scaler();
               }
               if (options_menu_sel == 9) // sound track vol ++
               {

                  #ifdef DUMB
                  extern int st_scaler;
                  if (++st_scaler > 9) st_scaler = 9;
                  set_st_scaler();
                  #endif

               }
               #endif
            }


            if ( (options_menu_sel >= 200) && (options_menu_sel < 300) ) //left
            {
               options_menu_sel -= 200;           

               if (options_menu_sel == 4) // color dec
               {
                  int zombie_allowed = 0;  
                  int p = 0;  
                  if (zombie_allowed)
                  {
                     if (--players[p].color < 0) players[p].color = 15;
                     players[p].bitmap_index = players[p].color - 1;
                     if (players[p].bitmap_index < 0 ) players[p].bitmap_index = 15;
                  }   
                  else
                  {
                     if (--players[p].color < 1) players[p].color = 15;
                     players[p].bitmap_index = players[p].color - 1;
                  }   
                  set_config_int("GAME", "color", players[p].color);
               }











               if (options_menu_sel == 6) // speed --
               {
                  if (--speed < 1) speed = 1;
                  set_speed();
               }
               #ifdef SOUND
               if (options_menu_sel == 8) // sound effects vol --
               {
                  extern int se_scaler;
                  if (--se_scaler < 0) se_scaler = 0;
                  set_se_scaler();
               }
               if (options_menu_sel == 9) // sound track vol --
               {
                  #ifdef DUMB
                  extern int st_scaler;
                  if (--st_scaler < 0) st_scaler = 0;
                  set_st_scaler();
                  #endif
               }
               #endif
            }
         }  while (options_menu_sel != 2); // end of options menu
         rest(100);
         clear(screen);
      }
      if ( (top_menu_sel >= 100) && (top_menu_sel < 200) )
      {
         // right
         top_menu_sel -= 100;           

         if (top_menu_sel == 2) // start level inc
         {
            if (key_shifts & KB_CTRL_FLAG) start_level +=100;
            else if (key_shifts & KB_SHIFT_FLAG) start_level +=10;
            else start_level++;
            if (start_level > 399) start_level = 399;
            set_start_level(start_level);
            load_level(start_level, 0);
            resume_allowed = 0;
         }
      }

      if ( (top_menu_sel >= 200) && (top_menu_sel < 300) )
      {
         // left
         top_menu_sel -= 200;           

         if (top_menu_sel == 2) // start level dec
         {
            if (key_shifts & KB_CTRL_FLAG) start_level -=100;
            else if (key_shifts & KB_SHIFT_FLAG) start_level -=10;
            else start_level--;
            if (start_level < 1) start_level = 1;
            set_start_level(start_level);
            load_level(start_level, 0);
            resume_allowed = 0;
         }
  
      }

   } while (top_menu_sel != 1); // end of game menu
}





int main(int argument_count, char **argument_array)
{

   char exe_pathandfile[80];
   char *exe_file;
   sprintf(exe_pathandfile, "%s",argument_array[0]);
   int exe_pathandfile_len = strlen(exe_pathandfile);
   exe_file = get_filename(exe_pathandfile);
   int exe_file_len = strlen(exe_file);
   int nl = exe_pathandfile_len - exe_file_len;
   exe_pathandfile[nl]=0;



// --------------------------------------------------------------------------------------------
// these flags get processed before initial setup is called
// --------------------------------------------------------------------------------------------


#ifndef RELEASE
   if (argument_count == 2) // example 'pmwin x'
   {
      void copy_files_to_clients(int exe_only);

      if (strcmp(argument_array[1],"-x") == 0 ) 
      {
          copy_files_to_clients(2); // src only
          exit(0);
      }   
      if (strcmp(argument_array[1],"-t") == 0 ) 
      {
          copy_files_to_clients(1); // pm.exe only
          exit(0);
      }   
      if (strcmp(argument_array[1],"-u") == 0 ) 
      {
         copy_files_to_clients(0); // all files
         exit(0);
      }   
   }
#endif


   allegro_init();
   set_config_file("pm.cfg");


   // this needs to be done after allegro is initialized but before initial_setup is called
   if (argument_count == 3) // example 'pm arg1 arg2'
   {
      if (strcmp(argument_array[1],"-b") == 0 ) 
      {
         sy = -1;
         sx = atoi(argument_array[2]);     
         if (sx == 0) set_config_int("SCREEN", "auto_full_screen", 1);
         else 
         {       
            if (sx == 320)  sy = 240;
            if (sx == 640)  sy = 480;
            if (sx == 800)  sy = 600;
            if (sx == 1024) sy = 768;
            if (sx == 1280) sy = 1024;
            if (sx == 1600) sy = 1200;
            if (sx == 1920) sy = 1080;
            if (sy == -1) sy = sx;
            printf("command line set resolution:%dx%d\n", sx, sy);
            set_config_int("SCREEN", "gfx_card", 2);
            set_config_int("SCREEN", "sx", sx);
            set_config_int("SCREEN", "sy", sy);
            set_config_int("SCREEN", "auto_full_screen", 0);

         }   
      }
   }   


   if (argument_count == 4) // example 'pm arg1 arg2 arg3'
   {
      if (strcmp(argument_array[1],"-b") == 0 ) 
      {
         sx = atoi(argument_array[2]);     
         sy = atoi(argument_array[3]);     
         if (sx == 0) set_config_int("SCREEN", "auto_full_screen", 1);
         else 
         {       
            printf("command line set resolution:%dx%d\n", sx, sy);
            set_config_int("SCREEN", "gfx_card", 2);
            set_config_int("SCREEN", "sx", sx);
            set_config_int("SCREEN", "sy", sy);
            set_config_int("SCREEN", "auto_full_screen", 0);
         }   
      }
   }   



   if (initial_setup())
   {
// --------------------------------------------------------------------------------------------
// these flags get processed after allegro is initialized
// --------------------------------------------------------------------------------------------
      if (argument_count == 2) // example 'pmwin arg1'
      {

         // run level editor -- eg: 'pm.exe -e'
         if (strcmp(argument_array[1],"-e") == 0 ) 
         {
            start_level = get_config_int("GAME", "start_level", 1); 
            play_level = start_level;
            set_start_level(play_level);
            printf("running level editor for level:%d\n", play_level);
            play_level = edit_menu(play_level);
            set_start_level(play_level);
            fast_exit(0);
         }  


         if (strcmp(argument_array[1],"-h") == 0 )  // help
         {
            help("Command Line");
            fast_exit(0);
         }   

#ifndef RELEASE




/*         // run packet test server

void nc_server(void);
void nc_client(void);

         if (strcmp(argument_array[1],"-x") == 0 )
         {
            nc_server(); 
            exit(0);
         }   
  
         // run packet test client
         if (strcmp(argument_array[1],"-z") == 0 )
         {
            nc_client();
            exit(0);
         }    */



         if (strcmp(argument_array[1],"-l") == 0 )  // log file viewer
         {
            void log_file_viewer(void);
            log_file_viewer();
            fast_exit(0);
         }


         if (strcmp(argument_array[1],"-g") == 0 )  // temp testing
         {


/*

            int c, r, g, b;

            c = palette_color[3];
            r = getr(c);            
            g = getg(c);            
            b = getb(c);            
            printf("3 c:%4d   r:%3d g:%3d b:%3d \n", c, r, g, b); 




            c = palette_color[9];
            r = getr(c);            
            g = getg(c);            
            b = getb(c);            
            printf("9 c:%4d   r:%3d g:%3d b:%3d \n", c, r, g, b); 


            c = palette_color[10];
            r = getr(c);            
            g = getg(c);            
            b = getb(c);            
            printf("10 c:%4d   r:%3d g:%3d b:%3d \n", c, r, g, b); 




            c = palette_color[13];
            r = getr(c);            
            g = getg(c);            
            b = getb(c);            
            printf("13 c:%4d   r:%3d g:%3d b:%3d \n", c, r, g, b); 

            c = palette_color[15];
            r = getr(c);            
            g = getg(c);            
            b = getb(c);            
            printf("15 c:%4d   r:%3d g:%3d b:%3d \n", c, r, g, b); 


            c = palette_color[173];
            r = getr(c);            
            g = getg(c);            
            b = getb(c);            
            printf("173 c:%4d   r:%3d g:%3d b:%3d \n", c, r, g, b); 

            c = palette_color[141];
            r = getr(c);            
            g = getg(c);            
            b = getb(c);            
            printf("141 c:%4d   r:%3d g:%3d b:%3d \n", c, r, g, b); 



//            tsw();






            int c, r, g, b;

            c = getpixel(memory_bitmap[400], 6, 3);
            r = getr(c);            
            g = getg(c);            
            b = getb(c);            

            int c32 = makecol32(r, g, b);

            int ccc = 56;
//            int ccc = palette_color[c];

            int cc8 = palette_color[8];

//            int cc8 = 23;


            printf("c:%4d   r:%3d g:%3d b:%3d   32:%d  ccc:%d  cc8:%d\n", c, r, g, b, c32, ccc, cc8); 


            c = getpixel(memory_bitmap[400], 7, 3);
            c = getpixel(memory_bitmap[400], 8, 3);
          
*/




/*

            int size = sizeof(players);
            int lim = size / 1;

            memmove(c_players, players, size); // copy to temp player struct for comparison

//            players[0].active++;

//            players[0].paused+=256;

//            players[0].shape = 256;



            for (i=0; i<lim; i++)
               if (memcmp(&players+i, &c_players+i, 1) != 0)
                  printf("difference found in player struct at %d bytes\n", i);
*/

/*
            int size = sizeof(players);
            char b1[size];
            char b2[size];

            memcpy(b1, players, size);

            players[0].active++;

            players[0].active = 256;

            players[1].active = 256;

            memcpy(b2, players, size);


            for (int i=0; i<size; i++)
               if (b1[i] != b2[i]) 
                  printf("difference found in player struct at %d bytes\n", i);


tsw();

*/

/*

              load_level(39, 1);
              void chunk(void);
              chunk();

*/
/*            void spline_test(void);
            void spline_adjust(void);
            void mdw_an(void);
//            spline_test();
            spline_adjust();
//            mdw_an();
*/

            // get some random numbers
            
            // suppose i want from 2-5 with .01
          
            // scale for int = *100; 
            // 200-500                        
                        
            // range = 300            
            // 300            

/*

            for (int y = 0; y<100; y++)
            {
               int r = 200 + rand() % 300;
               fixed s = itofix(r) / 100;   
               printf("[%3.2f]",fixtof(s));
            }
            tsw();

*/





//void solid_test(void);

//   solid_test();

/*
           void run_dialog_netgame_conf(void);
            run_dialog_netgame_conf();
*/

void speed_test(void);
speed_test();




// test nested if else

/*

             int a = 5;
             int b = 18;
             int c = 10;
             
             if (a == 5)
                if (b == 8)
                   if (c == 10) printf("test1\n");
                      else printf("test2\n");

                tsw();
*/

/*

            int d =4;
            while (d > 0) 
            {
               rect(screen, SCREEN_W/2-164, SCREEN_H/2-42, SCREEN_W/2+160, SCREEN_H/2-24, 11);
               sprintf(msg, "Chasing to passcount");
               rtextout_centre(screen, msg, SCREEN_W/2, SCREEN_H/2-32, 10, 2, 0);
               rectfill(screen, SCREEN_W/2-180, SCREEN_H/2-20, SCREEN_W/2+180, SCREEN_H/2+20, 0);
               rect(screen, SCREEN_W/2-180, SCREEN_H/2-20, SCREEN_W/2+180, SCREEN_H/2+16, 10);
               sprintf(msg, "[%d]", d);
               rtextout_centre(screen, msg, SCREEN_W/2, SCREEN_H/2, 10, 4, 0);
                d--;
             } 

           tsw();*/
           fast_exit(0);
         }   

#endif

#ifdef NETPLAY

         if (strcmp(argument_array[1],"-c") == 0 ) 
         {            
            show_splash_screen = 0;
            // no server specified; use the one from the config file 
//            printf("started client - looking for server IP:%s\n", m_serveraddress);
            if (client_init())
            {            
               start_mode = 1; // load level and start
               game_exit = 0;
               pm_main();
            } 
            client_exit(); 
            fast_exit(0);

         }

         if (strcmp(argument_array[1],"-s") == 0 )
         {
            show_splash_screen = 0;
            // no start level specified; use play level from config file
            play_level = start_level;
            if (server_init())
            {  
               start_mode = 1; // load level and start
               game_exit = 0;
               pm_main();
            }
            server_exit(); 
            fast_exit(0);
         }
#endif


         // keep this last so if no other single flag matches try to run like it an int level...
         // start game on specified level -- eg: 'pm.exe 211' 
         int pl = atoi(argument_array[1]);     
         if ((pl > 0) && (pl < 400))
         {
            show_splash_screen = 0;
            play_level = pl;
            set_start_level(pl);
            printf("started game on level:%d\n", play_level);
            start_mode = 1; // load level and start
            game_exit = 0;
            pm_main();
         }   
         else printf("%s could not be parsed to an integer level number\n", argument_array[1]);
      } // end of argument_count == 2  


      if (argument_count == 3) // example 'pmwin arg1 arg2'
      {
         // start game on specified level -- eg: 'pm.exe -p 211' 
         if (strcmp(argument_array[1],"-p") == 0 ) 
         {
            show_splash_screen = 0;
            int pl = atoi(argument_array[2]);     
            if ((pl > 0) && (pl < 400))
            {
               play_level = pl;
               set_start_level(pl);
               printf("started game on level:%d\n", play_level);
               start_mode = 1; // load level and start
               game_exit = 0;
               pm_main();
            }   
            else printf("%s could not be parsed to an integer level number\n", argument_array[2]);
         }         

         // run level editor for specified level -- eg: 'pm.exe -e 211'
         if (strcmp(argument_array[1],"-e") == 0 ) 
         {
            int pl = atoi(argument_array[2]);     
            if ((pl > 0) && (pl < 400))
            {
               play_level = pl;
               set_start_level(pl);
               printf("running level editor for level:%d\n", pl);
               pl = edit_menu(pl);
               set_start_level(pl);
               fast_exit(0);
            }  
            else printf("%s could not be parsed to an integer level number\n", argument_array[2]);
         }   

         // run saved game from file -- eg: 'pm.exe -f mz23.gm'
         if (strcmp(argument_array[1],"-f") == 0 )
         {
            show_splash_screen = 0;
            if (load_gm(argument_array[2]))
            {     
               printf("running game file:%s\n", argument_array[2]);
               players[0].control_method = 1;
               start_mode = 2; // load level and start, but skip game array erasing
               game_exit = 0;
               pm_main();
               fast_exit(0);
            }
         }   


#ifndef RELEASE

         // run saved game file and record video
         if (strcmp(argument_array[1],"-v") == 0 )
         {
            if (load_gm(argument_array[2]))
            {  
               printf("running game file:%s\n", argument_array[2]);
               players[0].control_method = 1;
               start_mode = 2; // load level and start, but skip game array erasing
               game_exit = 0;
               making_video = 1;
      
               char sys_cmd[500];  
               sprintf(sys_cmd, "del screenshots\\frame*.*");
               printf("%s\n",sys_cmd);
               system(sys_cmd);
   
               sprintf(sys_cmd, "del out.mp4");
               printf("%s\n",sys_cmd);
               system(sys_cmd);
   
               pm_main();
   
               sprintf(sys_cmd, "screenshots\\ffmpeg.exe -framerate 40 -start_number 000 -i \"screenshots\\frame%%05d.bmp\" -c:v h264 -r 40 -pix_fmt yuv420p out.mp4");
               printf("%s\n",sys_cmd);
               system(sys_cmd);
            }
         }   
#endif

#ifdef NETPLAY
            
         if (strcmp(argument_array[1],"-c") == 0 ) 
         {            
            show_splash_screen = 0;
            sprintf(m_serveraddress, "%s", argument_array[2]);  
//            printf("started client - looking for server IP:%s\n", m_serveraddress);
            set_config_string("NETWORK", "server_IP", m_serveraddress);
            if (client_init())
            {            
               start_mode = 1; // load level and start
               game_exit = 0;
               pm_main();
             }   
             client_exit(); 
             fast_exit(0);
         }
         if (strcmp(argument_array[1],"-s") == 0 ) 
         {            
            show_splash_screen = 0;
            play_level = atoi(argument_array[2]); 
            if (server_init())
            {  
               start_mode = 1; // load level and start
               game_exit = 0;
               pm_main();
            }
            server_exit(); 
            fast_exit(0);
         }
#endif


      } // end of argument_count == 3  

      game_menu(); // this is where it all happens
   } // end of initial setup

   blind_save_game_moves(2); 
   save_log_file();
   final_wrapup();
   exit(0);
}
END_OF_MAIN()






void copy_files_to_clients(int exe_only)
{
   char sys_cmd[500];  
   char client[20][255];
   int num_clients = 0;

// sprintf(client[num_clients++], "\\\\4230j\\pm_client3");  // win7 acer laptop
//   sprintf(client[num_clients++], "\\\\zi3\\pm_client99");  // zaiden

//   sprintf(client[num_clients++], "\\\\E6420\\pm_client5");  // win7 2560x1600 (my room)


//   sprintf(client[num_clients++], "\\\\E6400\\pm_client1");  //  E6400

  sprintf(client[num_clients++], "\\\\E6410\\pm_client2");  // win7 portable dev system  

//   sprintf(client[num_clients++], "\\\\insp9400\\pm_client11"); // dell insp 9400


//   sprintf(client[num_clients++], "\\\\DESKTOP-DBNSJH8\\pm_client8"); // win 10 EID work laptop

/*

    sprintf(client[num_clients++], "\\\\pfv\\pm_client6");    // XP 1600x1200

   sprintf(client[num_clients++], "\\\\4230-3\\pm_client7"); // ubuntu acer laptop


 
  sprintf(client[num_clients++], "\\\\m7667\\pm_client12"); // core2 2G 32bit GeForce 7500 LE
   sprintf(client[num_clients++], "\\\\nv59\\pm_client13");  // gateway nv59 i3 4G 1600x1200


   sprintf(client[num_clients++], "\\\\E6430\\pm_client4");  // win7 studio pc
   sprintf(client[num_clients++], "\\\\e4230f\\pm_client9"); // acer laptop
   sprintf(client[num_clients++], "\\\\4230a\\pm_client10"); // acer laptop
 */


   if (exe_only == 1)
   {
      printf("copying exe to clients\n");
      for (int c=0; c<num_clients; c++)
      {
         sprintf(sys_cmd, "copy pm.exe %s\\pm.exe /Y", client[c]);
         printf("%s\n",sys_cmd);
         system(sys_cmd);
         sprintf(sys_cmd, "copy pm.cfg %s\\pm.cfg /Y", client[c]);
         printf("%s\n",sys_cmd);
         system(sys_cmd);
      } 
   }
   else if (exe_only == 2)
   {
      printf("copying src to clients\n");
      for (int c=0; c<num_clients; c++)
      {
         sprintf(sys_cmd, "copy src\\*.cpp %s\\src ", client[c]);
         printf("%s\n",sys_cmd);
         system(sys_cmd);

         sprintf(sys_cmd, "copy src\\*.h %s\\src ", client[c]);
         printf("%s\n",sys_cmd);
         system(sys_cmd);

         sprintf(sys_cmd, "copy levels\\*.pml %s\\levels ", client[c]);
         printf("%s\n",sys_cmd);
         system(sys_cmd);


      } 
   }
   else
   {   
      printf("copying all files to clients\n");
      for (int c=0; c<num_clients; c++)
      {
         sprintf(sys_cmd, "xcopy *.* %s /E /Y", client[c]);
         printf("%s\n",sys_cmd);
         system(sys_cmd);
      } 
   }
}




















































