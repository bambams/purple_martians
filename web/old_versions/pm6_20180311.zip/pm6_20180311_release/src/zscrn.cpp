#include <allegro.h>
#include <math.h>
#include "pm.h"

int WX, WY;
extern int sx, sy, gfx_card, color_depth, auto_full_screen;
extern int desktop_sx, desktop_sy, desktop_colordepth;

void screen_shot_for_video(void)
{
   BITMAP *ss_bmp = NULL;
   PALETTE ss_pal;
   get_palette(ss_pal);
   ss_bmp = create_sub_bitmap(screen, 0, 0, SCREEN_W, SCREEN_H);
   char filename[80];
   sprintf(filename, "screenshots\\frame%05d.bmp", ssfnsn);
   save_bitmap(filename, ss_bmp, ss_pal);
   destroy_bitmap(ss_bmp);
   ssfnsn++;// screen shot file name sequence number
}



// do this on start and after color depth change
void create_bmp(void)
{
   for (int c=0; c<NUM_SPRITES; c++)
   {
      destroy_bitmap(memory_bitmap[c]);
      memory_bitmap[c] = create_bitmap(20,20);
      clear(memory_bitmap[c]);
   }

   for (int x=0; x<16; x++) // player bitmaps 
      for (int y=0; y<32; y++)
      {
         destroy_bitmap(player_bitmap[x][y]);
         player_bitmap[x][y] = create_bitmap(20,20);
      } 
   for (int z=0; z<2; z++)  // door bitmaps 
      for (int x=0; x<16; x++)
         for (int y=0; y<8; y++)
         {
            destroy_bitmap(door_bitmap[z][x][y]);
            door_bitmap[z][x][y] = create_bitmap(20,20);
         }  

   destroy_bitmap(scrn_buffer);
   scrn_buffer = create_bitmap(SCREEN_W, SCREEN_H);

   destroy_bitmap(l2000);
   l2000 = create_bitmap(2000,2000);

   destroy_bitmap(level_buffer);
   level_buffer = create_bitmap(2000,2000);

   destroy_bitmap(dtemp);
   dtemp = create_bitmap(20,20);
}

void proc_screen_change(void)
{
   create_bmp(); // recreate all the bitmaps

   load_sprit();

   fill_player_bitmap();
   void fill_door_bitmap(void);
   fill_door_bitmap();

   load_level(start_level, 1);

   set_scale_factor(1);
   set_map_var();
}

void save_screen_cfg(int safe)
{
   if (safe)
   {
      set_config_int("SCREEN", "sx", 640);
      set_config_int("SCREEN", "sy", 480);
      set_config_int("SCREEN", "gfx_card", 2);
      set_config_int("SCREEN", "color_depth", 8);
      set_config_int("SCREEN", "auto_full_screen", 0);
   }   
   else // current
   {
      set_config_int("SCREEN", "sx", sx);
      set_config_int("SCREEN", "sy", sy);
      set_config_int("SCREEN", "gfx_card", gfx_card);
      set_config_int("SCREEN", "color_depth", color_depth);
      set_config_int("SCREEN", "auto_full_screen", auto_full_screen);
   }
}

void log_screen_mode(void)
{
   sprintf(global_string[8][3], "Screen Mode:%dx%d", sx, sy);
   char tmsg1[80]; 
   char tmsg2[80]; 
   sprintf(msg, "Game resolution:    [%d x %d]", sx, sy);
   if (gfx_card == 1) sprintf(tmsg1, "Screen mode:        Full screen");
   if (gfx_card == 2) sprintf(tmsg1, "Screen mode:        Windowed");
   sprintf(tmsg2, "Color depth:        %d bit", color_depth);
   printf("%s\n%s\n%s\n", msg, tmsg1, tmsg2);
   if (L_LOGGING)
   {  
      #ifdef LOGGING
      add_log_entry_position_text(20, 0, 76, 10, msg, "|", " ");
      add_log_entry_position_text(20, 0, 76, 10, tmsg1, "|", " ");
      add_log_entry_position_text(20, 0, 76, 10, tmsg2, "|", " ");
      #endif
   } 
}   

void get_screen_cfg()
{
   // get graphics mode settings from config file
   sx = get_config_int("SCREEN", "sx", 640);
   sy = get_config_int("SCREEN", "sy", 480);
   gfx_card = get_config_int("SCREEN", "gfx_card", 2);
   color_depth = get_config_int("SCREEN", "color_depth", 8);
   auto_full_screen = get_config_int("SCREEN", "auto_full_screen", 1);
}

int sm_filter(int card, int w, int h, int color_depth)
{
   int ret = 1; // disable entry by default

   // first enable any resolutions we like

   if ((w == 320)   &&  (h ==  240)) ret = 0;    
   if ((w == 640)   &&  (h ==  480)) ret = 0;    
   if ((w == 800)   &&  (h ==  600)) ret = 0;    
   if ((w == 1024)  &&  (h ==  768)) ret = 0;    
   if ((w == 1280)  &&  (h == 1024)) ret = 0;    
   if ((w == 1600)  &&  (h == 1200)) ret = 0;    
   if ((w == 1920)  &&  (h == 1080)) ret = 0;    
   if ((w == desktop_sx) && (h ==  desktop_sy)) ret = 0;    

   // disable full screen modes for 8 bit
   if ((card == 1) && (color_depth == 8))
      if ((os_type != OSTYPE_LINUX) && (os_type != OSTYPE_WINXP)) // make an exception for these systems known to work
         ret = 1;

   // disable if not 8 or 16
   if (color_depth == 15) ret = 1;
   if (color_depth == 24) ret = 1;
   if (color_depth == 32) ret = 1;

   // disable 16 for windowed
   if ((card == 2) && (color_depth == 16)) ret = 1;


   // allow only auto full and auto windowed 
   if ((card != 1) && (card != 2)) ret = 1;

   return ret;   
}    

void set_screen_manual(void)
{
   auto_full_screen = 0;
   int new_sx = sx;
   int new_sy = sy;
   int new_gfx_card = gfx_card;
   int new_color_depth = color_depth;

   if (gfx_mode_select_filter(&new_gfx_card, &new_sx, &new_sy, &new_color_depth, sm_filter))
   {
      set_color_depth(new_color_depth);
      if (set_gfx_mode(new_gfx_card, new_sx, new_sy, 0, 0) != 0)
      {
         sprintf(msg, "Error setting resolution manually: [%d x %d] gfx_card:%d color_depth:%d", sx, sy, gfx_card, color_depth);
         alert(msg, allegro_error, NULL, "Sorry", NULL, 13, 0);
         printf("%s\n", msg);
         if (L_LOGGING)
         {  
            #ifdef LOGGING
            add_log_entry2(20, 0, msg);
            #endif
         }      
         // revert to previous mode
         set_color_depth(color_depth);
         set_gfx_mode(gfx_card, sx, sy, 0, 0);
         gui_fg_color = palette_color[255]; gui_bg_color = palette_color[0];
      }
      else
      {
         sx = new_sx;
         sy = new_sy;
         gfx_card = new_gfx_card; 
         color_depth = new_color_depth;
         //sprintf(msg, "Success setting resolution manually: [%d x %d] gfx_card:%d color_depth:%d", sx, sy, gfx_card, color_depth);
         //printf("%s\n", msg);
         save_screen_cfg(0);
         log_screen_mode();
         proc_screen_change();
      }
   }   
}


void set_screen_auto_fs_desktop()
{
   get_desktop_resolution(&desktop_sx, &desktop_sy);
   sx = desktop_sx;  
   sy = desktop_sy;
   gfx_card = 1;
   auto_full_screen = 1;

/*   // set to desktop color_depth
   desktop_colordepth = desktop_color_depth();
   color_depth = desktop_colordepth; */

/*   // if color depth has been set to 32 we won't force it to change
   // if it is 8 force to 16, unless xp or linux
   if ((color_depth < 16) && (os_type != OSTYPE_LINUX) && (os_type != OSTYPE_WINXP) // make an exception for these systems known to work
      color_depth =16;  */

   // force 16 for full screen, unless xp or linux, then force 8
   color_depth = 16;
   if ((os_type == OSTYPE_LINUX) || (os_type == OSTYPE_WINXP)) color_depth = 8;


   set_color_depth(color_depth);

   if (set_gfx_mode(gfx_card, sx, sy, 0, 0) == 0)
   { 
      //sprintf(msg, "Success setting resolution auto full screen: [%d x %d] gfx_card:%d color_depth:%d", sx, sy, gfx_card, color_depth);
      //printf("%s\n", msg);
      save_screen_cfg(0);
      log_screen_mode();
      proc_screen_change();
   }   
   else  // failed
   {
      sprintf(msg, "Error setting resolution auto full screen: [%d x %d]", sx, sy);
      alert(msg, allegro_error, NULL, "Sorry", NULL, 13, 0);
      printf("%s\n", msg);
      if (L_LOGGING)
      {  
         #ifdef LOGGING
         add_log_entry2(20, 0, msg);
         #endif
      }      
      save_screen_cfg(1); // set to safe mode
      get_screen_cfg(); 
      set_color_depth(color_depth);
      set_gfx_mode(2, sx, sy, 0, 0);
      log_screen_mode();
      proc_screen_change();
   }
}


int init_screen(void)
{
   // get desktop resolution
   get_desktop_resolution(&desktop_sx, &desktop_sy);
   desktop_colordepth = desktop_color_depth();

   sprintf(msg, "Desktop resolution: [%d x %d] %d bit", desktop_sx, desktop_sy, desktop_colordepth);
   printf("%s\n", msg);
   if (L_LOGGING)
   {  
      #ifdef LOGGING
      add_log_entry_position_text(20, 0, 76, 10, msg, "|", " ");
      #endif
   }
   get_screen_cfg();
   if (auto_full_screen) set_screen_auto_fs_desktop();
   else
   {
      int frg = 0; // forgiveness factor, full screen can be exact but windowed mode needs to be smaller or it will fail
      if (gfx_card == 2)
      {
         frg = 16;
         color_depth = 8;  // force 8 for windowed mode  
      }
      // check if we are trying to set a mode bigger than the desktop screen
      if ((sx > desktop_sx-frg) || (sy > desktop_sy-frg))
      {
         sx = 1024;  // try a lower resolution
         sy = 768;
      }  
      // still too big?
      if ((sx > desktop_sx-frg) || (sy > desktop_sy-frg))
      {
         sx = 800;   // try a lower resolution
         sy = 600;
      }   
      // how about now?
      if ((sx > desktop_sx-frg) || (sy > desktop_sy-frg))
      {
         sx = 640;  // try a lower resolution
         sy = 480;
      }   
   
      set_color_depth(color_depth);
   
      if (set_gfx_mode(gfx_card, sx, sy, 0, 0) != 0)
      { 
         save_screen_cfg(1); // set to safe mode
         sprintf(msg, "Error setting resolution: [%d x %d]", sx, sy);
         alert(msg, allegro_error, NULL, "Sorry", NULL, 13, 0);
         printf("%s\n", msg);
         if (L_LOGGING)
         {  
            #ifdef LOGGING
            add_log_entry2(20, 0, msg);
            #endif
         }      
         return 0;
      }   
      else
      {
         save_screen_cfg(0);
         log_screen_mode();
         proc_screen_change();
      }
   }
   return 1;
}
   
void show_os_detected(void)
{
   char tmsg[80];
   strcpy(tmsg, "?");

   if (os_type == OSTYPE_UNKNOWN) strcpy(tmsg, "unknown, or regular MSDOS");
   if (os_type == OSTYPE_WIN3) strcpy(tmsg, "Windows 3.1 or earlier");
   if (os_type == OSTYPE_WIN95) strcpy(tmsg, "Windows 95");
   if (os_type == OSTYPE_WIN98) strcpy(tmsg, "Windows 98");
   if (os_type == OSTYPE_WINME) strcpy(tmsg, "Windows ME");
   if (os_type == OSTYPE_WINNT) strcpy(tmsg, "Windows NT");
   if (os_type == OSTYPE_WIN2000) strcpy(tmsg, "Windows 2000");
   if (os_type == OSTYPE_WINXP) strcpy(tmsg, "Windows XP");
   if (os_type == OSTYPE_WIN2003) strcpy(tmsg, "Windows 2003");
   if (os_type == OSTYPE_WINVISTA) strcpy(tmsg, "Windows Vista");
   if (os_type == OSTYPE_WIN7) strcpy(tmsg, "Windows 7");
   if (os_type == OSTYPE_OS2) strcpy(tmsg, "OS/2");
   if (os_type == OSTYPE_WARP) strcpy(tmsg, "OS/2 Warp 3");
   if (os_type == OSTYPE_DOSEMU) strcpy(tmsg, "Linux DOSEMU");
   if (os_type == OSTYPE_OPENDOS) strcpy(tmsg, "Caldera OpenDOS");
   if (os_type == OSTYPE_LINUX) strcpy(tmsg, "Linux");
   if (os_type == OSTYPE_SUNOS) strcpy(tmsg, "SunOS/Solaris");
   if (os_type == OSTYPE_FREEBSD) strcpy(tmsg, "FreeBSD");
   if (os_type == OSTYPE_NETBSD) strcpy(tmsg, "NetBSD");
   if (os_type == OSTYPE_OPENBSD) strcpy(tmsg, "OpenBSD");
   if (os_type == OSTYPE_IRIX) strcpy(tmsg, "IRIX");
   if (os_type == OSTYPE_DARWIN) strcpy(tmsg, "Darwin");
   if (os_type == OSTYPE_QNX) strcpy(tmsg, "QNX");
   if (os_type == OSTYPE_UNIX) strcpy(tmsg, "Unknown Unix variant");
   if (os_type == OSTYPE_BEOS) strcpy(tmsg, "BeOS");
   if (os_type == OSTYPE_HAIKU) strcpy(tmsg, "Haiku");
   if (os_type == OSTYPE_MACOS) strcpy(tmsg, "MacOS");
   if (os_type == OSTYPE_MACOSX) strcpy(tmsg, "MacOS X");
   if (os_type == OSTYPE_PSP) strcpy(tmsg, "PSP");

   sprintf(msg, "OS detected:        [%s] [ver:%d.%d]", tmsg, os_version, os_revision);

   printf("%s\n", msg);
   if (L_LOGGING)
   {  
      #ifdef LOGGING
      add_log_entry_position_text(20, 0, 76, 10, msg, "|", " ");
      #endif
   }
}     

void get_new_background(void)
{
   blit(l2000, level_buffer, 0, 0, 0, 0, 2000, 2000);
}   

void blit_buffer_to_screen(void)
{
   blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
}     

void get_new_screen_buffer(void)
{
   int alp = active_local_player;
   int c = players[alp].color;

   clear(scrn_buffer);

   // draw frame in local player's color 
   for (int x=0;x<BORDER_WIDTH;x++)
      rect(scrn_buffer, x, x, SCREEN_W-1-x, SCREEN_H-1-x,  palette_color[c + (x * 16)] );

   // default place and size to draw on screen_buffer
   int bw = BORDER_WIDTH;
   int sbx = bw;
   int sby = bw;
   int sbw = SCREEN_W-bw*2;
   int sbh = SCREEN_H-bw*2;

   // how big is the entire level after scale factor is applied?
   extern float scale_factor_current;
   int sls = (int) ((float)2000 * scale_factor_current); // sls = scaled level size

   // is the entire level smaller than the screen buffer width?
   if (sls < sbw)
   {
      int a = sbw - sls; // how much smaller?
      sbw = sls;         // new screen_buffer blit width = sls
      sbx += a/2;        // new screen_buffer blit xpos
   }

   // is the entire level smaller than the screen buffer height?
   if (sls < sbh)
   {
      int a = sbh - sls; // how much smaller?
      sbh = sls;         // new screen_buffer blit height = sls
      sby += a/2;        // new screen_buffer blit ypos
   }
   
   // find the size of the source screen from actual screen size and scaler
   int SW = (int)( (float)(SCREEN_W - bw *2) / scale_factor_current);
   int SH = (int)( (float)(SCREEN_H - bw *2) / scale_factor_current);
   if (SW > 2000) SW = 2000;
   if (SH > 2000) SH = 2000;

   // find where to grab the source screen from based on the players position
   int PX = fixtoi(players[alp].PX) + 10;
   int PY = fixtoi(players[alp].PY) + 10;

/*   // this method always has the player in the middle of the screen
   int WX = PX - SW/2 -10; // set window from PX, PY
   int WY = PY - SH/2 -10;
*/

   // this method has a hysteresis rectangle in the middle of the screen where there is no scroll 
   // show this at end of function after we get scrn buffer....

//   int x_size = SW / 4; // larger number is smaller window
//   int y_size = SH / 4;

   int x_size = SW / 18; // larger number is smaller window
   int y_size = SH / 18;


   if (WX < PX - SW/2 - x_size) WX = PX - SW/2 - x_size; // hit right edge
   if (WX > PX - SW/2 + x_size) WX = PX - SW/2 + x_size; // hit left edge
   if (WY < PY - SH/2 - y_size) WY = PY - SH/2 - y_size; // hit bottom edge
   if (WY > PY - SH/2 + y_size) WY = PY - SH/2 + y_size; // hit top edge

   // correct for edges
   if (WX < 0) WX = 0;
   if (WY < 0) WY = 0;
   if (WX > (2000 - SW)) WX = 2000 - SW;
   if (WY > (2000 - SH)) WY = 2000 - SH;

   // this is the what all the previous calculation have been building up to 
   stretch_blit(level_buffer, scrn_buffer, WX, WY, SW, SH, sbx, sby, sbw, sbh);


   // where is the player on the screen buffer ??
   // needed to see if the map is covering player
   float psbx = (PX-WX-10) * scale_factor_current;
   float psby = (PY-WY-10) * scale_factor_current;
   float fsz = 20 * scale_factor_current; 

   // convert to int
   int px = (int) psbx+bw;
   int py = (int) psby+bw;
   int sz = (int) fsz;

   // show rect around player to make sure I've got it
   //rect (scrn_buffer, px, py, px+sz, py+sz, palette_color[10]);

   // save in player struct
   players1[alp].sbx1 = px;
   players1[alp].sby1 = py;
   players1[alp].sbx2 = px+sz;
   players1[alp].sby2 = py+sz;

   // show hysteresis window
   /*float fhx1 = SCREEN_W/2 - x_size * scale_factor_current;
   float fhx2 = SCREEN_W/2 + x_size * scale_factor_current;
   float fhy1 = SCREEN_H/2 - y_size * scale_factor_current;
   float fhy2 = SCREEN_H/2 + y_size * scale_factor_current;
   int hx1 = (int)fhx1;
   int hy1 = (int)fhy1;
   int hx2 = (int)fhx2;
   int hy2 = (int)fhy2;
   rect (scrn_buffer, hx1, hy1, hx2, hy2, palette_color[10]); */
}

   
void init_l2000(void) // fill l2000 with blocks and lift lines (called by load_level only and level editor)
{
   clear(l2000);
   for (int x=0; x<100; x++) 
      for (int y=0; y<100; y++)
      {
         int c = l[x][y];
         if (c < NUM_SPRITES) draw_sprite(l2000, memory_bitmap[c], x*20, y*20);
      }
   draw_lift_lines();
}

void draw_ebullets(void);
void draw_pbullets(void);


void draw_level2(BITMAP *bmp, int mx, int my, int ms, int blocks, int items, int enemies, int lifts, int players)
{

   if (blocks) get_new_background();
   else clear(level_buffer);     

   if (valid_level_loaded)
   {
      if (lifts)   draw_lifts();          
      if (items)   draw_items();          
      if (enemies) draw_enemy();          
      if (resume_allowed)
      {
         if (players) draw_players();         
         draw_ebullets();       
         draw_pbullets();       
      }
   }  
   stretch_blit(level_buffer, bmp, 0, 0, 2000, 2000, mx, my, ms, ms);
}     



void draw_level_centered(BITMAP *bmp, int screen_x, int screen_y, int level_x, int level_y, float scale_factor) 
{
   // use scale factor to determine scaled size of level
   int size = (int)(scale_factor * 2000);
   int mgx = screen_x - (int) (level_x * scale_factor);  // start x pos on level  
   int mgy = screen_y - (int) (level_y * scale_factor);  // start y pos on level  
   stretch_blit(level_buffer, bmp, 0, 0, 2000, 2000, mgx, mgy, size, size);
}     


void draw_level(BITMAP *b) // draws the map on the menu screen 
{

   int blocks = 0;
   if (valid_level_loaded) blocks = 1;  

   extern int menu_map_size;
   extern int menu_map_x;
   extern int menu_map_y;

/*
   int y_size = SCREEN_H-160;
   int x_size = SCREEN_W-260;

   if (y_size < x_size) menu_map_size = y_size;
   else menu_map_size = x_size;
   if (menu_map_size < 10) menu_map_size = 10;

   menu_map_x = SCREEN_W/2-(menu_map_size/2);
   menu_map_y = 140;
*/

   draw_level2(b, menu_map_x, menu_map_y, menu_map_size, blocks, 1, 1, 1, 1);

   int y_pos = 140;
   int x_pos = SCREEN_W/2+(menu_map_size/2);


   // clear level data background
   rectfill(b, x_pos, 140, x_pos + 118, y_pos+240, palette_color[0]);




   // show level data
   if (valid_level_loaded)
   {
      y_pos = enemy_data(scrn_buffer, x_pos, y_pos) + 8; 
      y_pos = item_data(scrn_buffer, x_pos, y_pos) + 8;
      sprintf(msg, "%d Lifts  ", num_lifts);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[15], 0);
      sprintf(msg, "-------");
      textout_ex(b, font, msg, x_pos, y_pos + 8, palette_color[15], 0);
   }

   int tmtx = SCREEN_W / 2;
   int tmty = 124;

   if (resume_allowed)
   {
      char msg1[80];
      sprintf(msg1, " Level %d ", start_level);
      textout_centre_ex(b, font, msg1,         tmtx, tmty,   palette_color[11], 0);
      textout_centre_ex(b, font, "  (paused)  ", tmtx, tmty+8, palette_color[14], 0);
   }
   else if (valid_level_loaded) 
   {
      sprintf(msg, " Level %d ", start_level);
      textout_centre_ex(b, font, msg, tmtx, tmty, palette_color[11], 0);
      textout_centre_ex(b, font, "  start level  ", tmtx, tmty+8, palette_color[9], 0);
   }
   else
   {
      sprintf(msg, " Level %d ", start_level);
      textout_centre_ex(b, font, msg, tmtx, tmty, palette_color[11], 0);
      textout_centre_ex(b, font, "  not found !  ", tmtx, tmty+8, palette_color[10], 0);
   }
}

void draw_title(BITMAP * bmp, int tx, int ty, int color)
{
   //sprintf(msg, "Purple Martians!");// default title
   sprintf(msg, "%s Martians!", color_name[color]); // overwrite with color

   // draw the big fancy title on its own bitmap
   BITMAP *pm_title = create_bitmap(280,20);
   BITMAP *temp_title = create_bitmap(140,8);
   if (get_color_depth() == 8)
   {
      clear(pm_title);
      clear(temp_title);
   }
   else 
   {
      clear_to_color(pm_title, makecol(255, 0, 255));
      clear_to_color(temp_title, makecol(255, 0, 255));
   }   

   textout_centre_ex(temp_title, font, msg, 70, 0, palette_color[color + 192], -1);

   for (int x=0; x<5; x++)
      for (int y=0; y<5; y++)
         stretch_sprite(pm_title, temp_title, x, y, 280, 16);

   textout_centre_ex(temp_title, font, msg, 70, 0, palette_color[color + 128], -1);

   stretch_sprite(pm_title, temp_title, 1,1,280,16);
   stretch_sprite(pm_title, temp_title, 1,3,280,16);
   stretch_sprite(pm_title, temp_title, 3,1,280,16);
   stretch_sprite(pm_title, temp_title, 3,3,280,16);

   textout_centre_ex(temp_title, font, msg, 70, 0, palette_color[color], -1);
   stretch_sprite(pm_title, temp_title, 2,2,280,16);

   draw_sprite(bmp, pm_title, tx, ty);

   destroy_bitmap(pm_title);
   destroy_bitmap(temp_title);
}



void frame_and_title(BITMAP *b)
{
   int p = active_local_player;
   int color = players[p].color;

   // draw the border
   for (int x = 0; x < BORDER_WIDTH; x++)
      rect(b, x, x, SCREEN_W-1-x, SCREEN_H-1-x,  palette_color[color + (x * 16)] );

   // draw the title on top on the border 
   draw_title(b, (SCREEN_W/2) - 140, 2, color);


   // draw the player on a block
//   draw_sprite(screen, player_bitmap[players[p].bitmap_index][1], 54, 50 );
//   blit(memory_bitmap[32], screen, 0, 0,          56, 70, 20, 20);

  // draw a line of players on each side of menu

/*
   fixed rot = ftofix(0);
   fixed sc = ftofix(5);
   int x = SCREEN_W/2 - 180; 
   int y = BORDER_WIDTH + 20;
   rotate_scaled_sprite(screen, player_bitmap[players[p].bitmap_index][1], x , y, rot, sc);


   rot = ftofix(128);
   x = SCREEN_W/2 + 80; 
   rotate_scaled_sprite_v_flip(screen, player_bitmap[players[p].bitmap_index][1], x , y, rot, sc);

*/

   // draw a line of players on each side of menu
   color = players[p].color;               // initial color
   int lim = 12;                           // number of players to draw
   float flsc = 5;                         // initial scale 
   float y_pos = 20;                       // initial y position 
   float y_step = 20 / lim;                // inc to raise 20
   float x_pos = SCREEN_W/2 - 180;      // initial x position
   int dist = (int)x_pos - BORDER_WIDTH;   // how much space do I have?

   // how much space will it take based on how many to draw ???
   float x_sp = (dist - 240) / (lim-1);     // spacing to stretch row to screen edge 

   for (float a=0; a<lim; a++)
   {
      fixed sc = ftofix(flsc);            // scale
      int y = BORDER_WIDTH + (int)y_pos;  // y position
      y_pos -= y_step;                    // move up 

      int x = (int)x_pos;                 // x position
      x_pos -= 11*flsc;                   // spacing based on scale  
      x_pos -= x_sp;                      // extra spacing stretch row to edge of screen
      flsc *= .78;                        // reduce scale by 78%

      rotate_scaled_sprite(b, player_bitmap[color - 1][1], x , y, itofix(0), sc);
      if (++color > 15) color = 1;        // cycle through players colors  
   }
   color = players[p].color;               // initial color
   flsc = 5;                               // initial scale 
   y_pos = 20;                             // initial y position 
   y_step = 20 / lim;                      // inc to raise 20
   x_pos = SCREEN_W/2 + 80;             // initial x position
   dist = SCREEN_W - BORDER_WIDTH - (int)x_pos;   // how much space do I have?

   // how much space will it take based on how many to draw ???
   x_sp = (dist - 360) / (lim-1);          // spacing to stretch row to screen edge 

   for (float a=0; a<lim; a++)
   {
      fixed sc = ftofix(flsc);             // scale
      int y = BORDER_WIDTH + (int)y_pos;   // y position
      y_pos -= y_step;                     // move up 
      int x = (int)x_pos;                  // x position
      x_pos += 15.1*flsc;                  // spacing based on scale  
      x_pos += x_sp;                       // extra spacing stretch row to edge of screen
      flsc *= .78;                         // reduce scale by 78%
      x_sp += .5;                          // hack to make things line up on right hand side of screen
      rotate_scaled_sprite_v_flip(b, player_bitmap[color - 1][1], x , y, itofix(128), sc);
      if (++color > 15) color = 1;        // cycle through players colors  
   }
   color = players[p].color;

   sprintf(msg, "%s", version_string);
   textout_centre_ex(b, font, msg, SCREEN_W/2, SCREEN_H-9, palette_color[15], -1);
}



void stimp(void)
{
   int num_steps = 20;
   int delay = 2;

   // find the size of the source screen from actual screen size and scaler
   extern float scale_factor_current;
   int bw = BORDER_WIDTH;
   int SW = (int)( (float)(SCREEN_W - bw *2) / scale_factor_current);
   int SH = (int)( (float)(SCREEN_H - bw *2) / scale_factor_current);

   if (SW > 2000) SW = 2000;
   if (SH > 2000) SH = 2000;

   // find where to grab the source screen from based on the players position
   int alp = active_local_player;
   int PX = fixtoi(players[alp].PX) + 10;
   int PY = fixtoi(players[alp].PY) + 10;

   // this method has a hysteresis rectangle in the middle of the screem where there is no scroll 
   int x_size = SW / 18; // larger number is smaller window
   int y_size = SH / 18;
   if (WX < PX - SW/2 - x_size) WX = PX - SW/2 - x_size;
   if (WX > PX - SW/2 + x_size) WX = PX - SW/2 + x_size;
   if (WY < PY - SH/2 - y_size) WY = PY - SH/2 - y_size;
   if (WY > PY - SH/2 + y_size) WY = PY - SH/2 + y_size;

   // correct for edges
   if (WX < 0) WX = 0;
   if (WY < 0) WY = 0;
   if (WX > (2000 - SW)) WX = 2000 - SW;
   if (WY > (2000 - SH)) WY = 2000 - SH;

   // this is where the player will be when stimp is done and the level starts
   PX = fixtoi(players[alp].PX);
   PY = fixtoi(players[alp].PY);

   float px_final = (PX-WX) * scale_factor_current + bw;
   float py_final = (PY-WY) * scale_factor_current + bw;  

   // this is the menu map's position and size 
   y_size = SCREEN_H-160;
   x_size = SCREEN_W-260;
   int size;
   if (y_size < x_size) size = y_size;
   else size = x_size;
   if (size < 10) size = 10;
   int mx = SCREEN_W/2-(size/2);
   int my = 140;

   // get the players position on the menu map
   int map_px = mx + PX * size / 2000;
   int map_py = my + PY * size / 2000;


   float sc = (float)size / 2000; 
   float scf = scale_factor_current;
   // do the scale increment as a percent change so that the zoom speed is constant
   // use the compound interest formula to find the percent change per step I need
   float a, per = 1.000;
   do 
   {
       per += .0001;
       a = sc * pow(per, num_steps);
   }
   while (a < scf);

   float fmx = (float)map_px;
   float fmxf = px_final;
   float fmxinc = (fmxf - fmx) / num_steps;

   float fmy = (float)map_py;
   float fmyf = py_final;
   float fmyinc = (fmyf - fmy) / num_steps;

   for (int steps = 0; steps<num_steps; steps++)
   {   
      clear(scrn_buffer); // use the scrn_buffer and clear it to avoid map smears when shrinking
      draw_level_centered(scrn_buffer, (int)fmx, (int)fmy, PX, PY,  sc);     
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      sc *= per; 
      fmx += fmxinc;
      fmy += fmyinc;
      rest (delay);
   }
}     


void stamp(void)
{
   int num_steps = 20;
   int delay = 2;

   // find the size of the source screen from actual screen size and scaler
   extern float scale_factor_current;
   int bw = BORDER_WIDTH;
   int SW = (int)( (float)(SCREEN_W - bw *2) / scale_factor_current);
   int SH = (int)( (float)(SCREEN_H - bw *2) / scale_factor_current);
   if (SW > 2000) SW = 2000;
   if (SH > 2000) SH = 2000;

   // find where to grab the source screen from based on the players position
   int alp = active_local_player;
   int PX = fixtoi(players[alp].PX) + 10;
   int PY = fixtoi(players[alp].PY) + 10;

   // this method has a hysteresis rectangle in the middle of the screem where there is no scroll 
   int x_size = SW / 18; // larger number is smaller window
   int y_size = SH / 18;
   if (WX < PX - SW/2 - x_size) WX = PX - SW/2 - x_size;
   if (WX > PX - SW/2 + x_size) WX = PX - SW/2 + x_size;
   if (WY < PY - SH/2 - y_size) WY = PY - SH/2 - y_size;
   if (WY > PY - SH/2 + y_size) WY = PY - SH/2 + y_size;

   // correct for edges
   if (WX < 0) WX = 0;
   if (WY < 0) WY = 0;
   if (WX > (2000 - SW)) WX = 2000 - SW;
   if (WY > (2000 - SH)) WY = 2000 - SH;

   // this is where the player will be when stimp is done and the level starts
   PX = fixtoi(players[alp].PX);
   PY = fixtoi(players[alp].PY);

   float px_final = (PX-WX) * scale_factor_current + bw;
   float py_final = (PY-WY) * scale_factor_current + bw;  

   // this is the menu map's position and size 
   y_size = SCREEN_H-160;
   x_size = SCREEN_W-260;
   int size;
   if (y_size < x_size) size = y_size;
   else size = x_size;
   if (size < 10) size = 10;
   int mx = SCREEN_W/2-(size/2);
   int my = 140;

   // get the players position on the menu map
   int map_px = mx + PX * size / 2000;
   int map_py = my + PY * size / 2000;

   float sc = scale_factor_current;
   float scf = (float)size / 2000; 

   // do the scale increment as a percent change so that the zoom speed is constant
   // use the compound interest formula to find the percent change per step I need
   float a, per = 1.000;
   do 
   {
       per -= .0001;
       a = sc * pow(per, num_steps);
   }
   while (a > scf);

   float fmx = px_final;
   float fmxf = (float)map_px;
   float fmxinc = (fmxf - fmx) / num_steps;

   float fmy = py_final;
   float fmyf = (float)map_py;
   float fmyinc = (fmyf - fmy) / num_steps;

   for (int steps = 0; steps<num_steps; steps++)
   {   
      clear(scrn_buffer); // use the scrn_buffer and clear it to avoid map smears when shrinking
      draw_level_centered(scrn_buffer, (int)fmx, (int)fmy, PX, PY,  sc);     
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      sc *= per; 
      fmx += fmxinc;
      fmy += fmyinc;
      rest (delay);
   }
}     

void proc_scale_factor_change(void)
{
   show_scale_factor--;
   extern float scale_factor;
   extern float scale_factor_current;
   extern float scale_factor_inc;
   
   if (scale_factor_current < scale_factor)
   {
       // try to scale the inc, larger as scale_factor gets larger
       float inc = scale_factor_inc * scale_factor_current/3;
       scale_factor_current += inc;
       // if we overshoot set to exact to prevent oscillation
       if (scale_factor_current > scale_factor) scale_factor_current = scale_factor;
   }  
   if (scale_factor_current > scale_factor)
   {
       // try to scale the inc, larger as scale_factor gets larger
       float inc = scale_factor_inc * scale_factor_current/3;
       scale_factor_current -= inc;
       // if we overshoot set to exact to prevent oscillation
       if (scale_factor_current < scale_factor) scale_factor_current = scale_factor;
   }  
}



void rtextout_centre(BITMAP *dbmp, char *txt1, int x, int y, int col, float scale, int rot)
{
   // draws rotated stretched text
   // used in many places
   int sw = strlen(txt1) * 8;
   BITMAP *temp = create_bitmap(sw, 8);
   if (get_color_depth() == 8) clear(temp);
   else clear_to_color(temp, makecol(255, 0, 255));
   textout_centre_ex(temp, font, txt1, sw/2, 0, palette_color[col], -1);
   pivot_scaled_sprite(dbmp, temp, x, y, sw/2, 4 , itofix(rot), ftofix(scale));
   destroy_bitmap(temp);
}

void mtextout(BITMAP *dbmp, char *txt1, int x, int y, float x_scale, float y_scale, int col)
{
   // can show mirror image text when scales are negative
   // used only mdw logo animation
   int sw = strlen(txt1) * 8;      // string length in pixels
   int sh = 8;                     // string height in pixels
   BITMAP *temps = NULL;
   temps = create_bitmap(sw,sh);
   if (get_color_depth() == 8) clear(temps);
   else clear_to_color(temps, makecol(255, 0, 255));
   textout_ex(temps, font, txt1, 0, 0, palette_color[col], 0);

   // get destination bitmap size
   int dw = abs( (int) ((float)sw * x_scale) );
   int dh = abs( (int) ((float)sh * y_scale) );

   if (dh > 1) // can't create a bitmap with height less than 1
   {
      BITMAP *tempd = NULL;
      tempd = create_bitmap(dw, dh);
      if (get_color_depth() == 8) clear(tempd);
      else clear_to_color(tempd, makecol(255, 0, 255));

      stretch_sprite(tempd, temps, 0, 0, dw, dh);
      if ((x_scale > 0) && (y_scale > 0)) rotate_scaled_sprite(dbmp, tempd, x, y, itofix(0), itofix(1));   
      if ((x_scale > 0) && (y_scale < 0)) rotate_scaled_sprite_v_flip(dbmp, tempd, x, y, itofix(0), itofix(1));   
      if ((x_scale < 0) && (y_scale > 0)) rotate_scaled_sprite_v_flip(dbmp, tempd, x-dw, y, itofix(128), itofix(1));   
      if ((x_scale < 0) && (y_scale < 0)) rotate_scaled_sprite(dbmp, tempd, x-dw, y, itofix(128), itofix(1));   
      destroy_bitmap(tempd);
   }
   destroy_bitmap(temps);
}

void mtextout_centre(BITMAP *dbmp, char *txt1, int x, int y, float x_scale, float y_scale, int col)
{
   // used only by bottom message
   int sw = strlen(txt1) * 8;      // string length in pixels
   int sh = 8;                     // string height in pixels

   BITMAP *temp = NULL;
   temp = create_bitmap(sw,sh);
   if (get_color_depth() == 8) clear(temp);
   else clear_to_color(temp, makecol(255, 0, 255));

   int dw = (int) ((float)sw * x_scale);
   int dh = (int) ((float)sh * y_scale);

   textout_ex(temp, font, txt1, 0, 0, palette_color[col], -1);
   stretch_sprite(dbmp, temp, x-dw/2, y, dw, dh);
   destroy_bitmap(temp);
}

void show_level_done(int keypress)
{
   float x_scale = (float)SCREEN_W/40;
   float y_scale = (float)SCREEN_H/16;
   x_scale /= 1.5;
   y_scale /= 1.5;

   int x = SCREEN_W/2;
   int y = SCREEN_H/2;
   int yu = y - (int)(y_scale*8);
   int col = 9; // color
   int ns = 8;  // num of shadows 
   int ci = 16; // color inc  
   int st = 6;  // skip step between 1st and 2nd color  

   for (int a = ns; a >= 0; a--)
   {
      int b = col+a*ci;
      if (a) b = col+( (a+st) * ci); // not first color 
      mtextout_centre(screen, "Level", x+a, yu+a, x_scale, y_scale, b);
      mtextout_centre(screen, "Done!", x+a, y+a, x_scale, y_scale, b);
   }
   if (keypress)
   {
      x_scale = (float)SCREEN_W/240;
      x_scale /= 1.2;
      y_scale = x_scale;
      y = SCREEN_H - (int)(y_scale*9) - BORDER_WIDTH;
      mtextout_centre(screen, "...press any key to continue...", x, y, x_scale, y_scale, 5);
      tsw();
   }
}

void set_map_position() 
{

//  1   9   2
//      |
// -----+-----
//      |
//  4   |   3

   int alp = active_local_player;

   int px1 = players1[alp].sbx1;
   int py1 = players1[alp].sby1;
   int px2 = players1[alp].sbx2;
   int py2 = players1[alp].sby2;

//   printf("gmo:%d mx:%d my:%d px1:%d py1:%d px2:%d py2:%d\n",game_map_on, map_x, map_y, px1, py1, px2, py2);
   switch (game_map_on)
   {
      case 0:
         map_x = BORDER_WIDTH;
         map_y = BORDER_WIDTH;
      break;            
      case 1:
         map_x = BORDER_WIDTH;
         map_y = BORDER_WIDTH;
         // check to see if player is covered by the map
         if ((px1 < map_x + map_size)
          && (py1 < map_y + map_size))  game_map_on = 2;  
      break;            
      case 2:
         map_x = SCREEN_W - map_size - BORDER_WIDTH;
         map_y = BORDER_WIDTH;
         if ((px2 > map_x)
          && (py1 < map_y + map_size))  game_map_on = 1;  
      break;            
      case 3:
         map_x = SCREEN_W - map_size - BORDER_WIDTH;
         map_y = SCREEN_H - map_size - BORDER_WIDTH;
         if ((px2 > map_x)
          && (py2 > map_y))  game_map_on = 4;  
      break;            
      case 4:
         map_x = BORDER_WIDTH;
         map_y = SCREEN_H - map_size - BORDER_WIDTH;
         if ((px1 < map_x + map_size)
          && (py2 > map_y))  game_map_on = 3;  
      break;            
      case 9:
         map_x = SCREEN_W/2 - map_size/2;
         map_y = BORDER_WIDTH;
         if ((px2 > map_x)
          && (px1 < map_x + map_size)
          && (py1 < map_y + map_size))  game_map_on = 4;  
      break;            
   }
}

void next_map_mode()
{
   int old_game_map_on = game_map_on;
   switch (game_map_on)
   {
      case 0: game_map_on = 1; break;            
      case 1: game_map_on = 2; break;            
      case 2: game_map_on = 3; break;            
      case 3: game_map_on = 4; break;            
      case 4: game_map_on = 9; break;            
      case 9: game_map_on = 0; break;            
   }
   set_map_position();
   if (old_game_map_on == game_map_on) game_map_on = 0;
}

void next_map_size()
{
   int smin = 0;
   if (SCREEN_H < SCREEN_W) smin = SCREEN_H;
   else smin = SCREEN_W;
        if (new_size == smin /4) new_size = smin/3; // 1/3
   else if (new_size == smin /3) new_size = smin/2; // 1/2
   else if (new_size == smin /2) new_size = smin/4; // 1/4
   else  new_size = smin /3; // if for some reason none of these match
}     

void draw_map()
{
   if (game_map_on)
   {
      // process the size change gradually
      if (map_size < new_size)
      {
         map_size+=30;
         if (map_size > new_size) map_size = new_size;
      }
      if (map_size > new_size)
      {
         map_size-=60;
         if (map_size < new_size) map_size = new_size;
      }
      set_map_position();
      stretch_blit(level_buffer, scrn_buffer, 0,0, 2000, 2000, map_x, map_y, map_size, map_size);     
   }
}

void draw_percent_bar(BITMAP *bmp, int cx, int y, int width, int height, int percent)
{
   int x = cx - width/2; // centering
   int w2 = (int) (width * ((float)percent/100)); // how much green
       rectfill(bmp, x, y, x + width, y + height, palette_color[10]); //  red   
   if (percent > 0)
      rectfill (bmp, x, y, x + w2   , y + height, palette_color[11]); //  green   
   rect(bmp, x, y, x + width, y + height, palette_color[15]);         //  white frame
}



void show_player_join_quit(void)
{
   int t =  show_player_join_quit_timer--;
   int jq = show_player_join_quit_jq;
   int p = show_player_join_quit_player;
   int color = players[p].color;

   if (jq == 0) sprintf(msg, "Player %d left the game!", p);
   if (jq == 1) sprintf(msg, "Player %d joined the game!", p);
   if (jq == 3) sprintf(msg, "Player %d DIED!", p);
   if (jq == 4) sprintf(msg, "Player %d SYNC CHECK FAIL!", p);

   if (jq == 5) sprintf(msg, "Player %d LOST SERVER CONNECTION", p);

   float stretch = ( (float)SCREEN_W / (strlen(msg)*8)) - 1; // (SCREEN_W / text length*8) -1
   float ratio = (float)t / 60;

   int y_pos = SCREEN_H/2;
   int y_pos_move = SCREEN_H/2;

   if (ratio > .6)
   {
        float ra1 = 1 - ratio;                 // starts at 0 and increases to .3
        float ra2 = ra1 * 2.5;                // starts at 0 and increases to .999
        stretch =  ra2 * stretch;
        y_pos = y_pos - y_pos_move + (int)(ra2 * y_pos_move);
   }      
   if (ratio < .4)
   {
        float ra1 = .4 - ratio;                // starts at 0 and increases to .3
        float ra2 = ra1 * 2.5;                // starts at 0 and increases to .999
        stretch -=  ra2 * stretch;
        y_pos += (int)(ra2 * y_pos_move);
   }
   if (stretch < .1) stretch = .1;
   rtextout_centre(scrn_buffer, msg, SCREEN_W/2, y_pos, color, stretch, 0);
}









void draw_fps_display(BITMAP *dbmp, int show_type)
{
   extern int fps;
   extern int frames_skipped_last_second;
   int y = 2;

   int p = active_local_player;
   int color = players[p].color; 
   int color_mode = -1; // transparent

   int fs = players1[p].frames_skipped;
   int fsls = frames_skipped_last_second;


   // are we not in a netgame
   if ((players[p].control_method == 0) || (players[p].control_method == 1))
   {
      if (passcount_timer_fps != 40) show_type = 1;
      //if (fs) show_type = 2;
      if (fsls) show_type = 2;
   }
   else
   {
      if (fs) show_type = 4;
      if (fsls) show_type = 5;
   }
   if (show_type == 8) sprintf(msg, "%dfps", fps);
   if (show_type == 1) sprintf(msg, "FPS set:%d act:%d", passcount_timer_fps, fps);
   if (show_type == 2) sprintf(msg, "frame skip:[%d]  FPS set:%d act:%d", fsls, passcount_timer_fps, fps);
   if (show_type == 3) sprintf(msg, "skip:%d total:%d FPS set:%d act:%d", fsls, fs, passcount_timer_fps, fps);
   if (show_type == 4) sprintf(msg, "total frames skipped:%d", fs);
   if (show_type == 5) sprintf(msg, "frame skip:%d  total:%d", fsls, fs);
   if (show_type != 8) color = 14;
   if (show_type) textout_ex(dbmp, font, msg, SCREEN_W - (strlen(msg)+2) * 8, y, palette_color[color], color_mode);
}



void draw_top_display(void)
{
   if (show_player_join_quit_timer) show_player_join_quit();

   extern int num_enemy;
   int p = active_local_player;
   int tdx = BORDER_WIDTH;
   int tdy = 0;

   int color_mode = 0;


   if (SCREEN_W < 600) // special case for narrow screens       
   {
      sprintf(msg,"Lv:%d Tm:%d En:%d" , play_level, passcount/40, num_enemy);
      textout_ex(scrn_buffer, font, msg, tdx, tdy+2, palette_color[14], -1);
      tdx += strlen(msg)*8 + 8;
   }
   else 
   {
      sprintf(msg,"Level:%d | Time:%d | Enemies:%d" , play_level, passcount/40, num_enemy);
      textout_ex(scrn_buffer, font, msg, tdx, tdy+2, palette_color[14], -1);
      tdx += strlen(msg)*8 + 16;

      if (!making_video) draw_fps_display(scrn_buffer, 8);

   }   

   // draw health bar
   draw_percent_bar(scrn_buffer, tdx+44, tdy, 88, 10, fixtoi(players[p].LIFE));
   sprintf(msg,"Health:%-2d", fixtoi(players[p].LIFE));
   textout_centre_ex(scrn_buffer, font, msg, tdx+44, tdy+2, palette_color[14], -1);
   tdx += 88; 

   // draw free men
   for (int a=0; a<players[p].LIVES; a++)
      stretch_sprite(scrn_buffer, player_bitmap[players[p].bitmap_index][1], tdx+8+(a*10), tdy+1, 10, 10);


   if (demo_mode_on)
   {
      float ts = (float)SCREEN_W / 72; // length of "Demo Mode"      

      ts /= 2;

      int x = SCREEN_W/2;
      int y = BORDER_WIDTH + (int)(8 * ts);



  //    mtextout(scrn_buffer, "Demo Mode", SCREEN_W/2, SCREEN_H - BORDER_WIDTH-40, 8, 4, 10);




      rtextout_centre(scrn_buffer, "Demo Mode", x, y, 9, ts, 0);
      
   }



   if (show_scale_factor > 0)
   {
      extern float scale_factor;
      sprintf(msg, "Scale:%-3.2f", scale_factor);
//      textout_centre_ex(scrn_buffer, font, msg, SCREEN_W/2, BORDER_WIDTH+2,  palette_color[15], -1);

      textout_centre_ex(scrn_buffer, font, msg, SCREEN_W*2/3, 2,  palette_color[15], -1);


   } 


   int cy = BORDER_WIDTH-6;
   int cx = SCREEN_W-320;


   // common debug overlay for all modes
   if ((show_debug_overlay) || (speed_testing))
   {

      if (ima_server) {cx = BORDER_WIDTH; cy+=80;}


      int color = 15;
      int fps_color = 14;

      extern int fps;
      extern int frames_skipped_last_second;
   
      int fs = players1[p].frames_skipped;
      int fsls = frames_skipped_last_second;

      char tmsg[80];
      sprintf(tmsg, "full screen");
      if (is_windowed_mode())sprintf(tmsg, "windowed");

      extern int fps;
      int cd = bitmap_color_depth(screen); 

      int csx = SCREEN_W;
      int csy = SCREEN_H;

      // show screen mode
      sprintf(msg, "%dx%d %2dbit %s", csx, csy, cd, tmsg );
      textout_ex(scrn_buffer, font, msg, cx, cy+=8,  palette_color[color], color_mode);


      extern float scale_factor;
      sprintf(msg, "scale_factor:%f", scale_factor);
      textout_ex(scrn_buffer, font, msg, cx, cy+=8,  palette_color[color], color_mode);

      cy+=4;

      sprintf(msg, "FPS set:%d act:%d", passcount_timer_fps, fps);
      textout_ex(scrn_buffer, font, msg, cx, cy+=8,  palette_color[fps_color], color_mode);

      sprintf(msg, "frames skipped last second:%d", fsls);
      textout_ex(scrn_buffer, font, msg, cx, cy+=8, palette_color[fps_color], color_mode);

      sprintf(msg, "total frames skipped:%d",fs);
      textout_ex(scrn_buffer, font, msg, cx, cy+=8, palette_color[fps_color], color_mode);


/*
      cy+=4;

      sprintf(msg, "px:%d     py:%d", fixtoi(players[p].PX), fixtoi(players[p].PY));
      textout_ex(scrn_buffer, font, msg, cx, cy+=8,  palette_color[color], color_mode);

      sprintf(msg, "pxinc:%1.2f  pyinc:%1.2f", fixtof(players[p].xinc), fixtof(players[p].yinc));
      textout_ex(scrn_buffer, font, msg, cx, cy+=8,  palette_color[color], color_mode);
*/
   }


   #ifdef NETPLAY
   if (ima_server)
   {
      int bdx = BORDER_WIDTH;
      int bdy = SCREEN_H - 10;
      int ts = 0;  // text spacing 

      sprintf(msg, "Netgame Server (%s) ", players1[p].hostname );
      textout_ex(scrn_buffer, font, msg, bdx, bdy, palette_color[14], -1);
      ts += strlen(msg)*8;            

       // calculate num of clients
       int num_clients = 0; 
       for (int p=0; p<NUM_PLAYERS; p++)
          if ((players[p].active) && (players[p].control_method == 2)) num_clients++;
       
      //sprintf(msg, "[clients:%d] [moves:%d]", num_clients, game_move_entry_pos);
      sprintf(msg, " clients:%d ", num_clients);
      textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
      ts += strlen(msg)*8;            

      // total bandwidth
      int tb = players1[0].tx_bytes_per_tally + players1[0].rx_bytes_per_tally;
      if (tb < 1000) sprintf(msg, "(%dB/s)", tb);  
      else
      {
         float ftb = (float)tb/1000; 
         sprintf(msg, "(%3.1fkB/s)", ftb);  
      }  
      textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
      ts += strlen(msg)*8;            

      //sprintf(msg, " zlib_cmp:%d ", zlib_cmp);
//         sprintf(msg, " chdf freq:%d ", chdf_freq);
//         textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
//         ts += strlen(msg)*8;            

      #ifndef RELEASE
      if (show_debug_overlay)
      {
         //int color_mode = -1; // transparent
         // int color_mode = 0; // black background
         int color_mode = palette_color[127+64]; // grey background
         int x = BORDER_WIDTH;
         int y = BORDER_WIDTH-8;

         sprintf(msg, "[p][wh][a][co][m][sync][lasd][late][start][destn][np][difs][tkbp][rkbs][dfcr][frsk][name]");
         textout_ex(scrn_buffer, font, msg, x, y + 8, palette_color[13], color_mode);

         for (int p=0; p<NUM_PLAYERS; p++)
         {
            y += 8;            

            if (players[p].control_method != 2) players1[p].last_sdak_rx = passcount; // only do sync for active clients

            sprintf(msg, "[%d][%2d][%d][%2d][%d][%4d][%4d][%4d][%5d][%5d][%2d][%4d][%4.1f][%4.1f][%4d][%4d]",
                                              p, 
                                              players1[p].who,
                                              players[p].active,
                                              players[p].color,
                                              players[p].control_method,
                                              players1[p].server_sync,
                                              passcount - players1[p].last_sdak_rx,
                                              players1[p].chdf_late,
                                              client_chdf_id[p][0],
                                              client_chdf_id[p][1],
                                              players1[p].num_dif_packets,
                                              players1[p].cmp_dif_size,
                                              (float)players1[p].tx_bytes_per_tally/1000,
                                              (float)players1[p].rx_bytes_per_tally/1000,
                                              players1[p].dif_corr,
                                              players1[p].frames_skipped);

            int color = 15;
            if (players[p].active == 0) color = 63;
            if (players[p].active == 1) color = 15;

            textout_ex(scrn_buffer, font, msg, x, y + 8, palette_color[color], color_mode);

            int sl = strlen(msg);

            if (p == 0)
            {
               sprintf(msg, "[%s] <-- server (me!)", players1[p].hostname);
               textout_ex(scrn_buffer, font, msg, x+(sl)*8, y + 8, palette_color[players[p].color], color_mode);
            }

            if ((players[p].active) && (players[p].control_method == 2))
            {
               sprintf(msg, "[%s] <-- active client", players1[p].hostname);
               textout_ex(scrn_buffer, font, msg, x+(sl)*8, y + 8, palette_color[players[p].color], color_mode);
            }

            if ((!players[p].active) && (players[p].control_method == 2))
            {
               sprintf(msg, "[%s] <-- syncing client", players1[p].hostname);
               textout_ex(scrn_buffer, font, msg, x+(sl)*8, y + 8, palette_color[players[p].color], color_mode);
            }
            if (players[p].control_method == 9)
            {
               sprintf(msg, "[%s] <-- used client", players1[p].hostname);
               textout_ex(scrn_buffer, font, msg, x+(sl)*8, y + 8, palette_color[color], color_mode);
            }

            if ( (players[p].active) || (players[p].control_method == 2) || (players[p].control_method == 9))
            {
               sprintf(msg, "[%2d]", players[p].color);
               textout_ex(scrn_buffer, font, msg, x+(10*8), y + 8, palette_color[players[p].color], color_mode);
            }   
         }

/*
         int pty = 120; 
         for(int p=0; p<NUM_PLAYERS; p++)
            if (players[p].active)
            {
               sprintf(msg, "p:%d bandwidth (B/s) TX cur:[%5d] max:[%5d] RX cur:[%5d] max:[%5d]", p, players1[p].tx_bytes_per_tally, players1[p].tx_max_bytes_per_tally, players1[p].rx_bytes_per_tally, players1[p].rx_max_bytes_per_tally);  
               textout_ex(scrn_buffer, font, msg, 80, pty+=8, palette_color[15], 0);
            }

         pty += 8; 
         for(int p=0; p<NUM_PLAYERS; p++)
            if (players[p].active)
            {
               sprintf(msg, "p:%d packets per second TX cur:[%5d] max:[%5d] RX cur:[%5d] max:[%5d]", p, players1[p].tx_packets_per_tally, players1[p].tx_max_packets_per_tally, players1[p].rx_packets_per_tally, players1[p].rx_max_packets_per_tally);  
               textout_ex(scrn_buffer, font, msg, 80, pty+=8, palette_color[15], 0);
            }
*/
      }
      #endif

   }   
   if (ima_client)
   {
      int color = players[p].color; 

      if (!players[p].active) 
      {
         sprintf(msg, "Please wait for server syncronization");
         rtextout_centre(scrn_buffer, msg, SCREEN_W/2, SCREEN_H/2-32, color, 2, 0);

         sprintf(msg, "[%d]", players1[p].server_sync);
         rtextout_centre(scrn_buffer, msg, SCREEN_W/2, SCREEN_H/2, color, 4, 0);
      }


      int bdx = BORDER_WIDTH;
      int bdy = SCREEN_H - 10;
      int ts = 0;  // text spacing 

      sprintf(msg, "Netgame Client (%s) ", local_hostname );
      textout_ex(scrn_buffer, font, msg, bdx, bdy, palette_color[14], -1);
      ts += strlen(msg)*8;            

      sprintf(msg, "sync:%d ", players1[p].server_sync);
      textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
      ts += strlen(msg)*8;            


/*
      sprintf(msg, " clf:%d ", control_lead_frames);
      textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
      ts += strlen(msg)*8;            

      sprintf(msg, " slf:%d ", server_lead_frames);
      textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
      ts += strlen(msg)*8;            
*/


/*         sprintf(msg, "ssync:%d ", server_sync);
      textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
      ts += strlen(msg)*8;            

      sprintf(msg, "csync:%d ", players1[p].c_sync);
      textout_ex(scrn_buffer, font, msg, bdx + ts, bdy, palette_color[14], -1);
      ts += strlen(msg)*8;            
*/ 


/*

      if (players1[p].client_sync_good)
      { 
         sprintf(msg, " sync good ");
         textout_ex(scrn_buffer, font, msg, bdx + ts, bdy, palette_color[14], -1);
      }
      else
      {
         sprintf(msg, " sync bad ");
         textout_ex(scrn_buffer, font, msg, bdx + ts, bdy, 10, -1);
         rtextout_centre(scrn_buffer, msg, SCREEN_W/2, SCREEN_H-64, 10, 2, 0);
      }
*/

      if (players1[p].serr_display_timer)
      {
         players1[p].serr_display_timer--;
         sprintf(msg, "server dropped client's input %d times!", players1[p].serr_c_sync_err);
         rtextout_centre(scrn_buffer, msg, SCREEN_W/2, SCREEN_H-32, 10, 2, 0);
      }

/*
//      if (1) // always show
//      if ((players[p].active) && (players[p].c_sync_err))  // only show errors if active and there are any
      if (players1[p].c_sync_err) // only show when errors
      {
         sprintf(msg, "[%d] client sync errors!!!", players1[p].c_sync_err);
         rtextout_centre(scrn_buffer, msg, SCREEN_W/2, SCREEN_H-32, 10, 2, 0);
      }

*/


      #ifndef RELEASE
      if (show_debug_overlay) // show a bunch of data for trouble shooting 
      {  
         int color_mode = palette_color[127+64]; // solid grey background
         //int color_mode = 0;   // solid black background 
         //int color_mode = -1; // transparent

         int ty = 120;

         if (players1[p].chdf_rx > 0) 
         {
            sprintf(msg, "chdf rx'd:%d on_time:%d late:%d [%d]", 
                          players1[p].chdf_rx, players1[p].chdf_on_time, 
                          players1[p].chdf_late, (players1[p].chdf_on_time * 100) / players1[p].chdf_rx);
            textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);
       }


         sprintf(msg, "dif corrections:%d ", players1[p].dif_corr);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);


         sprintf(msg, "late cdats dropped by server:%d", players1[p].serr_c_sync_err);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "game moves lead from server:%d min:%d err:%d", players1[p].c_sync, players1[p].c_sync_min, players1[p].c_sync_err);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);


         sprintf(msg, "server sync:%d ", players1[p].server_sync);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "moves:%d", game_move_entry_pos);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "moves skipped:%d", players1[p].moves_skipped);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "moves skipped per second :%d", players1[p].moves_skipped_last_tally);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "sdat skipped:%d", players1[p].sdat_skipped);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "frames_skipped:%d", players1[p].frames_skipped);
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);


         ty +=8;

         sprintf(msg, "bandwidth (bytes per second)");
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "TX currrent:[%d] max:[%d]", players1[p].tx_bytes_per_tally, players1[p].tx_max_bytes_per_tally);  
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "RX currrent:[%d] max:[%d]", players1[p].rx_bytes_per_tally, players1[p].rx_max_bytes_per_tally);  
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         ty +=8;

         sprintf(msg, "packets per second");
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "TX currrent:[%d] max:[%d]", players1[p].tx_packets_per_tally, players1[p].tx_max_packets_per_tally);  
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);

         sprintf(msg, "RX currrent:[%d] max:[%d]", players1[p].rx_packets_per_tally, players1[p].rx_max_packets_per_tally);  
         textout_ex(scrn_buffer, font, msg, 80, ty+=8, palette_color[15], color_mode);


         int x = 80;
         int y = 40;

          
         // print player array for client

         sprintf(msg, "[p][a][co][m]");
         textout_ex(scrn_buffer, font, msg, x, y, palette_color[13], color_mode);
         for (int p=0; p<NUM_PLAYERS; p++)
         {
            y += 8;            
            char ms[80]; 
            sprintf(ms, " ");

            if ((players[p].active) && (players[p].control_method == 2))
               sprintf(ms, " <-- active client");

            if ((!players[p].active) && (players[p].control_method == 2))
               sprintf(ms, " <-- syncing client");

            if (players[p].control_method == 9) sprintf(ms, " <-- used client");

            if (p == active_local_player) sprintf(ms, " <-- active local player (me!)");
            if (p == 0) sprintf(ms, " <-- server");
   
            sprintf(msg, "[%d][%d][%2d][%d]%s",
                                     p, 
                                     players[p].active,
                                     players[p].color,
                                     players[p].control_method,
                                     ms );
               
            int color = 15;
            if (players[p].active == 0) color = 63;
            if (players[p].active == 1) color = 15;
            if (players1[p].c_sync_err)  color = 10; 
            textout_ex(scrn_buffer, font, msg, x, y, palette_color[color], color_mode);

            // colorize only active, syncing or used  
            if ( (players[p].active) || (players[p].control_method == 2) || (players[p].control_method == 9))
            {
               sprintf(msg, "[%2d]", players[p].color);
               textout_ex(scrn_buffer, font, msg, x+(6*8), y, palette_color[players[p].color], color_mode);
            }   

            if (p == active_local_player)
            { 
               sprintf(msg, " <-- active local player (me!)");
               textout_ex(scrn_buffer, font, msg, x+(13*8), y, palette_color[players[p].color], color_mode);
            } 

         }
      } // end of debug overlay
      #endif

} // end of if (imaclient)
#endif
   
   if (players[0].control_method == 1) // file play
   {
      // find last gm with passcount !=0
      int last_pc;
      for (int g = game_move_entry_pos; g>0; g--)
         if (game_moves[g][0] != 0)
         {
            last_pc = game_moves[g][0];
            break; // exit loop immed   
         }      
   
      extern int game_move_current_pos;  
      int current = game_move_current_pos;  
      int total = game_move_entry_pos;  

      int bdx = BORDER_WIDTH;
      int bdy = SCREEN_H - 10;
      int ts = 0;  // text spacing 

      if (making_video)
      {
         screen_shot_for_video();
         printf("Time:[%d%%]\n", passcount*100/last_pc);

         sprintf(msg, "Recording Video From Saved Game  ");
         textout_centre_ex(screen, font, msg, SCREEN_W/2, SCREEN_H/2, palette_color[15], 0);
   
         sprintf(msg, "Time:[%d%%] ", passcount*100/last_pc);
         textout_centre_ex(screen, font, msg, SCREEN_W/2, SCREEN_H/2+8, palette_color[15], 0);

      }  
      else
      {  
         cy+=4;
         sprintf(msg, "Running Saved Game  ");
         textout_ex(scrn_buffer, font, msg, bdx, bdy, palette_color[14], -1);
         ts += strlen(msg)*8;            
         if (show_debug_overlay) textout_ex(scrn_buffer, font, msg, cx, cy+=8, palette_color[15], color_mode);
   
         sprintf(msg, "Time:[%d%%] ", passcount*100/last_pc);
         textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
         ts += strlen(msg)*8;            
         if (show_debug_overlay) textout_ex(scrn_buffer, font, msg, cx, cy+=8, palette_color[15], color_mode);
   
         sprintf(msg, "Moves:[%d%%] ", (current*100)/total);
         textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
         ts += strlen(msg)*8;            
         if (show_debug_overlay) textout_ex(scrn_buffer, font, msg, cx, cy+=8, palette_color[15], color_mode);
           
         sprintf(msg, "Active player:[%d] ",active_local_player);
         textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[14], -1);
         ts += strlen(msg)*8;            
         if (show_debug_overlay) textout_ex(scrn_buffer, font, msg, cx, cy+=8, palette_color[15], color_mode);



         if (show_debug_overlay)
         {
             cy+=4;
             sprintf(msg, "Active players:");
             textout_ex(scrn_buffer, font, msg, cx, cy+=8, palette_color[15], color_mode);
         }


         for (int ap=0; ap<NUM_PLAYERS; ap++)
         {
            if (players[ap].active)   
            {
               sprintf(msg, "%d", ap);
               textout_ex(scrn_buffer, font, msg, bdx + ts, bdy,  palette_color[players[ap].color], -1);
               ts += strlen(msg)*8;            

               sprintf(msg, "Player:%d", ap);
               if (show_debug_overlay) textout_ex(scrn_buffer, font, msg, cx, cy+=8, palette_color[players[ap].color], color_mode);

            }
         }   





      } 

   }     
}


void draw_bottom_msg()
{
   extern int bottom_msg;
   if (--bottom_msg > 0)
   {
      extern char b_msg[40][80];
      int a;
      int nb = 4;    // NUM_BOTTOM_MSG_LINES
   
      float chs = 1.3; // current h size
      float hss = .2;  // h size step
   
      float cvs = 1.3; // current v size
      float vss = .2;  // v size step
   
      int cc = 15; // current color
      int ci = 48;    // color inc use  only 16, 32, 48, 64 etc
   
      float ypos = SCREEN_H - (chs*8);
      for (a=0; a< nb; a++)
      {
         mtextout_centre(scrn_buffer, b_msg[a], SCREEN_W/2, (int)ypos, cvs, chs, cc);
   
         chs = chs - hss;
         cvs = cvs - vss;
         cc = cc + ci;
   
         float xh = (chs*8);
         ypos -= xh;
      }
   
   }
   else bottom_msg = 0;
}



   


























































/*





int d_slider_proc1(int msg, DIALOG *d, int c)
{
   int ret = d_slider_proc(msg, d, c);  // pass to slider function   

//   printf("slider pos:%d\n", test_val[2].d2);

   if (ret == D_GOTMOUSE)
   {
      test_int = test_val[2].d2;
      set_gui_txt();
      return D_REDRAW;
   }
   return ret;
}







extern DIALOG test_val[];


int d_button_proc1(int msg, DIALOG *d, int c)
{
   int ret = d_button_proc(msg, d, c);  // pass to button function   
   if (ret == D_CLOSE)
   {
      test_bool = !test_bool;
      set_gui_txt();
      return D_REDRAW;
   }

   return ret;
}






void set_gui_txt(void)
{
    sprintf(ti_txt, "ti:%d",test_int);    
    sprintf(tb_txt, "tb:%d",test_bool);    

}

int test_int = 32;
char ti_txt[100];

int test_bool = 0;
char tb_txt[100];




DIALOG test_val[] =
{
   // (dialog proc)     (x)   (y)   (w)   (h)   (fg)  (bg)  (key) (flags)  (d1)       (d2)   (dp)           (dp2)      (dp3) 
   { d_box_proc,        100,  100,  320,  200,  255,  0,    0,     0,       0,          0,    NULL,         NULL,      NULL  },
   { d_ctext_proc,      200,  110,    0,    0,   13,  0,    0,     0,       0,          0,    (char *) "Netgame Configuration" },

   { d_slider_proc1,     110,  150,  140,   16,   13,  0,    0,   D_EXIT,   100,        0,   NULL,    NULL, NULL  },


   { d_text_proc,       252,  154,   0,    0,   13,  0,    0,     0,       0,          0,    ti_txt },

   { d_button_proc1,    110,  130,  80,  20,    255,  0,    13,    D_EXIT,  0,          0,    tb_txt,      NULL, NULL  },


   { tb_dm,             110,  200,  300,  20,    255,  0,    13,    D_EXIT,  0,          0,    dm_txt,      NULL, NULL  },
   { tb_sb,             110,  225,  300,  20,    255,  0,    13,    D_EXIT,  0,          0,    sb_txt,      NULL, NULL  },




   { d_text_proc,       110,  250,   0,    0,   13,  0,    0,     0,       0,       0,   (char *)"Server IP or hostname:" },


   { d_edit_proc,       288,  250,  100,  10,   255,  0,    0,     0,  sizeof(m_serveraddress)-1, 0, m_serveraddress,   NULL  },





   { d_button_proc,     110,  175,  80,  20,    255,  0,    13,    D_EXIT,  0,          0,    (char *)"OK",      NULL, NULL  },
   { d_button_proc,     210,  175,  80,  20,    255,  0,    27,    D_EXIT,  0,          0,    (char *)"Cancel",  NULL, NULL  },
   { NULL,              0,    0,    0,    0,      0,  0,    0,     0,       0,          0,     NULL,       NULL, NULL  },
};



void run_dialog_test(void)
{
   //set slider's initial position from varaiable
   test_val[2].d2 = test_int;

   //set server from varaiable




   set_gui_txt();
   int ret = do_dialog(test_val, -1);
   printf("ret:%d\n", ret);

   if (ret == 9) // OK button
   {
      printf("Returned OK\n");
      set_config_int("NETWORK", "deathmatch_pbullets", deathmatch_pbullets);
      set_config_int("NETWORK", "suicide_pbullets", suicide_pbullets);
      set_config_string("NETWORK", "server_IP", m_serveraddress);

   }         
   
   if (ret == 10) // cancel button
   {
      printf("Returned Cancel\n");
   }

}






//   D_EXIT = 1
//   D_SELECTED = 2
//   D_GOTFOCUS = 4
//   D_GOTMOUSE = 8
//   D_HIDDEN = 16
//   D_DISABLED = 32
//   D_DIRTY = 64



//   D_OK = 0
//   D_CLOSE = 1
//   D_REDRAW = 2
//   D_REDRAWME = 4
//   D_WANT_FOCUS == 8

*/


extern char m_serveraddress[256];
char dm_txt[100];
char sb_txt[100];


void set_gui_txt(void)
{
   if (deathmatch_pbullets) sprintf(dm_txt, "Death Match Player Bullets:On ");    
   else sprintf(dm_txt, "Death Match Player Bullets:Off");    
   if (suicide_pbullets) sprintf(sb_txt, "Suicide Player Bullets:On ");    
   else sprintf(sb_txt, "Suicide Player Bullets:Off");    
}

int mslid(int msg, DIALOG *d, int c)
{
   int x1 = 110;
   int x2 = 410;
   int y1 = 220;
   int y2 = 240;
   char tmsg[80];
   int r = deathmatch_pbullets_damage;
   int e = x1 + (r*3);
   switch (msg)
   {
      case MSG_DRAW:
         rectfill(screen, x1, y1, x2, y2,  palette_color[0]);    // erase to background color
         rect    (screen, x1, y1, x2, y2,  palette_color[13] );    // draw frame
         rectfill(screen, e, y1+1, e+3, y2-1, palette_color[127]); // draw slider bar
         sprintf(tmsg,"Deathmatch Player Bullets Damage:%d",r);
         textout_centre_ex(screen, font, tmsg, x1 + (x2-x1)/2, y1+6, palette_color[13], -1);
      break;
      case MSG_CLICK:
         while (mouse_b & 1)
         {
            if ((mouse_y >  y1) && (mouse_y < y2) ) r = ((mouse_x - x1) / 3);
            if (r < 0) r = 0; 
            if (r > 100) r = 100; 
   
            if (r != deathmatch_pbullets_damage)
            {

               show_mouse(NULL);
               set_clip_rect(screen, x1+1, y1+1, x2-1, y2-1);   

               rectfill(screen, x1, y1, x2, y2,  palette_color[0]);    // erase to background color
               rect    (screen, x1, y1, x2, y2,  palette_color[13] );    // draw frame
   
               e = x1 + (r*3);
               rectfill(screen, e-2, y1+1, e+2, y2-1, palette_color[10]); // draw slider bar
               
               sprintf(tmsg,"Deathmatch Player Bullets Damage:%d",r);
               textout_centre_ex(screen, font, tmsg, x1 + (x2-x1)/2, y1+6, palette_color[13], -1);
               set_clip_rect(screen, 0, 0, SCREEN_W, SCREEN_H);   
               show_mouse(screen);
   
               deathmatch_pbullets_damage = r;
            }
            rest(20);
         }
         return D_REDRAW;
      break;
   }
   return D_O_K;
}




int tb_dm(int msg, DIALOG *d, int c)
{
   int ret = d_button_proc(msg, d, c);  // pass to button function   
   if (ret == D_CLOSE)
   {
      deathmatch_pbullets = !deathmatch_pbullets;
      set_gui_txt();
      return D_REDRAW;
   }
   return ret;
}

int tb_sb(int msg, DIALOG *d, int c)
{
   int ret = d_button_proc(msg, d, c);  // pass to button function   
   if (ret == D_CLOSE)
   {
      suicide_pbullets = !suicide_pbullets;
      set_gui_txt();
      return D_REDRAW;
   }
   return ret;
}

// 8 bit color version
DIALOG netgame_config_8[] =
{
   // (dialog proc)   (x)   (y)   (w)  (h)  (fg) (bg) (key)(flags)  (d1)   (d2)   (dp)           (dp2)      (dp3) 

   // entire frame
   { d_box_proc,      100,  100,  320, 200,   3, 173,  0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // title bar frame
   { d_box_proc,      100,  100,  320,  16,   3, 141,  0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // title 
   { d_ctext_proc,    260,  105,   0,    0,  13, 141,  0,   0,       0,      0,   (char *) "Netgame Configuration" },

   // frame 
   { d_box_proc,      104,  130,  310,  20,  13,   0,  0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // static text
   { d_text_proc,     110,  136,   0,    0,  13,   0,  0,   0,       0,      0,   (char *)"Server IP or hostname:" },
   // editable text
   { d_edit_proc,     288,  136,  124,  10,  15,   0,  0,   0,  sizeof(m_serveraddress)-1, 0, m_serveraddress,   NULL  },

    // toggle buttons
   { tb_dm,           110,  160,  300,  20,  13,   0,  0,   D_EXIT,  0,       0,   dm_txt,      NULL, NULL  },
   { tb_sb,           110,  190,  300,  20,  13,   0,  0,   D_EXIT,  0,       0,   sb_txt,      NULL, NULL  },

   // slider
   { mslid,           110,  220,  300,  20,   0,   0,  0,   D_EXIT,  0,       0,        0,      NULL, NULL  },

   { d_button_proc,   330,  260,  80,   20,   9,   0,  13,  D_EXIT,  0,       0,   (char *)"OK",      NULL, NULL  },
   { d_button_proc,   230,  260,  80,   20,  10,   0,  27,  D_EXIT,  0,       0,   (char *)"Cancel",  NULL, NULL  },
   { NULL,              0,    0,   0,    0,   0,   0,  0,   0,       0,       0,    NULL,       NULL, NULL  },
};

// 16 bit color version
DIALOG netgame_config_16[] =
{
   // (dialog proc)   (x)   (y)   (w)  (h)   (fg)  (bg) (key)(flags)  (d1)   (d2)   (dp)           (dp2)      (dp3) 

   // entire frame
   { d_box_proc,      100,  100,  320, 200, 15359, 650,  0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // title bar frame
   { d_box_proc,      100,  100,  320,  16, 15359, 942,  0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // title 
   { d_ctext_proc,    260,  105,   0,    0,  2047, 942,  0,   0,       0,      0,   (char *) "Netgame Configuration" },

   // frame 
   { d_box_proc,      104,  130,  310,  20,  2047,   0,  0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // static text
   { d_text_proc,     110,  136,   0,    0,  2047,   0,  0,   0,       0,      0,   (char *)"Server IP or hostname:" },
   // editable text
   { d_edit_proc,     288,  136,  124,  10, 65535,   0,  0,   0,       sizeof(m_serveraddress)-1, 0, m_serveraddress,   NULL  },

    // toggle buttons
   { tb_dm,           110,  160,  300,  20,  2047,   0,  0,   D_EXIT,  0,       0,   dm_txt,      NULL, NULL  },
   { tb_sb,           110,  190,  300,  20,  2047,   0,  0,   D_EXIT,  0,       0,   sb_txt,      NULL, NULL  },

   // deathmatch bullet damage slider
   { mslid,           110,  220,  300,  20,     0,   0,  0,   D_EXIT,  0,       0,        0,      NULL, NULL  },

   { d_button_proc,   330,  260,  80,   20,  2031,   0, 13,   D_EXIT,  0,       0,   (char *)"OK",      NULL, NULL  },
   { d_button_proc,   230,  260,  80,   20, 63488,   0, 27,   D_EXIT,  0,       0,   (char *)"Cancel",  NULL, NULL  },
   { NULL,              0,    0,   0,    0,     0,   0,  0,   0,       0,       0,    NULL,       NULL, NULL  },

};

// 32 bit color version
DIALOG netgame_config_32[] =
{
   // (dialog proc)   (x)   (y)   (w)  (h)  (fg)      (bg)   (key)(flags)  (d1)   (d2)   (dp)           (dp2)      (dp3) 

   // entire frame
   { d_box_proc,      100,  100,  320, 200, 3964415,  20817, 0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // title bar frame
   { d_box_proc,      100,  100,  320,  16, 3964415,  30069, 0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // title 
   { d_ctext_proc,    260,  105,   0,    0, 65535,    30069, 0,   0,       0,      0,   (char *) "Netgame Configuration" },



   // frame 
   { d_box_proc,      104,  130,  310,  20, 65535,    0,     0,   0,       0,      0,    NULL,         NULL,      NULL  },
   // static text
   { d_text_proc,     110,  136,   0,    0, 65535,    0,     0,   0,       0,      0,   (char *)"Server IP or hostname:" },
   // editable text
   { d_edit_proc,     288,  136,  124,  10, 16777215, 0,     0,   0,       sizeof(m_serveraddress)-1, 0, m_serveraddress,   NULL  },

    // toggle buttons
   { tb_dm,           110,  160,  300,  20, 65535,    0,     0,   D_EXIT,  0,       0,   dm_txt,      NULL, NULL  },
   { tb_sb,           110,  190,  300,  20, 65535,    0,     0,   D_EXIT,  0,       0,   sb_txt,      NULL, NULL  },

   // deathmatch bullet damage slider
   { mslid,           110,  220,  300,  20,     0,    0,     0,   D_EXIT,  0,       0,        0,      NULL, NULL  },

   { d_button_proc,   330,  260,  80,   20, 65405,    0,    13,   D_EXIT,  0,       0,   (char *)"OK",      NULL, NULL  },
   { d_button_proc,   230,  260,  80,   20, 16711680, 0,    27,   D_EXIT,  0,       0,   (char *)"Cancel",  NULL, NULL  },
   { NULL,              0,    0,   0,    0,     0,    0,     0,   0,       0,       0,    NULL,       NULL, NULL  },

};


void run_dialog_netgame_conf(void)
{
   clear_keybuf();
   set_gui_txt();

   int ret;
   int cd = get_color_depth(); 

   if (cd == 8)  ret = do_dialog(netgame_config_8, -1);
   if (cd == 16) ret = do_dialog(netgame_config_16, -1);
   if (cd == 32) ret = do_dialog(netgame_config_32, -1);

//   printf("ret:%d\n", ret);
   if (ret == 9) // OK button
   {
      //printf("Returned OK\n");
      set_config_int("NETWORK", "deathmatch_pbullets_damage", deathmatch_pbullets_damage);
      set_config_int("NETWORK", "deathmatch_pbullets", deathmatch_pbullets);
      set_config_int("NETWORK", "suicide_pbullets", suicide_pbullets);
      set_config_string("NETWORK", "server_IP", m_serveraddress);
   }         
   if (ret == 10) // cancel button
   {
      //printf("Returned Cancel\n");
   }
   clear_keybuf();
}
     
     
     
     



