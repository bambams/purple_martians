#include <allegro.h>
#include "pm.h"


char help_string[5000][200];


int load_help(void)
{
   char filename[100] = "help/pmhelp.txt";   
   FILE *filepntr;
   char buff[200];
   int line=0;
   int ch=0;

   if ((exists(filename)) == 0)
   {
      textout_ex(screen, font, "can't find pmhelp.txt", 16, 184, palette_color[10], 0);
      tsw();
      return 0;
   }
   else
   {
      filepntr=fopen(filename,"r");
      while(ch != EOF)
      {
         int loop = 0;
         ch = fgetc(filepntr);
         while((ch != '\n') && (ch != EOF))
         {
            if (ch != 13)
            {
               buff[loop] = ch;
               loop++;
            }   
            ch = fgetc(filepntr);
         }
         buff[loop] = 0;
         strcpy (help_string[line], buff);
         line++;
      }
     fclose(filepntr);
   }
   // printf("%d\n",line); 
   return line;
}


void chop_first_x_char(char *str, int n)
{
   char tmp[200];
   for(int x=n; x < (signed int)strlen(str)+1; x++)
      tmp[x-n] = str[x]; // chop first n 
   strcpy(str, tmp);
}     


void help(char *topic)
{
   if (SCREEN_H < 480) return;       // wont work with SCREEN_H < 480
   int xo  = (SCREEN_W - 640) / 2;   // x offset (distance from left screen edge to start of help screen)
   int lpp = (SCREEN_H - 48)  / 8;   // lines per page

   BITMAP *screenbuf = NULL;
   screenbuf = create_bitmap(640, SCREEN_H);
   int num_of_lines = load_help();

   char section_names[60][80];
   int section_first_lines[60];
   int num_sections;

   char buff2[200];
   char msg[200];

   BITMAP * hlift = NULL;
   hlift = load_bitmap("help/lift.bmp", NULL);


   BITMAP * status_window = NULL;
   status_window = load_bitmap("help/status_window.bmp", NULL);
   //if (!status_window) printf("failed to load status_window.bmp\n");
   //else draw_sprite(screen, status_window, 10, 10);

   BITMAP * selection_window = NULL;
   selection_window = load_bitmap("help/selection_window.bmp", NULL);
   //if (!selection_window) printf("failed to load selection_window.bmp\n");
   //else draw_sprite(screen, selection_window, 10, 60);


   int fc =    8;   // frame color
   int ftc =   15;  // frame text color
   int ftdm = -1;   // frame text draw mode

   int sc =   fc;    // section divider color
   int stc =  ftc;   // section divider text color
   int stdm = ftdm;  // section text draw mode



   // fill help_string[5000][200], section_name[60][80], section_first_lines[60] and set last_pos
   num_sections = 0;
   int line = 0;
   int last_pos;
   while (line < num_of_lines)
   {
      if (strncmp(help_string[line], "<section>", 9) != 0)
         line++;
      else
      {
         strcpy(msg, help_string[line]);
         for(int x=9; x < (signed int)strlen(msg)+1; x++)
            buff2[x-9] = msg[x]; // chop first 9
         strcpy(section_names[num_sections], buff2);
         section_first_lines[num_sections] = line;

         if (num_sections < 10)
            sprintf(help_string[line], "<section>0%-1d - %s",  num_sections, section_names[num_sections]);
         else
            sprintf(help_string[line], "<section>%-2d - %s",  num_sections, section_names[num_sections]);

         line++;
         num_sections++;
      }
      last_pos = section_first_lines[num_sections-1];
   }
   line=0;


   // add section headings to help_string
   int sl = 40;                      // line position to insert toc at
   int toc_size = num_sections * 2;  // size of toc to insert

   // slide all down
   for(int x=num_of_lines + toc_size; x > (sl-1+toc_size); x--)
      strcpy(help_string[x], help_string[x-toc_size]);

   for (int c=0; c<num_sections; c++)
   {
      if (c > 1) section_first_lines[c] += toc_size;  // slide section first line numbers
      if (c < 10) sprintf(msg, "<l15>              0%-1d ---- %s", c, section_names[c] );
      else        sprintf(msg, "<l15>              %-2d ---- %s",  c, section_names[c] );
      strcpy(help_string[sl+c*2], msg);
      strcpy(help_string[sl+c*2+1], ""); // blank line in between 
   }

   // increase because of inserted section name list (toc)
   last_pos     += toc_size;
   num_of_lines += toc_size;

   // set section from parameter 'topic'
   if (strlen(topic) > 1)
      for (int c=0; c<num_sections; c++)
         if (strncmp(section_names[c], topic, strlen(topic)) == 0)
            line = section_first_lines[c];


   int got_num =0;
   int quit = 0;
   while (!quit)
   {
      clear(screenbuf);

      for (int x=0;x<16;x++)
      {
         hline(screenbuf, x, SCREEN_H-1-x, 639-x, palette_color[fc+(x*16)] );
         hline(screenbuf, x, x, 639-x, palette_color[fc+(x*16)] );
         vline(screenbuf, x, x, SCREEN_H-1-x, palette_color[fc+(x*16)] ); 
         vline(screenbuf, 639-x, x, SCREEN_H-1-x, palette_color[fc+(x*16)] );
      }
      textout_ex(screenbuf, font, "<UP><DOWN>", 16, 2, palette_color[ftc], ftdm);
      textout_ex(screenbuf, font, "<ESC>-quits", 640-(11*8)-16, 2, palette_color[ftc], ftdm);
      textout_ex(screenbuf, font, "<PAGEUP><PAGEDOWN>", 16, SCREEN_H-9, palette_color[ftc], ftdm);
      textout_ex(screenbuf, font, "<HOME><END>", 640-(11*8)-16, SCREEN_H-9, palette_color[ftc], ftdm);
      textout_centre_ex(screenbuf, font, "Purple Martians Help", 320, 2, palette_color[ftc], ftdm);


      for (int c=0; c<lpp; c++) // cycle lines 
      {
         int xindent = 0;                   // start at xindent = 0
         int just = 0;                      // default just = left
         int color = 15;                    // default regular color unless changed
         sprintf(msg, help_string[line+c]); // put line to process in msg

         int processed_tag_this_time_through;
         int nexttag = 0;
         while (nexttag != -1) 
         {
            processed_tag_this_time_through = 0;

            int sy = 12 + (c*8);    // shape draw y position
            int sx = 20 + xindent;  // shape draw x pos left just
            int sxc = (640/2) - 10; // shape draw x pos centered

            if (strncmp(msg, "<title>", 7) == 0) // show title
            {   
                void draw_title(BITMAP * bmp, int tx, int ty, int color);
                draw_title(screenbuf, sxc-130, sy, 8);
                msg[0]= 0;
            } 
            if (strncmp(msg, "<section>", 9) == 0) // <section> "txt" - make a new section with "txt"
            {
               chop_first_x_char(msg, 9);
               for (int x=0;x<16;x++)
               {
                  hline(screenbuf, 0+x, 28+(c*8)+x, 640-1-x, palette_color[sc+(x*16)] );
                  hline(screenbuf, 0+x, 28+(c*8)-x, 640-1-x, palette_color[sc+(x*16)] );
               }
               textout_centre_ex(screenbuf, font, msg, 640/2, 24+(c*8), palette_color[stc], stdm);
               msg[0]= 0;
            }
            if (strncmp(msg, "<end of file>", 13) == 0)
            {
               for (int x=0;x<16;x++)
               {
                  hline(screenbuf, 0+x, 28+(c*8)+x, 640-1-x, palette_color[sc+(x*16)] );
                  hline(screenbuf, 0+x, 28+(c*8)-x, 640-1-x, palette_color[sc+(x*16)] );
               }
               textout_centre_ex(screenbuf, font, msg, 640/2, 24+(c*8), palette_color[stc], -1);
               c = lpp;   // end the cycle lines loop to prevent drawing unitialized lines
               msg[0]= 0;
            }
            if (strncmp(msg, "<lift>", 6) == 0) // show lift
            {   
                draw_sprite(screenbuf, hlift, sxc-30, sy );   
                msg[0]= 0;
            } 
            if (strncmp(msg, "<sta_w>", 7) == 0) // show selection window
            {   
                draw_sprite(screenbuf, status_window, sxc-160, sy );   
                msg[0]= 0;
            } 
            if (strncmp(msg, "<sel_w>", 7) == 0) // show selection window
            {   
                draw_sprite(screenbuf, selection_window, sxc-161, sy );   
                msg[0]= 0;
            } 

            if (strncmp(msg, "<mdw>", 5) == 0) // show mdw logo
            {   
               float sc = .5;

               int xo = (int)(200 * sc)+16;

               void mdw_an3(BITMAP *b, int x, int y, float sc, int th);
               mdw_an3(screenbuf, 320 + sxc-xo, sy+xo+16, sc, 3);
               mdw_an3(screenbuf, 320 - sxc+xo, sy+xo+16, sc, 3);

               mdw_an3(screenbuf, sxc, sy+50, .1, 1);
               mdw_an3(screenbuf, sxc, sy+200, .2, 1);

               float bs = (float)640 / (float)560;


               mdw_an3(screenbuf, sxc, sy+500, bs, 5);

               msg[0]= 0;
            } 
            if (strncmp(msg, "<mdw1>", 6) == 0) // show mdw logo
            {   
               float sc = .25;

               int xo = (int)(200 * sc)+16;

               void mdw_an3(BITMAP *b, int x, int y, float sc, int th);
               mdw_an3(screenbuf, 320 + sxc-xo, sy+xo+16, sc, 2);
               mdw_an3(screenbuf, 320 - sxc+xo, sy+xo+16, sc, 2);

               msg[0]= 0;
            } 
            if (strncmp(msg, "<ac", 3) == 0) // <acxxx> show animation sequence (centered)
            {
                buff2[0] = msg[3];
                buff2[1] = msg[4];
                buff2[2] = msg[5];
                buff2[3] = 0;
                int ans = zz[0][atoi(buff2)];
                draw_sprite(screenbuf, memory_bitmap[ans], sxc, sy );   
                msg[0]= 0;
            }
            if (strncmp(msg, "<a", 2) == 0) // <axx> show animation sequence (left just)
            {
                processed_tag_this_time_through = 1;
                buff2[0] = msg[2];
                buff2[1] = msg[3];
                buff2[2] = 0;
                int ans = zz[0][atoi(buff2)];
                draw_sprite(screenbuf, memory_bitmap[ans], sx, sy );   
                chop_first_x_char(msg, 5);
                xindent +=24;
            }
            if (strncmp(msg, "<hb", 3) == 0) // <hb> show centered health bar
            {
                buff2[0] = msg[3];
                buff2[1] = msg[4];
                buff2[2] = msg[5];
                buff2[3] = 0;
                int health = atoi(buff2);
                void draw_percent_bar(BITMAP *bmp, int sx, int y, int width, int height, int percent);
                draw_percent_bar(screenbuf, sxc+10, sy, 88, 10, health);
                sprintf(msg,"Health:%-2d", health);
                textout_centre_ex(screenbuf, font, msg, sxc+10, sy+2, palette_color[14], -1);
                msg[0]= 0;
            }
            if (strncmp(msg, "<pc", 3) == 0) // <pcxx> show player and color text (centered)
            {
                buff2[0] = msg[3];
                buff2[1] = msg[4];
                buff2[2] = 0;
                int pco = atoi(buff2);
                int ans = zz[1][9];
                draw_sprite(screenbuf, player_bitmap[pco-1][ans], sxc-40, sy );   
                textout_ex(screenbuf, font, color_name[pco], sxc+24-40, sy+6, palette_color[pco], -1);
                msg[0]= 0;
            }
            if (strncmp(msg, "<p", 2) == 0) // <pxx> show player (left just)
            {
                processed_tag_this_time_through = 1;
                buff2[0] = msg[2];
                buff2[1] = msg[3];
                buff2[2] = 0;
                int pco = atoi(buff2);
                int ans = zz[1][9];
                draw_sprite(screenbuf, player_bitmap[pco-1][ans], sx, sy );   
                chop_first_x_char(msg, 5);
                xindent +=24;
            }
            if (strncmp(msg, "<s", 2) == 0) // <sxxx> show shape left just)
            {
               processed_tag_this_time_through = 1;
               buff2[0] = msg[2];
               buff2[1] = msg[3];
               buff2[2] = msg[4];
               buff2[3] = 0;
               int ans = atoi(buff2);
               draw_sprite(screenbuf, memory_bitmap[ans], sx, sy );   
               chop_first_x_char(msg, 6);
               xindent +=24;
            }
            if (strncmp(msg, "<ms", 2) == 0) // <msxxxxxxx....> show 20 shapes (left just)
            {
               int z;
               for(z=0; z < 20; z++)
               {
                  buff2[0] = msg[3+z*3];
                  buff2[1] = msg[4+z*3];
                  buff2[2] = msg[5+z*3];
                  buff2[3] = 0;
                  int ans = atoi(buff2);
                  draw_sprite(screenbuf, memory_bitmap[ans], sx+(z*20), sy );   
               }
               msg[0]= 0; 
            }
            if (strncmp(msg, "<l", 2) == 0) // <lxx> line color xx (left just)
            {
               processed_tag_this_time_through = 1;
               buff2[0] = msg[2];
               buff2[1] = msg[3];
               buff2[2] = 0;
               color = atoi(buff2);
               chop_first_x_char(msg, 5);
            }
            if (strncmp(msg, "<c", 2) == 0) // <cxx> line color xx (centered)
            {
               processed_tag_this_time_through = 1;
               buff2[0] = msg[2];
               buff2[1] = msg[3];
               buff2[2] = 0;
               color = atoi(buff2);
               chop_first_x_char(msg, 5);
               just = 1;
            }

            if (strncmp(msg, "<b", 2) == 0) // <bxx> draw a line in color xx 
            {
               buff2[0] = msg[2];
               buff2[1] = msg[3];
               buff2[2] = 0;
               color = atoi(buff2);
               chop_first_x_char(msg, 5);
               hline(screenbuf, 20, sy+16, 620, palette_color[color]);  
               msg[0]= 0;
            }

            // by this point we should have processed and stripped any tag from the beginning of the line 
            // if there was a tag we didn't process it will be printed as text
            // now we search for the beginning of another tag "<"
            // if we find one, we chop out the text up to point and print it
            // then we will run this loop again to process the next tag
            // if we don't find another, we will print the whole line


            char txt[200];                        // line to print
            strcpy(txt, msg);                     // by default txt will have all of msg
            nexttag = -1;                         // default if no next tag found


             if ((!processed_tag_this_time_through) && (msg[0] == '<')) // bad tag
                msg[0] = '*';

            int len = strlen(msg);
            if (len>1)
               for (int x=0; x<len; x++)
                  if (msg[x] == '<')
                  {
                     nexttag = x;
                     break;
                  }   
            if (nexttag != -1)                    // another '<' was found
            {
               txt[nexttag] = 0;                  // terminate 'txt' with NULL to shorten string
               chop_first_x_char(msg, nexttag);   // remove this from the beginning of 'msg'
            }               
            if (just) textout_centre_ex(screenbuf, font, txt, 640/2,        24+(c*8), palette_color[color], 0);
            else             textout_ex(screenbuf, font, txt, 20 + xindent, 24+(c*8), palette_color[color], 0);
            xindent += strlen(txt) * 8;
         } // end of while nexttag != -1
      } // end of cycle lines

      if (key[KEY_UP])   line --;
      if (key[KEY_DOWN]) line ++;
      if (key[KEY_HOME]) line = 0;
      if (key[KEY_END])  line = last_pos;
      if (key[KEY_PGUP])
      {
         while (key[KEY_PGUP]);
         while ((strncmp(help_string[--line], "<section>", 9) != 0) && (line > 0));
      }
      if (key[KEY_PGDN])
      {
         while (key[KEY_PGDN]);
         while ((strncmp(help_string[++line], "<section>", 9) != 0) && (line < num_of_lines - lpp));
      }

      // limits 
      if (line < 0)  line = 0;
      if (line > last_pos)  line = last_pos;

      if (got_num)
      {
         sprintf(msg, "jump to section %c_", got_num);
         textout_centre_ex(screenbuf, font, msg, 320, SCREEN_H-9, palette_color[ftc], ftdm);
      }
      if (keypressed()) // don't wait for keypress 
      {
         int k = readkey();
         k = (k & 0xFF);  // strip upper bits 
         if ((k>47) && (k<58))   // if alphanumeric and return 
         {
            clear_keybuf();
            if (got_num) // last keypress was num 
            {
               int sn = (got_num-48)*10 + (k-48);
               if (sn < num_sections)
                  line = section_first_lines[sn];
               got_num = 0;
            }
            else got_num = k;
         }
         else got_num = 0; // keypressed but not num 
      }
      blit(screenbuf, screen, 0, 0, xo, 0, 640, SCREEN_H);
      update_animation();
      rest(20);
      while ((key[KEY_ESC]) || (mouse_b & 2)) quit = 1;
   }  // end of while not quit
   destroy_bitmap(screenbuf);
   destroy_bitmap(status_window);
   destroy_bitmap(selection_window);
   destroy_bitmap(hlift);
   clear(screen);
}




int zmenu(int menu_num, int menu_pos, int y)  // this menu function does not pass through, it waits for a selection and then exits
{
   y-=4;

   demo_mode_countdown = 400; 

   int highlight = menu_pos;
   int selection = 999;
   int last_list_item;
   int c;
   int old_my, new_my;
   int mx = SCREEN_W/2;


   int up_held = 0;
   int down_held = 0;
   int left_held = 0;
   int right_held = 0;


   show_mouse(NULL);


   while (key[KEY_UP]);
   while (key[KEY_DOWN]);
   while (key[KEY_ENTER]);
   while (key[KEY_ESC]);

   if ((key[KEY_LEFT]) || (players[0].left)) left_held = 1;
   if ((key[KEY_RIGHT]) || (players[0].right)) right_held = 1;


   proc_controllers();
   while (players[0].fire) proc_controllers();
   while (players[0].jump) proc_controllers();

   clear_keybuf();
   do
   {
      
      if (menu_num == 7)
      {
         draw_level(scrn_buffer); // only draw map on main menu
         if (--demo_mode_countdown < 0)
         {
            demo_mode();
            demo_mode_countdown = 400; 
         } 
         sprintf(global_string[7][9], "Demo Mode (%d)", demo_mode_countdown/40);
      }  


      c = 0;
      while (strcmp(global_string[menu_num][c],"end") != 0)
      {
         int b = players[active_local_player].color; 
//         int b = 15; 
         if ((!resume_allowed) && (menu_num == 7) && (c==4)) b+=80; // dimmer if can't resume
         textout_centre_ex(scrn_buffer, font, global_string[menu_num][c], mx, y+(c*10)+1, palette_color[b+48], 0);

         if (c == highlight)
            textout_centre_ex(scrn_buffer, font, global_string[menu_num][c], mx, y+(c*10)+1, palette_color[b], 0);

         if (c == highlight)
         {
            int sl = strlen(global_string[menu_num][c]) * 4;
            rect(scrn_buffer, mx-sl-2, y+(c*10)-1, mx+sl, y+(c*10)+9, palette_color[b+80]); 
//            textout_centre_ex(scrn_buffer, font, global_string[menu_num][c], mx, y+(c*10)+1, palette_color[b], 0);
         }


         c++;
      }
      last_list_item = c-1;

      frame_and_title(scrn_buffer);
      mdw_an();
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      clear(scrn_buffer);

      proc_controllers();
      position_mouse(SCREEN_W/2, SCREEN_H/2);
      old_my=mouse_y;
      rest(20);
      new_my=mouse_y;

      // shortcut key for level editor  
      if (menu_num == 7) if (key[KEY_L]) return 9;

      if (((key[KEY_RIGHT]) || (players[0].right)) && (right_held == 0))
      {
         right_held = 1; 
         selection = highlight + 100;
      }
      if ( (!(key[KEY_RIGHT])) &&  (!(players[0].right)) )  right_held = 0;

      if (((key[KEY_LEFT]) || (players[0].left)) && (left_held == 0))
      {
         left_held = 1; 
         selection = highlight + 200;
      }
      if ( (!(key[KEY_LEFT])) &&  (!(players[0].left)) )  left_held = 0;


      if (((key[KEY_DOWN]) || (players[0].down) || (new_my > old_my+1)) && (down_held == 0))
      {
         if (++highlight > last_list_item) highlight = last_list_item;
         if ((!resume_allowed) && (menu_num == 7)) if (highlight==4) highlight++; // skip resume if disabled
         down_held = 1;
         demo_mode_countdown = 400; 
      }
      if (  (!(key[KEY_DOWN])) && (!(players[0].down)) && (!(new_my > old_my+1)) ) down_held = 0;


      if (((key[KEY_UP]) || (players[0].up) || (new_my < old_my-1)) && (up_held == 0))
      {
         if (--highlight < 2) highlight = 2;
         if ((!resume_allowed) && (menu_num == 7)) if (highlight==4) highlight--; // skip resume if disabled
         up_held = 1;
         demo_mode_countdown = 400; 
      }
      if (  (!(key[KEY_UP])) && (!(players[0].up)) && (!(new_my < old_my-1)) ) up_held = 0;


      if ( (key[KEY_ENTER]) || (players[0].fire) || (players[0].jump) || (mouse_b & 1) )
      {
         while ((key[KEY_ENTER]) || (mouse_b & 1));
         while ((players[0].jump) || (players[0].fire)) proc_controllers();
         selection = highlight;
      }
      if ((key[KEY_ESC]) || (mouse_b & 2))
      {
         while ((key[KEY_ESC]) || (mouse_b & 2)); // wait for release
         selection = last_list_item;
         if (menu_num == 9)  selection = 2; // back is at top of controller menu
         if (menu_num == 8)  selection = 2; // back is at top of options menu
         if (menu_num == 7)  selection = 1; // for top menu only
      }
   } while (selection == 999);
   return selection;
}

void menu_setup(void)
{
   strcpy (lift_step_type_name[0], "illegal!");
   strcpy (lift_step_type_name[1], "Move");
   strcpy (lift_step_type_name[2], "Wait");
   strcpy (lift_step_type_name[3], "Prox");
   strcpy (lift_step_type_name[4], "Loop");

   strcpy (enemy_name[3], "ArchWagon");
   strcpy (enemy_name[4], "Bouncer");
   strcpy (enemy_name[6], "Cannon");
   strcpy (enemy_name[7], "PodZilla ");
   strcpy (enemy_name[8], "TrakBot");
   strcpy (enemy_name[9], "Cloner");
   strcpy (enemy_name[11], "Block Walker");
   strcpy (enemy_name[12], "Flapper");

   strcpy (color_name[0], "Zombie");
   strcpy (color_name[1], "Violet");
   strcpy (color_name[2], "Mauve");
   strcpy (color_name[3], "Bluey");
   strcpy (color_name[4], "Reddy");
   strcpy (color_name[5], "Pink");
   strcpy (color_name[6], "Taan");
   strcpy (color_name[7], "Orange");
   strcpy (color_name[8], "Purple");
   strcpy (color_name[9], "Forest");
   strcpy (color_name[10], "Red");
   strcpy (color_name[11], "Green");
   strcpy (color_name[12], "Blue");
   strcpy (color_name[13], "Aqua");
   strcpy (color_name[14], "Yellow");
   strcpy (color_name[15], "White");

   strcpy (global_string[7][0], ""); // main menu
   strcpy (global_string[7][1], "");
   strcpy (global_string[7][2], "Start Level (1)");        
   strcpy (global_string[7][3], "Start New Game");           
   strcpy (global_string[7][4], "Resume Current Game");        
   strcpy (global_string[7][5], "   ---   ");
   strcpy (global_string[7][6], "   ---   ");

#ifdef NETPLAY
   strcpy (global_string[7][5], "Host Network Game");
   strcpy (global_string[7][6], "Join Network Game");
#endif

   strcpy (global_string[7][7], "Options Menu");
   strcpy (global_string[7][8], "Level Editor");
   strcpy (global_string[7][9], "Demo Mode");
   strcpy (global_string[7][10], "Help Screens");
   strcpy (global_string[7][11], "end");



   strcpy (global_string[8][0], "Options Menu");
   strcpy (global_string[8][1], "----------");
   strcpy (global_string[8][2], "Back to Game Menu");
   strcpy (global_string[8][3], "Screen Mode: 640 x 480");
   strcpy (global_string[8][4], "<-Change Color->");
   strcpy (global_string[8][5], "Controller Setup");
   strcpy (global_string[8][6], "Speed:Fast");
   strcpy (global_string[8][7], "Sound:Off");
   strcpy (global_string[8][8], "Sound Effects Volume:9");
   strcpy (global_string[8][9], "Sound Track Volume:9");
   strcpy (global_string[8][10], "Netgame Configuration");
   strcpy (global_string[8][11], "Splash Screen:ON");
   strcpy (global_string[8][12], "Save Game");
   strcpy (global_string[8][13], "Run Game");
   strcpy (global_string[8][14], "end");


   strcpy (global_string[9][0],  "Controller Setup Menu");
   strcpy (global_string[9][1],  "---------------------");
   strcpy (global_string[9][2],  "Back to Options Menu");
   strcpy (global_string[9][3],  "Test Controls" );
   strcpy (global_string[9][4],  "Set all controls" );
   strcpy (global_string[9][5],  "Set all to joy1" );
   strcpy (global_string[9][6],  "Set all to joy2" );
   strcpy (global_string[9][7],  "Set all to arrows" );
   strcpy (global_string[9][8],  "Set all to IJKL SPACE C" );
   strcpy (global_string[9][9],  " ----------------------" );
   strcpy (global_string[9][23], "end");
}



































