// e_pde.cpp (20100220 cleanup)
#include <allegro.h>
#include "pm.h"

int load_PDE()
{
   FILE *filepntr;
   extern int PDEi[100][32];
   extern fixed PDEfx[100][16];
   extern char PDEt[100][20][40];
   int PDE_load_error;
   int loop, ch, c, x;
   char buff[80];
   textout_centre_ex(screen, font, "loading PDE...", SCREEN_W/2, 176, palette_color[10], 0);
   PDE_load_error = 0;
   if (!exists("bitmaps/pde.pm"))
   {
      textout_ex(screen, font, "Can't find pde.pm", 0, 160, palette_color[10], 0);
      PDE_load_error = 2;
   }
   if (!PDE_load_error) // file exists 
      if ((filepntr=fopen("bitmaps/pde.pm","r")) == NULL)
      {
         textout_ex(screen, font, "Error opening pde.pm", 0, 160, palette_color[10], 0);
         PDE_load_error = 3;
      }
   if (!PDE_load_error) // file exists and is open! 
   {
      for (c=0; c<100; c++) // read PDE enemy fixed 
         for (x=0; x<16; x++)
         {
            loop = 0;
            ch = fgetc(filepntr);
            while((ch != '\n') && (ch != EOF))
            {
               buff[loop] = ch;
               loop++;
               ch = fgetc(filepntr);
            }
            buff[loop] = (char)NULL;
            PDEfx[c][x] = atoi(buff);  // fixed

            if (ch == EOF)
            {
               textout_ex(screen, font, "Error reading fixed in PDE", 0, 176, palette_color[10], 0);
               rest(3000);
               PDE_load_error = 4;
            }
         }
         for (c=0; c < 100; c++)  // enemy ints 
            for (x=0; x<32; x++)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
               {
                  buff[loop] = ch;
                  loop++;
                  ch = fgetc(filepntr);
               }
               buff[loop] = (char)NULL;
               PDEi[c][x] = atoi(buff);
               if (ch == EOF)
               {
                  textout_ex(screen, font, "Error reading ints in PDE", 0, 176, palette_color[10], 0);
                  rest(3000);
                  PDE_load_error = 5;
               }
            }
         for (c=0; c < 100; c++)  // enemy text 
            for (x=0; x<20; x++)
            {
               loop = 0;
               ch = fgetc(filepntr);
               while((ch != '\n') && (ch != EOF))
               {
                  PDEt[c][x][loop] = ch;
                  loop++;
                  ch = fgetc(filepntr);
               }
               PDEt[c][x][loop] = (char)NULL;
               if (ch == EOF)
               {
                  sprintf(msg,"Error reading text at %d %d %d in PDE", loop, c, x);
                  textout_ex(screen, font, msg, 0, 176, palette_color[10], 0);
                  rest(3000);
                  PDE_load_error = 6;
               }
            }
         fclose(filepntr);
      }
   if  (PDE_load_error)
   {
      sprintf(msg,"PDI load error %d", PDE_load_error);
      textout_ex(screen, font, msg, 0, 200, palette_color[10], 0);
      rest(2000);
      return 0;
   }
   return 1;
}

void save_PDE()
{
   FILE *filepntr;
   extern char PDEt[100][20][40];
   extern int PDEi[100][32];
   extern fixed PDEfx[100][16];
   int c, x;
   filepntr = fopen("bitmaps/pde.pm","w");
   for (c=0; c < 100; c++)  // enemy fixed 
      for (x=0; x<16; x++)
         fprintf(filepntr,"%d\n",PDEfx[c][x]);

   for (c=0; c < 100; c++) // enemy int 
      for (x=0; x<32; x++)
         fprintf(filepntr,"%d\n",PDEi[c][x]);

   for (c=0; c < 100; c++) // enemy text 
      for (x=0; x<20; x++)
         fprintf(filepntr,"%s\n",PDEt[c][x]);
   fclose(filepntr);
}


// this is a non blocking, pass through funtion and should be called in a loop 
int bottom_menu(int menu_num)
{
   int selection, c, d;
   show_mouse(screen);
   rest(5);
   show_mouse(NULL);
   if (mouse_y > 186) selection = (mouse_x / 40);   // highlight only 
   for (c=0; c <= 7; c++)
   {
      if (c == selection) d = 9; else d = 9+64;
      sprintf(msg," F%-1d  ",c+1);
      textout_ex(screen, font, msg,                        c*40, 184, palette_color[d], 0);
      textout_ex(screen, font, global_string[menu_num][c], c*40, 192, palette_color[d], 0);
   }
   selection = 999; // normal return --  nothing happened 
   if ((mouse_b & 1) && (mouse_y > 186))
   {
      selection = (mouse_x / 40);
      while (mouse_b & 1);   // wait for release 
   }
   if ((mouse_b & 2) && (mouse_y > 160))
   {
      selection = -1;
      while (mouse_b & 2); // wait for release 
   }
   if (selection == 7) selection = -1;
   while (key[KEY_F1]) selection = 0;
   while (key[KEY_F2]) selection = 1;
   while (key[KEY_F3]) selection = 2;
   while (key[KEY_F4]) selection = 3;
   while (key[KEY_F5]) selection = 4;
   while (key[KEY_F6]) selection = 5;
   while (key[KEY_F7]) selection = 6;
   while (key[KEY_F8]) selection = -1;
   while (key[KEY_ESC])selection = -1;
   return selection;
}

// global variables only for edit_float
// only used in PDE
float edit_float_retval;
float finitial, fxinc, fyinc, flv, fuv;

int edit_float(int x, int y)
{
   int imx = mouse_x; // initial mouse position 
   int imy = mouse_y;
   int quit_mode=0, retval, quit=0;
   int old_mouse_x, old_mouse_y;
   show_mouse(NULL);
   if (mouse_b & 1) quit_mode = 1;   // set mouse exit mode if b1 pressed on enter 
   while (!quit)
   {
      sprintf(msg,"%-4.3f",finitial);
      textout_ex(screen, font, msg, x, y, palette_color[10], 0);

      if ((quit_mode == 1) && (!(mouse_b & 1)) )     // wait for b1 release 
      {
         clear_keybuf();
         sprintf(msg,"%-4.3f",finitial);
         textout_ex(screen, font, msg, x, y, palette_color[11], 0);
         edit_float_retval = finitial;
         retval = 1;
         quit = 1;
      }
      if ((quit_mode == 0) && (key[KEY_ENTER]))
         {
         clear_keybuf();
         sprintf(msg,"%f  ",finitial);
         textout_ex(screen, font, msg, x, y, palette_color[10], 0);
         edit_float_retval = finitial;
         retval = 1;
         quit = 1;
      }
      if (key[KEY_0]) finitial = 0;
      if (key[KEY_1]) finitial = 1;
      if (key[KEY_2]) finitial = 2;
      if (key[KEY_3]) finitial = 3;
      if (key[KEY_4]) finitial = 4;
      if (key[KEY_5]) finitial = 5;
      if (key[KEY_6]) finitial = 6;
      if (key[KEY_7]) finitial = 7;
      if (key[KEY_8]) finitial = 8;
      if (key[KEY_9]) finitial = 9;

      if ((key[KEY_ESC]) || (mouse_b & 2))
      {
         retval = 0;
         quit = 1;
      }

      position_mouse(160,100);
      old_mouse_x = mouse_x;
      old_mouse_y = mouse_y;
      rest(20); // this wait is crucial to get mouse movement 
  
      finitial += (mouse_x - old_mouse_x) * fxinc;
      finitial += (mouse_y - old_mouse_y) * fyinc;

      // check and enforce limits 
      if (finitial > fuv) finitial = fuv;
      if (finitial < flv) finitial = flv;
   }
   position_mouse(imx, imy); // set original mouse position 
   show_mouse(screen);

   return retval;
}





extern int PDEi[100][32];
extern fixed PDEfx[100][16];
extern char PDEt[100][20][40];



void PDE_swap(int s1, int s2)
{
   for (int y=0; y<32; y++)
   {
      int temp    = PDEi[s1][y];
      PDEi[s1][y] = PDEi[s2][y];
      PDEi[s2][y] = temp;
   }
   for (int y=0; y<16; y++)
   {
      fixed temp   = PDEfx[s1][y];
      PDEfx[s1][y] = PDEfx[s2][y];
      PDEfx[s2][y] = temp;
   }
   for (int y=0; y<20; y++)
   {
      char stemp[80];
      strcpy(stemp,       PDEt[s1][y] );
      strcpy(PDEt[s1][y], PDEt[s2][y] );
      strcpy(PDEt[s2][y], stemp);
   }
}


void PDE_sort(void)
{
   // first just sort by type
   int swap_flag = 1;
   while (swap_flag)
   {
      swap_flag = 0;
      for (int x=0; x<99; x++)
      {
         if ( PDEi[x][0] > PDEi[x+1][0]) // sort by type 
         {
            PDE_swap(x, x + 1);
            swap_flag++; // if any swaps 
         } 
      } 
   } 

   // then sort by text line
   swap_flag = 1;
   int do_swap = 0;
   while (swap_flag)
   {
      do_swap = 0;
      swap_flag = 0;
      for (int x=0; x<99; x++)
      {
         if ((PDEi[x][0] > 199) && ( PDEi[x][0] < 300))  // if both creators 
            if ((PDEi[x+1][0] > 199) && ( PDEi[x+1][0] < 300)) 
               if (strncmp(PDEt[x][1], PDEt[x+1][1], strlen(PDEt[x][1])) > 0)
                  do_swap = 1;
 
         if ((PDEi[x][0] > 99) && ( PDEi[x][0] < 200))  // if both items
            if ((PDEi[x+1][0] > 99) && ( PDEi[x+1][0] < 200)) 
               if ( PDEi[x][0] == PDEi[x+1][0] ) // if same type
                  if (strncmp(PDEt[x][1], PDEt[x+1][1], strlen(PDEt[x][1]) ) > 0)  // secondary sort by text line 1 
                     do_swap = 1;

         if ((PDEi[x][0] > 0) && ( PDEi[x][0] < 100))  // if both enemies
            if ((PDEi[x+1][0] > 0) && ( PDEi[x+1][0] < 100)) 
               if ( PDEi[x][0] == PDEi[x+1][0] ) // if same type
                  if (strncmp(PDEt[x][1], PDEt[x+1][1], strlen(PDEt[x][1]) ) > 0)  // secondary sort by text line 1 
                     do_swap = 1;

         if (do_swap) // do the swap 
         {
            do_swap = 0;
            swap_flag++; // if any swaps 
            PDE_swap(x, x + 1);
         } // end of swap 
      } // end of for x 
   } // end of while swap flag 

   draw_select_window();
}



void predefined_enemies(void)
{
   if (load_PDE())
   {
      int x,y, EN = 0, redraw = 1, menu_sel;
      clear_keybuf();
      do
      {
         show_mouse(screen);
         rest(10);
         show_mouse(NULL);
         menu_sel = (bottom_menu(5));   // call the menu handler 

         if (redraw)
         {
            int a,b=0;
            int rt = PDEi[EN][0];
            redraw = 0;
            clear(screen);

            a = PDEi[EN][1]; // bmp or ans 
            if (a < NUM_SPRITES) b = a; // bmp 
            if (a > 999) b = zz[5][a-1000]; // ans 

            blit(memory_bitmap[b], screen, 0,0,0,0,20,20);

            if (rt < 99)
            {
               sprintf(msg, "Predefined Enemy %d", EN);
               textout_ex(screen, font, msg, 40, 0, palette_color[240], 0);
               for (x=0; x<16; x++) // three columns 
               {
                  sprintf(msg, "Ef%-1d %f", x, fixtof(PDEfx[EN][x]));
                  textout_ex(screen, font, msg, 256, 20+(x*8), palette_color[240], 0);
                  sprintf(msg, "Ei%-1d %d", x, PDEi[EN][x]);
                  textout_ex(screen, font, msg, 400, 20+(x*8), palette_color[240], 0);
                  sprintf(msg, "Ei%-1d %d", x+16, PDEi[EN][x+16]);
                  textout_ex(screen, font, msg, 500, 20+(x*8), palette_color[240], 0);
               }
                  for (x=0; x<20; x++)
                     textout_ex(screen, font, PDEt[EN][x], 0, 20+(x*8), palette_color[240], 0);
            }

            if ((rt > 99) && (rt < 200))
            {
               sprintf(msg, "Predefined Item %d", EN);
               textout_ex(screen, font, msg, 40, 0, 240, 0);
               for (x=0; x<10; x++)
               {
                  textout_ex(screen, font, PDEt[EN][x], 0, 20+(x*8), palette_color[240], 0);
                  textout_ex(screen, font, PDEt[EN][x+10], 0, 100+(x*8), palette_color[240], 0);
               }
               for (x=0; x<16; x++)
               {
                  sprintf(msg, "I%-2d %d", x, PDEi[EN][x]);
                  textout_ex(screen, font, msg, 400, 20+(x*8), palette_color[240], 0);
               }
            }
            if (rt > 199)
            {
               sprintf(msg, "Special Creator %d", EN);
               textout_ex(screen, font, msg, 40, 0, 240, 0);
               for (x=0; x<16; x++) // three columns 
               {
                  sprintf(msg, "Ef%-1d %f", x, fixtof(PDEfx[EN][x]));
                  textout_ex(screen, font, msg, 256, 20+(x*8), palette_color[240], 0);
                  sprintf(msg, "Ei%-1d %d", x, PDEi[EN][x]);
                  textout_ex(screen, font, msg, 400, 20+(x*8), palette_color[240], 0);
                  sprintf(msg, "Ei%-1d %d", x+16, PDEi[EN][x+16]);
                  textout_ex(screen, font, msg, 500, 20+(x*8), palette_color[240], 0);
               }
               for (x=0; x<10; x++)
               {
                  textout_ex(screen, font, PDEt[EN][x], 0, 20+(x*8), palette_color[240], 0);
                  textout_ex(screen, font, PDEt[EN][x+10], 0, 100+(x*8), palette_color[240], 0);
               }
            }
         }

         if ((key[KEY_RCONTROL]) && (key[KEY_S])) // sort 
         { 
            while (key[KEY_S]);
            PDE_sort();
           
            for (int x=0; x<50; x++) PDE_swap(x, x + 50); // move all to + 50

            int insert_pos = 0; // creators to 0 
            for (int x=50; x<100; x++)
            {
               int rt = PDEi[x][0];
               if (rt > 199) PDE_swap(x, insert_pos++);   
            }

            insert_pos = 16; // items to 16 
            for (int x=50; x<100; x++)
            {
               int rt = PDEi[x][0];
               if ((rt > 99) && (rt < 200)) PDE_swap(x, insert_pos++);
            }

            insert_pos = 32; // enemies to 32 
            for (int x=50; x<100; x++)
            {
               int rt = PDEi[x][0];
               if ((rt) && (rt < 99)) PDE_swap(x, insert_pos++);
            }
            draw_select_window();
            redraw = 1;
         }







         // --------------  edit text
         if ((mouse_b & 1) && (mouse_x < 240) && (mouse_y > 20) && (mouse_y < 180))
         {     
            int k, tx = 0, ty = 0;
            int line_length = 30;
            ty = (mouse_y-20)/8;
            tx = mouse_x/8;
            redraw = 1;
            do
            {
               show_mouse(screen);
               rest(20);
               show_mouse(NULL);

               if (redraw)
                  for (x=0; x<20; x++)
                  {
                     redraw = 0;
                     textout_ex(screen, font, "                               ", 0, 20+(x*8), palette_color[240], 0); // 31 spaces 
                     textout_ex(screen, font, PDEt[EN][x], 0, 20+(x*8), palette_color[240], 0);
                  }

               // mark the text entry position
               msg[0] = PDEt[EN][ty][tx];
               if (msg[0] == (char)NULL) msg[0] = 32;
               msg[1] = (char)NULL;
               textout_ex(screen, font, msg, (tx*8), 20+(ty*8), palette_color[240], 10);
               
               if (keypressed()) // don't wait for keypress 
               {
                  k = readkey();
                  redraw = 1;
               }
               else k = 0;
                 
               k = (k & 0xFF);  // strip upper bits 
               if ((k>31) && (k<128))   // if alphanumeric 
               {
                  int z = strlen(PDEt[EN][ty]);
                  if (z > line_length) z = line_length;
                  for (x=z; x>tx; x--)
                     PDEt[EN][ty][x] = PDEt[EN][ty][x-1];
                  PDEt[EN][ty][tx] = k;
                  if (++tx > line_length) // end of line? 
                  {
                     PDEt[EN][ty][tx] = (char)NULL; // terminate the line 
                     ty++;  // LF 
                     tx = 0; // CR 
                  }
               }
               if (key[KEY_BACKSPACE])
               {
                  while (key[KEY_BACKSPACE]);
                  if (--tx<0) tx = 0;
                  int z = strlen(PDEt[EN][ty]);
                  for (x=tx; x<z; x++)
                     PDEt[EN][ty][x] = PDEt[EN][ty][x+1];
               }
               if (key[KEY_ENTER])
               {
                  while (key[KEY_ENTER]);
                  for (y=19; y>ty; y--)  // slide all down 
                  {
                     strcpy(PDEt[EN][y],PDEt[EN][y-1]);
                  }
                  if (strlen(PDEt[EN][ty]) == 999) // cursor past end of line 
                  {
                     PDEt[EN][ty+1][0] = (char)NULL; // next line empty 
                  }
                  if ((signed int)strlen(PDEt[EN][ty]) >= tx) // cursor not past end of line 
                  {
                     for (x=0; x <= 30-tx; x++)         // split line at tx 
                         PDEt[EN][ty+1][x] = PDEt[EN][ty+1][tx+x];

                     PDEt[EN][ty][tx] = (char)NULL;  // terminate top line 
                     tx = 0;
                     ty++;
                  }
               }
               if (key[KEY_DEL])
               {
                  while (key[KEY_DEL]);
                  if (PDEt[EN][ty][tx] == (char)NULL)
                  {
                     for (x=0; x<=30-tx; x++) // get portion from line below 
                         PDEt[EN][ty][tx+x] = PDEt[EN][ty+1][x];

                     for (y=ty+1; y<19; y++)  // slide all up 
                        strcpy(PDEt[EN][y],PDEt[EN][y+1]);
                     PDEt[EN][19][0] = (char)NULL; // last line empty 
                  }
                  else
                  {
                     for (x = tx; x < (int)strlen(PDEt[EN][ty]); x++)
                        PDEt[EN][ty][x] = PDEt[EN][ty][x+1];
                  }
               }

               if (key[KEY_RIGHT])
               {
                  while (key[KEY_RIGHT]);
                  if (++tx > line_length-1) tx = line_length-1;
               }  
               if (key[KEY_LEFT])
               {
                  while (key[KEY_LEFT]);
                  if (--tx < 0) tx = 0;
               }   
               if (key[KEY_UP])
               {
                  while (key[KEY_UP]);
                  if (--ty < 0) ty = 0;
               }
               if (key[KEY_DOWN]) 
               {
                  while (key[KEY_DOWN]);
                  if (++ty > 19) ty = 19;
               }   
               if ((mouse_b & 1) && (mouse_x < 250) && (mouse_y > 20) && (mouse_y < 180))
               {
                  redraw = 1;
                  ty = (mouse_y-20)/8;
                  tx = mouse_x/8;
               }
               if (tx > (signed int)strlen(PDEt[EN][ty])) tx = strlen(PDEt[EN][ty]);
               clear_keybuf();
            } while ((k != 27) && (!(mouse_b & 2)) );
            while (key[KEY_ESC]);
            clear_keybuf();
            redraw = 1;
         }

         if (key[KEY_PGUP])
         {
            while (key[KEY_PGUP]);
            EN +=10;
            if (EN > 99) EN = 99;
            clear_keybuf();
            redraw =1;
         }
         if (key[KEY_PGDN])
         {
            while (key[KEY_PGDN]);
            EN -=10;
            if (EN < 0) EN = 0;
            clear_keybuf();
            redraw =1;
         }
         if ((key[KEY_RCONTROL]) && (key[KEY_DEL])) // DELETE PD 
         { 
            while ((key[KEY_RCONTROL]) && (key[KEY_DEL]));
            for (int y=0; y<32; y++) PDEi[EN][y] = 0;
            for (int y=0; y<16; y++) PDEfx[EN][y] = itofix(0);
            for (int y=0; y<20; y++) strcpy(PDEt[EN][y],"");
            PDEi[EN][0] = 9999; // mark as empty
            redraw =1;
            //PDE_sort();
            draw_select_window();
         }
         if (menu_sel == 1) // prev PDE 
         {
            if (--EN < 0) EN = 0;
            redraw =1;
         }
         if (menu_sel == 2) // next PDE 
         {
            if (++EN > 99) EN = 99;
            redraw =1;
         }
         if (menu_sel == 5) // save PDE 
         {
            save_PDE();
            redraw =1;
         }
         if (menu_sel == 6) // load PDE 
         {
            load_PDE();
            redraw =1;
         }
         if ((mouse_y > 20) && (mouse_y < 340) && (mouse_b & 1))  // edit variables 
         {
            int tab = 0;
            y = (mouse_y-20)/8;
            if (y>9) tab = 8;
            redraw=1;
            if ((mouse_x > 400) && (mouse_x < 500))
               if (edit_int(432 + tab, 20+(y*8), PDEi[EN][y], 1, -1, 20000)) PDEi[EN][y] = edit_int_retval;
            if ((mouse_x > 500) && (mouse_x < 600))
               if (edit_int(540, 20+(y*8), PDEi[EN][y+16], 1, -1, 20000)) PDEi[EN][y+16] = edit_int_retval;
            if ((mouse_x > 256) && (mouse_x < 400))
            {  // edit float 
               fxinc=.01;  // y inc 
               fyinc=.1;   // x inc 
               flv=-2000;  // lv    
               fuv=2000;   // uv    
               finitial = fixtof(PDEfx[EN][y]);
               if (edit_float(288+tab, 20+(y*8))) PDEfx[EN][y] = ftofix(edit_float_retval);
            }
        }
      } while (!(key[KEY_ESC]) && (menu_sel != -1));
   } // end of if load succesfull 
   while (key[KEY_ESC]);
   draw_select_window();
}
























