#include <allegro.h>
#include <math.h>
#include "pm.h"



void client_local_control(int);
void server_local_control(int);
void proc_game_loop(void);
void player_key_check(int);
void clear_keys(int);
void set_passcount_timer_fps(int x);

char tmp_string[1000];

/* from alleg src keyboard.c
AL_CONST char *_keyboard_common_names[KEY_MAX] =
{
   "(none)",     "A",          "B",          "C",
   "D",          "E",          "F",          "G",
   "H",          "I",          "J",          "K",
   "L",          "M",          "N",          "O",
   "P",          "Q",          "R",          "S",
   "T",          "U",          "V",          "W",
   "X",          "Y",          "Z",          "0",
   "1",          "2",          "3",          "4",
   "5",          "6",          "7",          "8",
   "9",          "0 PAD",      "1 PAD",      "2 PAD",
   "3 PAD",      "4 PAD",      "5 PAD",      "6 PAD",
   "7 PAD",      "8 PAD",      "9 PAD",      "F1",
   "F2",         "F3",         "F4",         "F5",
   "F6",         "F7",         "F8",         "F9",
   "F10",        "F11",        "F12",        "ESC",
   "KEY60",      "KEY61",      "KEY62",      "BACKSPACE",
   "TAB",        "KEY65",      "KEY66",      "ENTER",
   "KEY68",      "KEY69",      "BACKSLASH",  "KEY71",
   "KEY72",      "KEY73",      "KEY74",      "SPACE",
   "INSERT",     "DEL",        "HOME",       "END",
   "PGUP",       "PGDN",       "LEFT",       "RIGHT",
   "UP",         "DOWN",       "/ PAD",      "* PAD",
   "- PAD",      "+ PAD",      "DEL PAD",    "ENTER PAD",
   "PRINT",      "PAUSE",      "KEY94",      "KEY95",
   "KEY96",      "KEY97",      "KEY98",      "KEY99",
   "KEY100",     "KEY101",     "KEY102",     "= PAD",
   "KEY104",     "KEY105",     "KEY106",     "KEY107",
   "KEY108",     "KEY109",     "KEY110",     "KEY111",
   "KEY112",     "KEY113",     "KEY114",     "LSHIFT",
   "RSHIFT",     "LCONTROL",   "RCONTROL",   "ALT",
   "ALTGR",      "LWIN",       "RWIN",       "MENU",
   "SCRLOCK",    "NUMLOCK",    "CAPSLOCK"
};
*/
char *key_names[] =
{
   "(none)",     "A",          "B",          "C",
   "D",          "E",          "F",          "G",
   "H",          "I",          "J",          "K",
   "L",          "M",          "N",          "O",
   "P",          "Q",          "R",          "S",
   "T",          "U",          "V",          "W",
   "X",          "Y",          "Z",          "0",
   "1",          "2",          "3",          "4",
   "5",          "6",          "7",          "8",
   "9",          "0_PAD",      "1_PAD",      "2_PAD",
   "3_PAD",      "4_PAD",      "5_PAD",      "6_PAD",
   "7_PAD",      "8_PAD",      "9_PAD",      "F1",
   "F2",         "F3",         "F4",         "F5",
   "F6",         "F7",         "F8",         "F9",
   "F10",        "F11",        "F12",        "ESC",
   "TILDE",      "MINUS",      "EQUALS",     "BACKSPACE",
   "TAB",        "OPENBRACE",  "CLOSEBRACE", "ENTER",
   "COLON",      "QUOTE",      "BACKSLASH",  "BACKSLASH2",
   "COMMA",      "STOP",       "SLASH",      "SPACE",
   "INSERT",     "DEL",        "HOME",       "END",
   "PGUP",       "PGDN",       "LEFT",       "RIGHT",
   "UP",         "DOWN",       "SLASH_PAD",  "ASTERISK",
   "MINUS_PAD",  "PLUS_PAD",   "DEL_PAD",    "ENTER_PAD",
   "PRTSCR",     "PAUSE",      "ABNT_C1",    "YEN",
   "KANA",       "CONVERT",    "NOCONVERT",  "AT",
   "CIRCUMFLEX", "COLON2",     "KANJI",
   "LSHIFT",     "RSHIFT",     "LCONTROL",   "RCONTROL",
   "ALT",        "ALTGR",      "LWIN",       "RWIN",
   "MENU",       "SCRLOCK",    "NUMLOCK",    "CAPSLOCK",
   "LSHIFT",     "RSHIFT",     "LCONTROL",   "RCONTROL", "L_ALT", "R_ALT",
   "kc121",      "kC122",      "kc123",  
   "SCRLOCK",    "NUMLOCK",    "CAPSLOCK", "kc127",  

// next is 128

   // joystick equivalents
   // 128-
           "joy1-up","joy1-down","joy1-left","joy1-right",
           "joy1-b0","joy1-b1","joy1-b2","joy1-b3","joy1-b4","joy1-b5","joy1-b6","joy1-b7",
           "joy1-b8","joy1-b9","joy1-b10","joy1-b11","joy1-b12","joy1-b13","joy1-b14","joy1-b15",
           
   // 148-
           "joy2-up","joy2-down","joy2-left","joy2-right",
           "joy2-b0","joy2-b1","joy2-b2","joy2-b3","joy2-b4","joy2-b5","joy2-b6","joy2-b7",
           "joy2-b8","joy2-b9","joy2-b10","joy2-b11","joy2-b12","joy2-b13","joy2-b14","joy2-b15"

};



void press_any()
{
   clear_keybuf();
   if (0) // joystick control
   {
      do
      {
         poll_joystick();
      } while ((joy_b1) || (joy_b2));  // wait for release first, if still pressed on entry
      do
      {
         poll_joystick();
      } while ((!joy_b1) && (!keypressed()) && (!joy_b2));  // wait for press
   }
   else readkey();
}

int press_any_p_rt(int p)
{
   // this function will return a zero all the time unless the player has pressed a control
   int ret = 0;

   poll_joystick();
   //  check for up
   if (players1[p].up_key > 119) players[p].up = joy_check(players1[p].up_key);
   else if (key[players1[p].up_key]) players[p].up = 1;
   if (players[p].up) ret = 1;

   //  check for down
   if (players1[p].down_key > 119) players[p].down = joy_check(players1[p].down_key);
   else if (key[players1[p].down_key]) players[p].down = 1;
   if (players[p].down) ret = 1;

   //  check for left
   if (players1[p].left_key > 119) players[p].left = joy_check(players1[p].left_key);
   else if (key[players1[p].left_key]) players[p].left = 1;
   if (players[p].left) ret = 1;

   //  check for right
   if (players1[p].right_key > 119) players[p].right = joy_check(players1[p].right_key);
   else if (key[players1[p].right_key]) players[p].right = 1;
   if (players[p].right) ret = 1;

   //  check for fire
   if (players1[p].fire_key > 119) players[p].fire = joy_check(players1[p].fire_key);
   else if (key[players1[p].fire_key]) players[p].fire = 1;
   if (players[p].fire) ret = 1;

   //  check for jump
   if (players1[p].jump_key > 119) players[p].jump = joy_check(players1[p].jump_key);
   else if (key[players1[p].jump_key]) players[p].jump = 1;
   if (players[p].jump) ret = 1;

   return ret;
}


int my_readkey(void)
{
   textout_centre_ex(screen, font, "...press new key or joystick control...", SCREEN_W/2, SCREEN_H/2, palette_color[10], 0);
   int c, quit = 0, ret = 0;
   while (!quit)
   {
      int j;
      for (j=0; j<num_joysticks; j++)
      {
         if (joy[j].flags & JOYFLAG_DIGITAL) // if joy stick present
         {
             poll_joystick();   // read joystick
             for (c=0; c<joy[j].num_buttons; c++) // cycle buttons
             {
                if (joy[j].button[c].b) // button pressed
                {
                   while (joy[j].button[c].b) poll_joystick(); // wait for release
                   ret = 132+c+(j*20);
                   quit = 1;
                }
             }
             if (joy[j].stick[0].axis[1].d1) // up
             {
                 while (joy[j].stick[0].axis[1].d1) poll_joystick(); // wait for release
                 ret = 128+(j*20);
                 quit = 1;
             }
             if (joy[j].stick[0].axis[1].d2) // down
             {
                 while (joy[j].stick[0].axis[1].d2) poll_joystick(); // wait for release
                 ret = 129+(j*20);
                 quit = 1;
             }
             if (joy[j].stick[0].axis[0].d1) // left
             {
                 while (joy[j].stick[0].axis[0].d1) poll_joystick(); // wait for release
                 ret = 130+(j*20);
                 quit = 1;
             }
             if (joy[j].stick[0].axis[0].d2) // right
             {
                 while (joy[j].stick[0].axis[0].d2) poll_joystick(); // wait for release
                 ret = 131+(j*20);
                 quit = 1;
             }
         }
      }

      for (c=0; c<128; c++)
      {
         if ((key[c]) && (!key[KEY_ENTER])) // don't let <ENTER> be one of the controls
         {
            while (key[c]); // wait for release
            ret = c;
            quit = 1;
         }
      }
   }
   textout_centre_ex(screen, font, "                                        ", SCREEN_W/2, SCREEN_H/2, palette_color[10], 0);
   return ret;
}


void load_keys()
{
   players1[0].up_key    = get_config_int("GAMECONTROLS", "p1_up_key",    KEY_UP);
   players1[0].down_key  = get_config_int("GAMECONTROLS", "p1_down_key",  KEY_DOWN);
   players1[0].right_key = get_config_int("GAMECONTROLS", "p1_right_key", KEY_RIGHT);
   players1[0].left_key  = get_config_int("GAMECONTROLS", "p1_left_key",  KEY_LEFT);
   players1[0].jump_key  = get_config_int("GAMECONTROLS", "p1_jump_key",  KEY_SPACE);
   players1[0].fire_key  = get_config_int("GAMECONTROLS", "p1_fire_key",  KEY_C);
   players1[0].menu_key  = get_config_int("GAMECONTROLS", "p1_menu_key",  KEY_ESC);
}
void save_keys()
{
   set_config_int("GAMECONTROLS", "p1_up_key",    players1[0].up_key);
   set_config_int("GAMECONTROLS", "p1_down_key",  players1[0].down_key);
   set_config_int("GAMECONTROLS", "p1_right_key", players1[0].right_key);
   set_config_int("GAMECONTROLS", "p1_left_key",  players1[0].left_key);
   set_config_int("GAMECONTROLS", "p1_jump_key",  players1[0].jump_key);
   set_config_int("GAMECONTROLS", "p1_fire_key",  players1[0].fire_key);
   set_config_int("GAMECONTROLS", "p1_menu_key",  players1[0].menu_key);
}

void set_key_menu(int menu, int p, int start_row)
{
   int a = start_row;
   int m = menu;

   sprintf(global_string[m][a+0], "Up ---- %s", key_names[ players1[p].up_key]);
   sprintf(global_string[m][a+1], "Down -- %s", key_names[ players1[p].down_key]);
   sprintf(global_string[m][a+2], "Right - %s", key_names[ players1[p].right_key]);
   sprintf(global_string[m][a+3], "Left -- %s", key_names[ players1[p].left_key]);
   sprintf(global_string[m][a+4], "Jump -- %s", key_names[ players1[p].jump_key]);
   sprintf(global_string[m][a+5], "Fire -- %s", key_names[ players1[p].fire_key]);
   sprintf(global_string[m][a+6], "Menu -- %s", key_names[ players1[p].menu_key]);
   sprintf(global_string[m][a+7], "end" );

   // find longest
   unsigned int longest = 0;
   for (int b=a; b<a+7; b++)
      if (strlen(global_string[m][b]) > longest) longest = strlen(global_string[m][b]);

   for (int b=a; b<a+7; b++)
      while (strlen(global_string[m][b]) < longest)
         strcat(global_string[m][b], " "); // pad string length

}


void set_controller_menu_keys(void)
{
   set_key_menu(9, 0, 10);
}     


void get_all_keys(int p)
// prompts for all seven keys
{
   int x = SCREEN_W/2-70;

   int key_sel;
   clear(screen);
   clear_keybuf();
   rest(100);
   set_key_menu(5, p, 2);
   for (key_sel = 2; key_sel < 9; key_sel++)
   {
      textout_ex(screen, font, global_string[5][key_sel], x, 100+8*key_sel,palette_color[10], 0);
      switch (key_sel)
      {
         case  2: players1[p].up_key    =  my_readkey(); break;
         case  3: players1[p].down_key  =  my_readkey(); break;
         case  4: players1[p].right_key =  my_readkey(); break;
         case  5: players1[p].left_key  =  my_readkey(); break;
         case  6: players1[p].jump_key  =  my_readkey(); break;
         case  7: players1[p].fire_key  =  my_readkey(); break;
         case  8: players1[p].menu_key  =  my_readkey(); break;
      }
      set_key_menu(5, p, 2);
      textout_ex(screen, font, "                                ", x, 100+8*key_sel,palette_color[9], 0);
      textout_ex(screen, font, global_string[5][key_sel], x, 100+8*key_sel,palette_color[9], 0);
   }
   save_keys();
   clear(screen);
}

void test_keys(void)
{
   int quit = 0;

   int x = SCREEN_W/2;
   int y = BORDER_WIDTH + 8;

   clear(screen);

   int col = 15;

   textout_centre_ex(screen, font, "----------------------------------------", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "Test your controller setup here.", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "(F12 to quit)", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "----------------------------------------", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "Test how pressing multiple", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "controls affects other controls.", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "----------------------------------------", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "Keyboards widely differ in the number", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "keys that can be detected at one time.", x, y+=8, palette_color[col], 0);
   textout_centre_ex(screen, font, "----------------------------------------", x, y+=8, palette_color[col], 0);

   int ty = y;

   while (!quit)
   {
      int y = ty;
      proc_controllers();
      rest(20);  
      if (players[0].up) textout_centre_ex(screen, font, "UP", x, y+=8, palette_color[10], 0);
      else textout_centre_ex(screen, font, "    ", x, y+=8, palette_color[10], 0);
      if (players[0].down) textout_centre_ex(screen, font, "DOWN", x, y+=8, palette_color[10], 0);
      else textout_centre_ex(screen, font, "    ", x, y+=8, palette_color[10], 0);
      if (players[0].left) textout_centre_ex(screen, font, "LEFT", x, y+=8, palette_color[10], 0);
      else textout_centre_ex(screen, font, "    ", x, y+=8, palette_color[10], 0);
      if (players[0].right) textout_centre_ex(screen, font, "RIGHT", x, y+=8, palette_color[10], 0);
      else textout_centre_ex(screen, font, "     ", x, y+=8, palette_color[10], 0);
      if (players[0].jump) textout_centre_ex(screen, font, "JUMP", x, y+=8, palette_color[10], 0);
      else textout_centre_ex(screen, font, "    ", x, y+=8, palette_color[10], 0);
      if (players[0].fire) textout_centre_ex(screen, font, "FIRE", x, y+=8, palette_color[10], 0);
      else textout_centre_ex(screen, font, "    ", x, y+=8, palette_color[10], 0);
      if (players[0].menu) textout_centre_ex(screen, font, "MENU", x, y+=8, palette_color[10], 0);
      else textout_centre_ex(screen, font, "    ", x, y+=8, palette_color[10], 0);
      while (key[KEY_F12]) quit = 1;  
   }
}

int joy_check(int p)
{
   if (p == 128) if (joy[0].stick[0].axis[1].d1) return 1;
   if (p == 129) if (joy[0].stick[0].axis[1].d2) return 1;
   if (p == 130) if (joy[0].stick[0].axis[0].d1) return 1;
   if (p == 131) if (joy[0].stick[0].axis[0].d2) return 1;
   if (p == 132) if (joy[0].button[0].b) return 1;
   if (p == 133) if (joy[0].button[1].b) return 1;
   if (p == 134) if (joy[0].button[2].b) return 1;
   if (p == 135) if (joy[0].button[3].b) return 1;
   if (p == 136) if (joy[0].button[4].b) return 1;
   if (p == 137) if (joy[0].button[5].b) return 1;
   if (p == 138) if (joy[0].button[6].b) return 1;
   if (p == 139) if (joy[0].button[7].b) return 1;
   if (p == 140) if (joy[0].button[8].b) return 1;
   if (p == 141) if (joy[0].button[9].b) return 1;
   if (p == 142) if (joy[0].button[10].b) return 1;
   if (p == 143) if (joy[0].button[11].b) return 1;
   if (p == 144) if (joy[0].button[12].b) return 1;
   if (p == 145) if (joy[0].button[13].b) return 1;
   if (p == 146) if (joy[0].button[14].b) return 1;
   if (p == 147) if (joy[0].button[15].b) return 1;

   if (p == 148) if (joy[1].stick[0].axis[1].d1) return 1;
   if (p == 149) if (joy[1].stick[0].axis[1].d2) return 1;
   if (p == 150) if (joy[1].stick[0].axis[0].d1) return 1;
   if (p == 151) if (joy[1].stick[0].axis[0].d2) return 1;
   if (p == 152) if (joy[1].button[0].b) return 1;
   if (p == 153) if (joy[1].button[1].b) return 1;
   if (p == 154) if (joy[1].button[2].b) return 1;
   if (p == 155) if (joy[1].button[3].b) return 1;
   if (p == 156) if (joy[1].button[4].b) return 1;
   if (p == 157) if (joy[1].button[5].b) return 1;
   if (p == 158) if (joy[1].button[6].b) return 1;
   if (p == 159) if (joy[1].button[7].b) return 1;
   if (p == 160) if (joy[1].button[8].b) return 1;
   if (p == 161) if (joy[1].button[9].b) return 1;
   if (p == 162) if (joy[1].button[10].b) return 1;
   if (p == 163) if (joy[1].button[11].b) return 1;
   if (p == 164) if (joy[1].button[12].b) return 1;
   if (p == 165) if (joy[1].button[13].b) return 1;
   if (p == 166) if (joy[1].button[14].b) return 1;
   if (p == 167) if (joy[1].button[15].b) return 1;
   return 0;
}

void set_start_level(int s)
{
   start_level = s;
   sprintf(global_string[7][2], "Start Level (%d)", start_level);
   set_config_int("GAME", "start_level", start_level);
}

void set_passcount_timer_fps(int x)
{
   passcount_timer_fps = x;
   install_int_ex(inc_timer_passcount, BPS_TO_TIMER(passcount_timer_fps));
}

void set_speed(void)
{
   extern int speed;
   sprintf(global_string[8][6],"Speed:%2d fps", speed);
   set_passcount_timer_fps(speed);
//   set_config_int("GAME", "speed", speed);
}

void set_scale_factor(int instant)
{
   show_scale_factor = 80;
   float sfr = 0.01; // scale factor round
   extern float scale_factor;
   int preserve_aspect_ratio = 0;
   scale_factor = round(scale_factor/sfr) * sfr;      


   // enforce max and min
   if (scale_factor < .2) scale_factor = .2;
   if (scale_factor > 40) scale_factor = 40;

   // check aspect ratio
   if (preserve_aspect_ratio)
   {
      int bw = BORDER_WIDTH;
      int SW = (int)( (float)(SCREEN_W - bw *2) / scale_factor);
      int SH = (int)( (float)(SCREEN_H - bw *2) / scale_factor);
      while ((SW > 1999) || (SH > 1999))
      {
         scale_factor += sfr;
         scale_factor = round(scale_factor/sfr) * sfr;      
         SW = (int)( (float)(SCREEN_W - bw *2) / scale_factor);
         SH = (int)( (float)(SCREEN_H - bw *2) / scale_factor);
      }          
   }
   set_config_float("SCREEN", "scale_factor", scale_factor);
   if (instant)
   {
      extern float scale_factor_current;
      scale_factor_current = scale_factor;
   }   
}


void set_map_var(void)
{
   extern int tmy;   // menu pos
   extern int tmtx, tmty; // text position
   extern int mx;
   extern int my;

   extern float steps;

   md = 1; // defaults
   steps = 10;
   tmy = 10;
   my = tmy + 130;
   tmty = my-16; // text

   // set intial map size based on minimum screen dimension / 3
   int smin = 0;
   if (SCREEN_H < SCREEN_W) smin = SCREEN_H;
   else smin = SCREEN_W;
   new_size = smin / 3;
   map_size = new_size;


   md = ( (SCREEN_H-130) /100);

   mx = SCREEN_W/2-(md*50);
   tmtx = mx+(md*50); //text pos


   // set db and create map for level editor
   db = (SCREEN_H/100);
   if (db < 4) db = 4;
   if (db > 20) db = 20;
   // check to see if there is enough space for buttons on the right panel...
   while (SCREEN_W - db*100 < 200) db--; 
   if (db < 2) db = 2;
   destroy_bitmap(lefsm);
   lefsm = create_bitmap(db*100,db*100);
   
   // create a bitmap to use as a mouse pointer
   mp = create_bitmap(db*25,db*25);


   // moved this here from draw_level

   extern int menu_map_size;
   extern int menu_map_x;
   extern int menu_map_y;

   int y_size = SCREEN_H-160;
   int x_size = SCREEN_W-260;

   if (y_size < x_size) menu_map_size = y_size;
   else menu_map_size = x_size;
   if (menu_map_size < 10) menu_map_size = 10;

   menu_map_x = SCREEN_W/2-(menu_map_size/2);
   menu_map_y = 140;

   // splash screen logo position
   mdw_splash_logo_x = SCREEN_W/2;
   mdw_splash_logo_y = SCREEN_H/2;

   // splash screen logo size
   int min_d = SCREEN_H;  // find miniumum dimension
   if (SCREEN_W < SCREEN_H) min_d = SCREEN_W;
   mdw_splash_logo_scale = (float) min_d / 500; // 400 is the exact size, make it bigger for padding
   mdw_splash_logo_th = 2;

   // map screen logo position and size
   int sp = menu_map_x - BORDER_WIDTH;    // how much space do I have between the map and the screen edge?
   mdw_map_logo_scale = (float) sp / 500; // 400 is the exact size, make it bigger for padding
   mdw_map_logo_th = mdw_splash_logo_th;  // same thickness as splash
   mdw_map_logo_x = BORDER_WIDTH + sp/2;
   mdw_map_logo_y = menu_map_y + (int) (mdw_map_logo_scale * 200); // align top of logo with top of map

   // this is the link from splash to map
   mdw_logo_scale_dec = (mdw_splash_logo_scale - mdw_map_logo_scale) / 320;
   mdw_logo_x_dec = (mdw_splash_logo_x - (float)mdw_map_logo_x) / 320;
   mdw_logo_y_dec = (mdw_splash_logo_y - (float)mdw_map_logo_y) / 320;


//   printf("slx %f sly %f\n", mdw_splash_logo_x, mdw_splash_logo_y );
//   printf("mlx %d mly %d\n", mdw_map_logo_x, mdw_map_logo_y );

//   printf("xdec %f ydec %f\n", mdw_logo_x_dec, mdw_logo_y_dec );
//   printf("xdec %f ydec %f\n", mdw_logo_x_dec*320, mdw_logo_y_dec*320 );

/*   // set thickness based on scale 
   if (mdw_map_logo_scale <= .3) mdw_map_logo_th = 1;
   if (mdw_map_logo_scale >  .3) mdw_map_logo_th = 2;
   if (mdw_map_logo_scale >  .5) mdw_map_logo_th = 3;
   if (mdw_map_logo_scale >  .7) mdw_map_logo_th = 5;
  // printf("%d %f\n", mdw_map_logo_th, mdw_map_logo_scale);
*/



}

void set_comp_move_from_controls(int p)
{
   players1[p].comp_move = 0;
   if (players[p].left)  players1[p].comp_move += 1;
   if (players[p].right) players1[p].comp_move += 2;
   if (players[p].up)    players1[p].comp_move += 4;
   if (players[p].down)  players1[p].comp_move += 8;
   if (players[p].jump)  players1[p].comp_move += 16;
   if (players[p].fire)  players1[p].comp_move += 32;
   if (players[p].menu)  players1[p].comp_move = 127;
}

void set_controls_from_comp_move(int g)
{
   int p = game_moves[g][2];
   int t = game_moves[g][3];
   clear_keys(p);

   if (t == 127)
   {
      players[p].menu = 1;
      t -= 127;
   }

   if (t > 31)
   {
      t -= 32;
      players[p].fire = 1;
   }
   if (t > 15)
   {
      t -= 16;
      players[p].jump = 1;
   }
   if (t > 7)
   {
      t -= 8;
      players[p].down=1;
   }
   if (t > 3)
   {
      t -= 4;
      players[p].up = 1;
   }
   if (t > 1)
   {
      t -= 2;
      players[p].right = 1;
   }
   if (t > 0)
   {
      t -= 1;
      players[p].left = 1;
   }
}

void clear_keys(int p)
{
   players[p].left = 0;
   players[p].right = 0;
   players[p].up = 0;
   players[p].down = 0;
   players[p].jump = 0;
   players[p].fire = 0;
   players[p].menu = 0;
}


void rungame_key_check(int p)
{
   if (key[KEY_0]) active_local_player = 0;
   if (key[KEY_1]) active_local_player = 1;
   if (key[KEY_2]) active_local_player = 2;
   if (key[KEY_3]) active_local_player = 3;
   if (key[KEY_4]) active_local_player = 4;
   if (key[KEY_5]) active_local_player = 5;
   if (key[KEY_6]) active_local_player = 6;
   if (key[KEY_7]) active_local_player = 7;

   // dont let alp be an inactive player
   while (!players[active_local_player].active) // if alp not active
      if (++active_local_player > 7) active_local_player = 0;

   if (demo_mode_on)
   {
      if (keypressed())
      {
         int k = readkey();
         k = (k & 0xFF);          // strip upper bits 
         if ((k > 0) && (k < 48)) demo_mode_on = 0;
         if ((k > 55) && (k < 128)) demo_mode_on = 0;

        if (!demo_mode_on)
        {
           game_exit = 1;
           resume_allowed = 0;   
        } 

 
      }
   


// ignore 48 to 55
// ignore all function keys






/*
      poll_joystick();
      clear_keys(active_local_player);
      player_key_check(active_local_player);
*/

   }
}

void set_comp_move_from_player_key_check(int p) // but don't set controls !!!
{
   int cm = 0;

   if ((players1[p].left_key > 119) && (joy_check(players1[p].left_key))) cm += 1;
   else if (key[players1[p].left_key]) cm += 1;

   if ((players1[p].right_key > 119) && (joy_check(players1[p].right_key))) cm += 2;
   else if (key[players1[p].right_key]) cm += 2;

   if ((players1[p].up_key > 119) && (joy_check(players1[p].up_key))) cm += 4;
   else if (key[players1[p].up_key]) cm += 4;

   if ((players1[p].down_key > 119) && (joy_check(players1[p].down_key))) cm += 8;
   else if (key[players1[p].down_key]) cm += 8;

   if ((players1[p].jump_key > 119) && (joy_check(players1[p].jump_key))) cm += 16;
   else if (key[players1[p].jump_key]) cm += 16;

   if ((players1[p].fire_key > 119) && (joy_check(players1[p].fire_key))) cm += 32;
   else if (key[players1[p].fire_key]) cm += 32;

   // if menu key ignore everything else and set to 127
   if ((players1[p].menu_key > 119) && (joy_check(players1[p].menu_key))) cm = 127;
   else if (key[players1[p].menu_key]) cm = 127;
   if (key[KEY_ESC]) cm = 127;

   players1[p].comp_move = cm;
}

void player_key_check(int p)
{
   //  check for up
   if (players1[p].up_key > 119) players[p].up = joy_check(players1[p].up_key);
   else if (key[players1[p].up_key]) players[p].up = 1;

   //  check for down
   if (players1[p].down_key > 119) players[p].down = joy_check(players1[p].down_key);
   else if (key[players1[p].down_key]) players[p].down = 1;

   //  check for left
   if (players1[p].left_key > 119) players[p].left = joy_check(players1[p].left_key);
   else if (key[players1[p].left_key]) players[p].left = 1;

   //  check for right
   if (players1[p].right_key > 119) players[p].right = joy_check(players1[p].right_key);
   else if (key[players1[p].right_key]) players[p].right = 1;

   //  check for fire
   if (players1[p].fire_key > 119) players[p].fire = joy_check(players1[p].fire_key);
   else if (key[players1[p].fire_key]) players[p].fire = 1;

   //  check for jump
   if (players1[p].jump_key > 119) players[p].jump = joy_check(players1[p].jump_key);
   else if (key[players1[p].jump_key]) players[p].jump = 1;

   //  check for menu
   if (players1[p].menu_key > 119) players[p].menu = joy_check(players1[p].menu_key);
   else if (key[players1[p].menu_key]) players[p].menu = 1;
   if (key[KEY_ESC]) players[p].menu = 1;

}

void function_key_check(void)
{
//   extern int test_int;
   extern int speed;
   extern float scale_factor;
   extern int KEY_F1_held;
   extern int KEY_F2_held;
   extern int KEY_F3_held;
   extern int KEY_F4_held;
   extern int KEY_F5_held;
   
   extern int KEY_F6_held;
   extern int KEY_F7_held;
   extern int KEY_F8_held;
   extern int KEY_F10_held;
   extern int KEY_PRTSCR_held;


   if ((key[KEY_F1]) && (!KEY_F1_held))
   {
      KEY_F1_held = 1;
#ifndef RELEASE
      players1[active_local_player].fake_keypress_mode =! players1[active_local_player].fake_keypress_mode;
      printf("fake keypress mode:%d\n", players1[active_local_player].fake_keypress_mode);
#endif


/*
      printf("dif test\n");
      players[0].PX += ftofix(0.0001);

      Ei[2][9]++;
      Efi[3][1] += ftofix(0.0001);

      item[4][3]++;
      itemf[5][0] += ftofix(0.0001);
    
      lifts[6].fy += ftofix(0.0001);

      l[2][3]++; 

*/

/*
      printf("dif test\n");

      void show_player_dif(int ba);
      void show_enemy_dif(int ba);
      void show_item_dif(int ba);
      void show_lifts_dif(int ba);

      show_player_dif(1); 
      show_player_dif(2); 

      show_enemy_dif(1);
      show_enemy_dif(2);

      show_item_dif(1);
      show_item_dif(2);

      show_lifts_dif(1);
      show_lifts_dif(2);
*/

   }
   if (!key[KEY_F1]) KEY_F1_held = 0;


   if ((key[KEY_F2]) && (!KEY_F2_held))
   {
      KEY_F2_held = 1;

   }
   if (!key[KEY_F2]) KEY_F2_held = 0;





   if ((key[KEY_F3]) && (!KEY_F3_held))
   {
      KEY_F3_held = 1;
      next_map_size();

   }
   if (!key[KEY_F3]) KEY_F3_held = 0;
   if ((key[KEY_F4]) && (!KEY_F4_held))
   {
      KEY_F4_held = 1;
      next_map_mode();

   }
   if (!key[KEY_F4]) KEY_F4_held = 0;





   if ((key[KEY_F5]) && (!KEY_F5_held))
   {
      KEY_F5_held = 10;
      scale_factor *= .90;
      set_scale_factor(0);
   }
   if (!key[KEY_F5]) KEY_F5_held = 0;
   if (key[KEY_F5]) if (--KEY_F5_held < 0) KEY_F5_held = 0;
   if ((key[KEY_F6]) && (!KEY_F6_held))
   {
      KEY_F6_held = 10;
      scale_factor *= 1.1;
      set_scale_factor(0);
   }   
   if (!key[KEY_F6]) KEY_F6_held = 0;
   if (key[KEY_F6]) if (--KEY_F6_held < 0) KEY_F6_held = 0;

   if ((KEY_F5_held) && (KEY_F6_held))
   {
      KEY_F5_held = 10;
      KEY_F6_held = 10;
      scale_factor = 1.0;
      set_scale_factor(1);
   }   

   if ((!ima_client) && (!ima_server)) // only adjust speed if not in netgame
   {
      if ((key[KEY_F7]) && (!KEY_F7_held))
      {
         KEY_F7_held = speed/4;
         if (key_shifts & KB_CTRL_FLAG) speed -= 100;
         else if (key_shifts & KB_SHIFT_FLAG) speed -= 20;
         else speed -= 1;
         if (speed < 10) speed = 10;
         set_speed();
      }
      if (!key[KEY_F7]) KEY_F7_held = 0;
      if (key[KEY_F7]) if (--KEY_F7_held < 0) KEY_F7_held = 0;
   
   
      if ((key[KEY_F8]) && (!KEY_F8_held))
      {
         KEY_F8_held = speed/4;
         if (key_shifts & KB_CTRL_FLAG) speed += 100;
         else if (key_shifts & KB_SHIFT_FLAG) speed += 20;
         else speed += 1;
         if (speed > 10000) speed = 10000;
         set_speed();
      }
      if (!key[KEY_F8]) KEY_F8_held = 0;
      if (key[KEY_F8]) if (--KEY_F8_held < 0) KEY_F8_held = 0;
   }

   if ((KEY_F7_held) && (KEY_F8_held))
   {
      KEY_F7_held = 10;
      KEY_F8_held = 10;
      speed = 40;
      set_speed();
   }   

   if ((key[KEY_F10]) && (!KEY_F10_held))
   {
      KEY_F10_held = 1;

      if (show_debug_overlay)  show_debug_overlay = 0;
      else 
      {
//         if ((key_shifts & KB_CTRL_FLAG) && (key_shifts & KB_ALT_FLAG))
         show_debug_overlay = 1;
      } 
   }
   if (!key[KEY_F10]) KEY_F10_held = 0;

   if ((key[KEY_PRTSCR]) && (!KEY_PRTSCR_held))
   {
      KEY_PRTSCR_held = 1;
      BITMAP *ss_bmp = NULL;
      PALETTE ss_pal;
      get_palette(ss_pal);
      ss_bmp = create_sub_bitmap(screen, 0, 0, SCREEN_W, SCREEN_H);

      char filename[80];
      struct tm *timenow;
      time_t now = time(NULL);
      timenow = localtime(&now);
      strftime(filename, sizeof(filename), "screenshots\\%Y%m%d%H%M%S.bmp", timenow);

      save_bitmap(filename, ss_bmp, ss_pal);
      destroy_bitmap(ss_bmp);
   }
   if (!key[KEY_PRTSCR]) KEY_PRTSCR_held = 0;
 
}

void add_game_move(int pc, int type, int data1, int data2)
{
   if (type == 6) // special level done move
   {
      game_moves[game_move_entry_pos][0] = pc;
      game_moves[game_move_entry_pos][1] = 6; // type 6; level done
      game_moves[game_move_entry_pos][2] = 0; 
      game_moves[game_move_entry_pos][3] = 0; 
      game_move_entry_pos++;
      return; // to exit immediately
   }
   if ((type == 5) && (data2 == 127))        // special client exit move
   {
      game_moves[game_move_entry_pos][0] = pc;
      game_moves[game_move_entry_pos][1] = 1;     // type 1; player state
      game_moves[game_move_entry_pos][2] = data1; // player num
      game_moves[game_move_entry_pos][3] = 64;    // inactive
      game_move_entry_pos++;
      return; // to exit immediately
   }   
   game_moves[game_move_entry_pos][0] = pc;
   game_moves[game_move_entry_pos][1] = type;
   game_moves[game_move_entry_pos][2] = data1;
   game_moves[game_move_entry_pos][3] = data2;
   game_move_entry_pos++;
}   

int game_move_check(int pc, int type, int data1, int data2)
{
   int match = 0;
   // look from current position back 100
   int start_look = game_move_entry_pos-100;
   if (start_look < 0) start_look = 0;
   for (int x = start_look; x<start_look+100; x++)
      if (game_moves[x][0] == pc)
      
         if (game_moves[x][1] == type)
            if (game_moves[x][2] == data1)
               if (game_moves[x][3] == data2)
               {
                   match = 1;
                   return match; // to exit function immed
               }   
   return match; 
}


void show_player_join_quit(void);


void log_bandwidth_stats(int p)
{
   sprintf(msg,"total tx bytes............[%d]", players1[p].tx_total_bytes);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"max tx bytes per frame....[%d]", players1[p].tx_max_bytes_per_frame);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");
    
   sprintf(msg,"avg tx bytes per frame....[%d]", players1[p].tx_total_bytes / passcount);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"max rx bytes per second...[%d]", players1[p].tx_max_bytes_per_tally);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"avg tx bytes per sec......[%d]", (players1[p].tx_total_bytes *40)/ passcount);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"total tx packets..........[%d]", players1[p].tx_total_packets);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"max tx packets per frame..[%d]", players1[p].tx_max_packets_per_frame);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"max tx packets per second.[%d]", players1[p].tx_max_packets_per_tally);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");


   sprintf(msg,"total rx bytes............[%d]", players1[p].rx_total_bytes);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"max rx bytes per frame....[%d]", players1[p].rx_max_bytes_per_frame);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");
    
   sprintf(msg,"avg rx bytes per frame....[%d]", players1[p].rx_total_bytes / passcount);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"max rx bytes per second...[%d]", players1[p].rx_max_bytes_per_tally);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"avg rx bytes per sec......[%d]", (players1[p].rx_total_bytes *40)/ passcount);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"total rx packets..........[%d]", players1[p].rx_total_packets);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"max rx packets per frame..[%d]", players1[p].rx_max_packets_per_frame);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"max rx packets per second.[%d]", players1[p].rx_max_packets_per_tally);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");
}

void log_reason_for_client_quit(int p)
{
   char tmsg[80];
   sprintf(tmsg,"unknown");
   int r = players1[p].quit_reason;
   if (r == 64) sprintf(tmsg,"player quit game with ESC");
   if (r == 65) sprintf(tmsg,"player quit with F12");
   if (r == 70) sprintf(tmsg,"server drop (server sync > 100)");
   if (r == 71) sprintf(tmsg,"server drop (no sdak for 100 frames)");
   if (r == 74) sprintf(tmsg,"client never became active");
   if (r == 75) sprintf(tmsg,"client lost server connection");
   if (r == 80) sprintf(tmsg,"level done");
   if (r == 90) sprintf(tmsg,"local client quit");
   if (r == 91) sprintf(tmsg,"local server quit");
   if (r == 92) sprintf(tmsg,"remote server quit");
   sprintf(msg,"reason for quit...........[%s]", tmsg);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");
}

void log_ending_stats()
{
   int p = active_local_player;
   add_log_entry_sdat_rx_and_game_move_entered(22, p);
   add_log_entry_centered_text(22, p, 76, "", "+", "-");
   sprintf(msg,"total game frames.........[%d]", passcount);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");
   sprintf(msg,"frame when client joined..[%d]", players1[p].join_frame);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

   if (players1[p].quit_frame == 0) players1[p].quit_frame = passcount;
   sprintf(msg,"frame when client quit....[%d]", players1[p].quit_frame);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

   log_reason_for_client_quit(p);

   sprintf(msg,"frames client was active..[%d]", players1[p].quit_frame - players1[p].join_frame);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

   sprintf(msg,"frames skipped............[%d]", players1[p].frames_skipped);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"cdat packets tx'd.........[%d]", players1[p].cdat_packets_tx);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

   sprintf(msg,"cdat late to server.......[%d]", players1[p].serr_c_sync_err);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");
   sprintf(msg,"minimum c_sync............[%d]", players1[p].c_sync_min);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");
   sprintf(msg,"c_sync errors.............[%d]", players1[p].c_sync_err);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");
  
   sprintf(msg,"chdf received.............[%d]", players1[p].chdf_rx );
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

   sprintf(msg,"chdf received on time.....[%d]", players1[p].chdf_on_time );
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");
   
   sprintf(msg,"chdf received late........[%d]", players1[p].chdf_late );
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");
   
   if (players1[p].chdf_rx > 0) 
   {
      sprintf(msg,"percent of late chdf......[%d]", (players1[p].chdf_late*100) / players1[p].chdf_rx);
      add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");
   }

   sprintf(msg,"chdf corrections..........[%d]", players1[p].dif_corr);
   add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

   log_bandwidth_stats(p);

   add_log_entry_centered_text(22, p, 76, "", "+", "-");
}





void log_ending_stats_server()
{
   add_log_entry_centered_text(22, 0, 76, "", "+", "-");

   sprintf(msg,"level.....................[%d]", play_level);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"total frames..............[%d]", passcount);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"total moves...............[%d]", game_move_entry_pos);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"total time (seconds)......[%d]", passcount/40);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"total time (minutes)......[%d]", passcount/40/60);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

   sprintf(msg,"server frames skipped.. ..[%d]", players1[0].frames_skipped);
   add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");


   log_bandwidth_stats(0);

   add_log_entry_centered_text(22, 0, 76, "", "+", "-");

   for (int p=1; p<NUM_PLAYERS; p++)
   {
      if ((players[p].control_method == 2) || (players[p].control_method == 9))
      {
         sprintf(msg,"Player:%d (%s)", p, players1[p].hostname);
         add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

         sprintf(msg,"frame when client joined..[%d]", players1[p].join_frame);
         add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

         if (players1[p].quit_frame == 0) players1[p].quit_frame = passcount;
         sprintf(msg,"frame when client quit....[%d]", players1[p].quit_frame);
         add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

         log_reason_for_client_quit(p);
      
         sprintf(msg,"frames client was active..[%d]", players1[p].quit_frame - players1[p].join_frame);
         add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

         sprintf(msg,"cdat late to server.......[%d]", players1[p].c_sync_err);
         add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

         sprintf(msg,"chdf late.................[%d]", players1[p].chdf_late);
         add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

         sprintf(msg,"chdf corrections..........[%d]", players1[p].dif_corr);
         add_log_entry_position_text(22, p, 76, 10, msg, "|", " ");

         sprintf(msg,"frames skipped............[%d]", players1[p].frames_skipped);
         add_log_entry_position_text(22, 0, 76, 10, msg, "|", " ");

         log_bandwidth_stats(p);

         add_log_entry_centered_text(22, p, 76, "", "+", "-");


      }
   }
}
void proc_game_move(void)
{
  /*  this function looks in the game_moves array for an exact passcount match
      this only processes system moves, not regular game_moves
      its likely that an exact passcount match won't be found and nothing will be done
      if multiple passcounts match they all will be processed
  */

//   for (int x=game_move_entry_pos; x>game_move_entry_pos-20; x--)  // only look back 20 steps at most
//   the above line is wrong 
//   this needs to go all the way back to the start, or new joining players will be wrong
//   for (int x=game_move_entry_pos; x>0; x--)  // look back all the way to the start

// now with state and difs, looking back 100 might be all that is needed
// run game wont work unless look back to start

   int ll; 
   if (players[0].control_method == 1) ll = 0; // run game needs to look back to the start
   else ll = game_move_entry_pos - 100; // every other mode can just look back 100
   if (ll < 0) ll = 0; // don't look back past zero!
  

   for (int x=game_move_entry_pos; x>ll; x--)  // look back for passcount
   {
      if (game_moves[x][0] == passcount)
      {
         switch (game_moves[x][1])
         {
            case 0:  /* 'game_start' ; a marker to the start of the gamefile */  break;

            case 6:  // 'level done' 
               if (L_LOGGING)
               {  
                  #ifdef LOGGING
                  extern int play_level;                              
                  sprintf(msg,"LEVEL %d DONE", play_level);
                  add_log_entry_header(10, 0, msg, 3);
                  #endif 
               }
               if ((ima_client) || (ima_server)) 
               {  
                  for (int p=0; p<NUM_PLAYERS; p++)
                     if (players[p].active) players1[p].quit_reason = 80;

                  if (L_LOGGING_NETPLAY)
                  { 
                     #ifdef LOGGING_NETPLAY
                     if (ima_client) log_ending_stats();
                     if (ima_server) log_ending_stats_server();
                     #endif
                  }
               }   
               proc_level_done();
            break;

            case 1:  // player state and color
            {
               int val = game_moves[x][3]; // color, active, quit reason, this does it all  
               int p = game_moves[x][2];
               if (val > 63) // player becomes inactive
               {
                  players1[p].quit_reason = val;
                  players1[p].quit_frame = passcount;

                  if ((players[p].active == 0) && (players[p].control_method == 2))
                  {
                     #ifdef LOGGING_NETPLAY
                     sprintf(msg,"PLAYER:%d never became ACTIVE", p);
                     add_log_entry_header(10, p, msg, 1);
                     #endif
                     players1[p].join_frame = passcount;
                     players1[p].quit_reason = 74;
                     players[p].control_method = 9; // prevent re-use of this player number in this level
                     players1[p].who = 99; 
                  }

                  if (players[p].active)
                  {

                     if (players[p].control_method == 1) // run game only
                     {
                        players[p].active = 0; 
                        // only quit if no players left active
                        int still_active = 0;   
                        for (int p=0; p<NUM_PLAYERS; p++)
                           if (players[p].active) still_active = 1;
                        if (!still_active) game_exit = 1;
                     }  


                     if (L_LOGGING_NETPLAY)
                     { 
                        #ifdef LOGGING_NETPLAY
                        sprintf(msg,"PLAYER:%d became INACTIVE", p);
                        add_log_entry_header(10, p, msg, 1);

                        char tmsg[80];

                        sprintf(tmsg,"unknown");

                        if (players1[p].quit_reason == 64) 
                           sprintf(tmsg,"menu key pressed");

                        if (players1[p].quit_reason == 70) 
                           sprintf(tmsg,"dropped by server (server sync > 100)");

                        if (players1[p].quit_reason == 71) 
                           sprintf(tmsg,"dropped by server (no sdak received for 100 frames)");

                        sprintf(msg,"Reason:%s", tmsg);
                        add_log_entry_header(10, p, msg, 1);
                        #endif
                     }

                     if (players[p].control_method == 0) // local player only 
                     {
                        game_exit = 1;
                        resume_allowed = 1;
                     }  

                     if (players[p].control_method == 4) // local client quit
                     {
                        if (val == 64) players1[p].quit_reason = 90;
                        game_exit = 1;
                        resume_allowed = 0;
                        if (L_LOGGING_NETPLAY)
                        { 
                           #ifdef LOGGING_NETPLAY
                           sprintf(msg,"Local Client(%s) quit the game.",local_hostname);
                           add_log_entry_header(10, p, msg, 1);
                           log_ending_stats();
                           #endif
                        }
                        active_local_player = 0;   
                        players[0].control_method = 0; // local control
                     }

                     if (players[p].control_method == 3) // local server quit
                     {
                        if (val == 64) players1[p].quit_reason = 91;
                        game_exit = 1;
                        resume_allowed = 0;
                        if (L_LOGGING_NETPLAY)
                        { 
                           #ifdef LOGGING_NETPLAY
                           sprintf(msg,"Local Server(%s) quit the game.",local_hostname);
                           add_log_entry_header(10, p, msg, 1);
                           log_ending_stats_server();
                           #endif
                        }
                        players[0].control_method = 0; // local control
                     } 

                     if (players[p].control_method == 2) // if display mode only on client or server
                     {
                        players[p].active = 0; 
                        players[p].control_method = 9; // prevent re-use of this player number in this level
                        players1[p].who = 99; 

                        // only makes sense to show this if not local player 
                        show_player_join_quit_timer = 60;
                        show_player_join_quit_player = p;
                        show_player_join_quit_jq = 0;
                     }   


                     if ((ima_client) && (p == 0))  // remote server quit game on local client
                     {
                        if (val == 64) players1[p].quit_reason = 92;
                        if (L_LOGGING_NETPLAY)
                        { 
                           #ifdef LOGGING_NETPLAY
                           sprintf(msg,"Remote Server ended the game.");
                           add_log_entry_header(10, p, msg, 1);
                           log_ending_stats();
                           #endif
                        } 
                        game_exit = 1;
                        resume_allowed = 0;
                        active_local_player = 0;   
                        players[0].control_method = 0; // local control

                     }   
                  } // end of if player active                       
               }  // end of player becomes inactive  

               if ((players[p].active == 0) && (val > 0) && (val < 16))
               {
                  players[p].active = 1; 
                  players[p].color = val;
                  players[p].bitmap_index = val - 1;

                  players1[p].join_frame = passcount;

                  if (L_LOGGING_NETPLAY)
                  { 
                     #ifdef LOGGING_NETPLAY
                     sprintf(msg,"PLAYER:%d became ACTIVE (color:%d)", p, players[p].color);
                     add_log_entry_header(10, p, msg, 1);
                     #endif
                  }

                  if (p == active_local_player)
                  {
                     if (L_LOGGING_NETPLAY)
                     { 
                        #ifdef LOGGING_NETPLAY
                        int finish_time = clock();
                        int time = finish_time - log_timer;
                        log_timer = clock();
                        sprintf(msg,"Chase and lock done in %dms",time);
                        add_log_entry_header(10, p, msg, 1);
                        #endif
                     }
                  }   

                  show_player_join_quit_timer = 60;
                  show_player_join_quit_player = p;
                  show_player_join_quit_jq = 1;

                  if ((ima_server) || (ima_client))
                     if (p != active_local_player) players[p].control_method = 2;

                  // if player 0 is file play all added players will be too
                  if (players[0].control_method == 1) players[p].control_method = 1;
                  init_player(p, 3);
               }                  
            } 
            break; // end of case 1 player state



         } // end of passcount match
      }
   } // end of look back from entry pos                      
}

void proc_controllers()
{ 
   if (game_exit) // if called from menu only do key check for active local player
   {
      poll_joystick();
      clear_keys(active_local_player);
      player_key_check(active_local_player);
   }
   else
   {
      poll_joystick();
      function_key_check();

      extern int level_done;

      for (int p=0; p<NUM_PLAYERS; p++)
         if (players[p].active) // cycle all active players
         {
            if (players[p].control_method == 0) // local single player control
            {
               if (level_done) add_game_move(passcount, 6, 0, 0); // insert level done into game move
               clear_keys(p);
               player_key_check(p);
               set_comp_move_from_controls(p);
               if (players1[p].comp_move != players1[p].old_comp_move)
               {
                  players1[p].old_comp_move = players1[p].comp_move;
                  add_game_move(passcount, 5, p, players1[p].comp_move);
               }
            }
            if (players[p].control_method == 1) // run game from file
            {
               rungame_key_check(p);
               int last_pc = game_moves[game_move_entry_pos-4][0];  
               if ((last_pc < passcount - 100) || (key[KEY_ESC]))
               {
                  // set all players inactive
                  for (int p=0; p<NUM_PLAYERS; p++)
                     players[p].active = 0;

                  // except for local player
                  players[0].active = 1;
                  resume_allowed = 1;
                  game_exit = 1;

               }
            }

#ifdef NETPLAY

            if (players[p].control_method == 3) server_local_control(p);
            if (players[p].control_method == 4) client_local_control(p);
#endif

            // common for all players;  get controls from game_move
            int found = 0; 
            for (int g=game_move_entry_pos; g>0; g--)  // look back from entry pos  
                if ((game_moves[g][1] == 5) && (game_moves[g][2] == p)) // find first that matches type and p
                   if (game_moves[g][0] <= passcount) // check to make sure its not in the future
                   {
                      set_controls_from_comp_move(g);
                      extern int game_move_current_pos; // for savegame running only
                      game_move_current_pos = g;
                      g = 0; // break out of loop
                      found = 1;
                   }
             if (!found) clear_keys(p); // if no match found
       }   // end of active player iterate
      proc_game_move();  // run once per frame to process system messages from game_move
   } // end of if (!game_exit)
}  








































