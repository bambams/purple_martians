// e_fnx.cpp (20100220 cleanup)

#include <allegro.h>
#include "pm.h"

extern int swbl[NUM_SPRITES][2];
extern int swnbl;
extern int swnbl_cur;
 
void initialize_zz(void);

int old_mouse_x;
int old_mouse_y;
int old_mouse_b;

int mouse_changed(void)
{
   int change = 0;
   if (old_mouse_x != mouse_x)
   {
      old_mouse_x = mouse_x;
      change = 1;
//      printf("x\n"); 
   }       
   if (old_mouse_y != mouse_y)
   {
      old_mouse_y = mouse_y;
      change = 1;
//      printf("y\n"); 
   }       
   if (old_mouse_b != mouse_b)
   {
      old_mouse_b = mouse_b;
      change = 1;
//      printf("b\n"); 
   }       
   return change;
}


fixed get_sproingy_jump_height(int num)
{
   fixed t1 = fixdiv(itofix(item[num][7]), ftofix(7.1));
   fixed t2 = itofix(-15); // jump starts not at zero, but at almost one block height off ground
   while (t1 > itofix(0))
   {
      t2 += t1; // distance moved this time period
      t1 -= ftofix(.2); // minus slow gravity               
   }
   return t2;    
}    

// used only in sliders for button set new direction (cannon and podzilla)
void set_xyinc_rot(int EN, int x2, int y2)
{
   fixed xlen = itofix(x2) - Efi[EN][0];      // get the x distance between enemy and x2
   fixed ylen = itofix(y2) - Efi[EN][1];      // get the y distance between enemy and y2
   fixed hy_dist =  fixhypot(xlen, ylen);     // hypotenuse distance
   fixed speed = Efi[EN][5];                  // speed
   fixed scaler = fixdiv(hy_dist, speed);     // get scaler
   fixed xinc = fixdiv(xlen, scaler);         // calc xinc
   fixed yinc = fixdiv(ylen, scaler);         // calc yinc
   Efi[EN][2] = xinc;
   Efi[EN][3] = yinc;
   Efi[EN][14] = fixatan2(ylen, xlen) - itofix(64);
}

// used only in sliders for button set new direction (rocket)
void set_rocket_rot(int num, int x2, int y2)
{
   fixed xlen = itofix(x2) - itofix(item[num][4]);      // get the x distance between item and x2
   fixed ylen = itofix(y2) - itofix(item[num][5]);      // get the y distance between item and y2
   fixed rot = fixatan2(ylen, xlen) + itofix(64);
   item[num][10] = fixtoi(rot) * 10;
}

void set_wx(int x, int y)
{
     extern int wx, wy;
     int d;
     wx = x - SCREEN_W/40;
     wy = y - SCREEN_H/40;

    // check limits 
    d = 100 - (SCREEN_W/20);
    if (wx>d) wx = d;
    if (wx<0) wx = 0;

    d = 100 - (SCREEN_H/20);
    if (wy>d) wy = d;
    if (wy<0) wy = 0;
}
void set_wx_from_start_block(void)
{
   int c, x, y;
   for (c=0; c<500; c++)  // get initial wx, wy from start block 
   if (item[c][0] == 5)
   {
      x = item[c][4]/20;
      y = item[c][5]/20;
       break;
   }
   set_wx(x+4, y);
}

void show_big(BITMAP *b)
{
   blit(lefsm, b, 0, 0, 0, 0, db*100, db*100);
}

void draw_big(int draw_lifts)
{
   init_l2000(); // fill l2000 with blocks and lift lines
   draw_level2(lefsm, 0, 0, db*100, 1, 1, 1, draw_lifts, 0);
   draw_level2(l2000, 0, 0, 2000, 1, 1, 1, 1, 0);
}





void draw_cloner_boxes(BITMAP *b, int num)
{
   int cw = Ei[num][19];     // width 
   int ch = Ei[num][20];     // height  

   int cx1 = Ei[num][15];    // source
   int cy1 = Ei[num][16];     
   int cx2 = cx1 + cw;     
   int cy2 = cy1 + ch;

   int cx3 = Ei[num][17];    // destination
   int cy3 = Ei[num][18];     
   int cx4 = cx3 + cw;     
   int cy4 = cy3 + ch;
   
   int tx1 = Ei[num][11] * db; // trigger box
   int ty1 = Ei[num][12] * db;
   int tx2 = Ei[num][13] * db + db;
   int ty2 = Ei[num][14] * db + db;
   
   set_clip_rect(b, 1, 1, db*100-2, db*100-2);
   rect(b, cx1*db, cy1*db, cx2*db, cy2*db, palette_color[10]); // src
   rect(b, cx3*db, cy3*db, cx4*db, cy4*db, palette_color[11]); // dest
   rect(b, tx1, ty1, tx2, ty2, palette_color[14]);             // trig
   set_clip_rect(b, 0, 0, SCREEN_W-1, SCREEN_H-1);
}


void draw_bs(BITMAP *b, int cc)
{
   BITMAP *jtemp = NULL;

   int dx, dy, ex, ey, mx, my, ssz, ccz;
   int xy_display_on = 1;

   // get mouse pos 
   dx = mouse_x/db;
   dy = mouse_y/db;

   // set bulls eye map size 
   if (db >= 10) ssz = 300;
   if (db == 7) ssz = 300;
   if (db == 4) ssz = 220;
   if (db == 6) ssz = 180;

   ccz = (((ssz/20)-1)/2); // 7 = 3, 5 = 2, 3 = 1 

   mx = -ssz/2 + (db*100) + (SCREEN_W-(db*100)) / 2;
   my = (db*100)-ssz-2;

   ex = dx*20 - (ssz/2-10);
   ey = dy*20 - (ssz/2-10);

   if ((dx<100) && (dy < 100))
   {
      // get background from l2000 for bullseye map sized ssz x ssz 
      jtemp = create_bitmap(ssz, ssz);
      blit(l2000, jtemp, ex, ey, 0, 0, ssz, ssz);

      // clear edges if neccesary 
      if (dx < ccz)    rectfill  (jtemp,  0,   0,  ((ccz-dx)*20)-1,    ssz-1,   palette_color[0]);
      if (dy < ccz)    rectfill  (jtemp,  0,   0,   ssz-1,   ((ccz-dy)*20)-1,   palette_color[0]);
      
      if (dx > 99-ccz) rectfill  (jtemp,  ssz-(ccz-(99-dx))*20,  0,  ssz-1,  ssz-1,   palette_color[0]);
      if (dy > 99-ccz) rectfill  (jtemp,  0,  ssz-(ccz-(99-dy))*20,  ssz-1,  ssz-1,   palette_color[0]);

      // draw red bullseye 
      line(jtemp,        0,   ssz/2-10,     ssz-1,  ssz/2-10,  palette_color[10]);
      line(jtemp,        0,   ssz/2+10,     ssz-1,  ssz/2+10,  palette_color[10]);
      line(jtemp, ssz/2+10,          0,  ssz/2+10,     ssz-1,  palette_color[10]);
      line(jtemp, ssz/2-10,          0,  ssz/2-10,     ssz-1,  palette_color[10]);


      set_clip_rect(b, db*100+1, 0, SCREEN_W-2, SCREEN_H-1);
 
      // blit bullseye to screen 
      blit(jtemp, b, 0, 0, mx+1, my+1, ssz-1, ssz-1);
 
      destroy_bitmap(jtemp);
 
      // frame bullseye 
      rect(b, mx, my, mx+ssz, my+ssz, palette_color[10]);
      set_clip_rect(b, 0, 0, SCREEN_W-1, SCREEN_H-1);

      if (xy_display_on)
      {
         sprintf(msg," x=%-2d     y=%-2d ", dx, dy );
         textout_centre_ex(b, font, msg, txc, my-9, palette_color[15], 0);
      }
   }
   else
   {
      if (xy_display_on)
      {
         sprintf(msg,"  mouse off map  ");
         textout_centre_ex(b, font, msg, txc, my-9, palette_color[14], 0);
      }
      // erase bullseye map 
      rectfill(b, mx, my, mx+ssz, my+ssz, palette_color[0]);
   }
}
int getbox(char *txt, int obj_type, int sub_type, int num )
{
   int bs_on = 1;
   int quit = 0;
   while (mouse_b & 1);    // wait for release 
   while (!quit)
   {
      int dx = mouse_x/db;
      int dy = mouse_y/db;
      //printf(" "); // crashes under win 7 if this line is not here

      title_obj(scrn_buffer, obj_type, sub_type, num, 0, 15);

      // show text line 
      textout_centre_ex(scrn_buffer, font, "Draw a new", txc, 72, palette_color[9], 0);
      textout_centre_ex(scrn_buffer, font, txt, txc, 80, palette_color[10], 0);
      textout_centre_ex(scrn_buffer, font, "by clicking and", txc, 88, palette_color[9], 0);
      textout_centre_ex(scrn_buffer, font, "dragging with the", txc, 96, palette_color[9], 0);
      textout_centre_ex(scrn_buffer, font, "left mouse button", txc, 104, palette_color[9], 0);
      textout_centre_ex(scrn_buffer, font, "Cancel with <ESC> or", txc, 130, palette_color[14], 0);
      textout_centre_ex(scrn_buffer, font, "the right mouse button", txc, 138, palette_color[9], 0);

      if (bs_on) draw_bs(scrn_buffer, 15);

      if ((obj_type == 3) && (sub_type == 9)) // cloner
         draw_cloner_boxes(scrn_buffer, num);


     // show block cursor 
      if ((dx<100) && (dy < 100)) rect(scrn_buffer, dx*db, dy*db, (dx+1)*db-1, (dy+1)*db-1, palette_color[127-32]); // show which block is selected 

      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      show_mouse(NULL);
      rest(10);      
      clear(scrn_buffer); 

      if (mouse_b & 1)
      {
         quit = 1;
         bx1 = mouse_x/db;
         by1 = mouse_y/db;
         while (mouse_b & 1) // trap while b1 is held 
         {
            title_obj(scrn_buffer, obj_type, sub_type, num, 0, 15);

            // show text line 
            textout_centre_ex(scrn_buffer, font, "Draw a new", txc, 72, palette_color[9], 0);
            textout_centre_ex(scrn_buffer, font, txt, txc, 80, palette_color[10], 0);
            textout_centre_ex(scrn_buffer, font, "by clicking and", txc, 88, palette_color[9], 0);
            textout_centre_ex(scrn_buffer, font, "dragging with the", txc, 96, palette_color[9], 0);
            textout_centre_ex(scrn_buffer, font, "left mouse button", txc, 104, palette_color[9], 0);
            textout_centre_ex(scrn_buffer, font, "Cancel with <ESC> or", txc, 130, palette_color[14], 0);
            textout_centre_ex(scrn_buffer, font, "the right mouse button", txc, 138, palette_color[9], 0);

            if (bs_on) draw_bs(scrn_buffer, 15);

            if ((obj_type == 3) && (sub_type == 9)) // cloner
              draw_cloner_boxes(scrn_buffer, num);


            // show selection rectangle 
            bx2 = (mouse_x/db)+1;
            by2 = (mouse_y/db)+1;
            set_clip_rect(scrn_buffer, 0, 0, db*100-1, db*100-1);
            rect(scrn_buffer, (bx1)*db, (by1)*db, (bx2)*db, (by2)*db, palette_color[15]);
            set_clip_rect(scrn_buffer, 0, 0, SCREEN_W-1, SCREEN_H-1);


            blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
            show_mouse(NULL);
            rest(10);      
            clear(scrn_buffer); 
         }
           
         // limits 
         if (bx1<0) bx1 = 0;
         if (bx2<0) bx2 = 0;
         if (by1<0) by1 = 0;
         if (by2<0) by2 = 0;

         if (bx1>99) bx1 = 99;
         if (bx2>99) bx2 = 99;
         if (by1>99) by1 = 99;
         if (by2>99) by2 = 99;
           
         // ensure top-right, bottom left format 
         if (bx1 > bx2)
         {
            int btemp = bx2;
            bx2 = bx1;
            bx1= btemp;
         }
         if (by1 > by2)
         {
            int btemp = by2;
            by2 = by1;
            by1= btemp;
         }
      }
      if  (mouse_b & 2)
      {
         while (mouse_b & 2); // wait for release 
         return 0;
      }
      if (key[KEY_ESC])
      {
         return 0;
      }
   } // end of while not quit 
   return 1;
}
int getxy(char *txt, int obj_type, int sub_type, int num )
{
   int dx, dy;

   // in case these are needed for lifts
   int lift = sub_type;
   int step = num;

   int retval;
   int quit=0;

   while (mouse_b & 1); // wait for release 
   clear(scrn_buffer); 


// get original positions in case we are cancelled
   int original_dx, original_dy;
   if (obj_type == 2)
   {
      original_dx = item[num][4];
      original_dy = item[num][5];
   }     
   if (obj_type == 3)
   {
      original_dx = fixtoi(Efi[num][0]) / 20;
      original_dy = fixtoi(Efi[num][1]) / 20;
   }     

   if (obj_type == 99) // pod extended
   {
      original_dx = fixtoi(Efi[num][5]) / 20;
      original_dy = fixtoi(Efi[num][6]) / 20;
   }     

   if (obj_type == 98) // cloner destination
   {
      original_dx = Ei[num][17];
      original_dy = Ei[num][18];
   }     

   if (obj_type == 4)
   {

      original_dx = lift_steps[lift][step].x / 20;
      original_dy = lift_steps[lift][step].y / 20;
   }

   while(!quit)
   {
      dx = mouse_x/db;
      dy = mouse_y/db;

      if ((dx < 100) && (dy < 100)) // if mouse on map
      {
         switch (obj_type) // show draw_item
         {
            case 2: // show item 
               if (sub_type == 1010) // message display only
               { 
                  show_big(scrn_buffer);
                  set_clip_rect(scrn_buffer, 1, 1, db*100-2, db*100-2);
                  draw_sprite(scrn_buffer, mp, dx*db, dy*db);
                  set_clip_rect(scrn_buffer, 0, 0, SCREEN_W-1, SCREEN_H-1);
               }
               else // all other items
               {
                  item[num][4] = dx*20;
                  item[num][5] = dy*20;
                  itemf[num][0] = itofix(dx*20);
                  itemf[num][1] = itofix(dy*20);
                  draw_big(1);
                  show_big(scrn_buffer);
                  draw_bs(scrn_buffer, 14);            // show bullseye map
                  set_clip_rect(scrn_buffer, 1, 1, db*100-2, db*100-2);
                  rect(scrn_buffer, dx*db, dy*db, (dx+1)*db-1, (dy+1)*db-1, palette_color[127-32]); // draw box to show cursor 
                  set_clip_rect(scrn_buffer, 0, 0, SCREEN_W-1, SCREEN_H-1);
               }   
            break;
            case 3: // show enem 
               Efi[num][0] = itofix(dx * 20);
               Efi[num][1] = itofix(dy * 20);
               draw_big(1);
               show_big(scrn_buffer);
               draw_bs(scrn_buffer, 14);            // show bullseye map
               set_clip_rect(scrn_buffer, 1, 1, db*100-2, db*100-2);
               rect(scrn_buffer, dx*db, dy*db, (dx+1)*db-1, (dy+1)*db-1, palette_color[127-32]); // draw box to show cursor 
               set_clip_rect(scrn_buffer, 0, 0, SCREEN_W-1, SCREEN_H-1);
            break;
            case 99: // move pod extended
            { 
               Efi[num][5] = itofix(dx * 20);
               Efi[num][6] = itofix(dy * 20);
               draw_big(1);
               show_big(scrn_buffer);
               draw_bs(scrn_buffer, 14);     
               int ex = fixtoi(Efi[num][0])*db/20;
               int ey = fixtoi(Efi[num][1])*db/20;
               int px = fixtoi(Efi[num][5])*db/20;
               int py = fixtoi(Efi[num][6])*db/20;
               set_clip_rect(scrn_buffer, 1, 1, db*100-2, db*100-2);
               rect(scrn_buffer, ex, ey, ex+db-1, ey+db-1, palette_color[13]);           // draw box to show pod location
               rectfill(scrn_buffer, px, py, px+db-1, py+db-1, palette_color[10]);       // draw box to show pod extended
               line(scrn_buffer, ex+db/2, ey+db/2, px+db/2, py+db/2, palette_color[10]); // connect with line
               set_clip_rect(scrn_buffer, 0, 0, SCREEN_W-1, SCREEN_H-1);
            }
            break;
            case 98: // cloner destination
            {
               Ei[num][17] = dx;
               Ei[num][18] = dy;
               draw_big(1);
               show_big(scrn_buffer);
               draw_bs(scrn_buffer, 14); 
               draw_cloner_boxes(scrn_buffer, num);
            }
            break;
            case 97: // set new rocket direction
            {
               draw_big(1);
               show_big(scrn_buffer);
               draw_bs(scrn_buffer, 14); 
               int ix = item[num][4]*db/20;
               int iy = item[num][5]*db/20;
               set_clip_rect(scrn_buffer, 1, 1, db*100-2, db*100-2);
               rect(scrn_buffer, ix, iy, ix+db-1, iy+db-1, palette_color[13]);                     // show rocket location
               rectfill(scrn_buffer, dx*db, dy*db, (dx+1)*db-1, (dy+1)*db-1, palette_color[10]);   // show cursor 
               line(scrn_buffer, ix+db/2, iy+db/2, dx*db+db/2, dy*db+db/2, palette_color[10]);     // connect with line
               set_clip_rect(scrn_buffer, 0, 0, SCREEN_W-1, SCREEN_H-1);
            }
            break;
            case 96: // set cannon or bouncer direction
            {   
               draw_big(1);
               show_big(scrn_buffer);
               draw_bs(scrn_buffer, 14);
               int ex = fixtoi(Efi[num][0])*db/20;
               int ey = fixtoi(Efi[num][1])*db/20;
               set_clip_rect(scrn_buffer, 1, 1, db*100-2, db*100-2);
               rect(scrn_buffer, ex, ey, ex+db-1, ey+db-1, palette_color[13]);                   // draw box to show enemy location
               rectfill(scrn_buffer, dx*db, dy*db, (dx+1)*db-1, (dy+1)*db-1, palette_color[10]); // draw box to show cursor 
               line(scrn_buffer, ex+db/2, ey+db/2, dx*db+db/2, dy*db+db/2, palette_color[10]);   // connect with line
               set_clip_rect(scrn_buffer, 0, 0, SCREEN_W-1, SCREEN_H-1);
            }
            break;
            case 4: // show lift 
            {
               lift_steps[lift][step].x = dx*20;
               lift_steps[lift][step].y = dy*20;
               
               //  redraw
               set_lift(lift, step);   // set current step in current lift
               draw_big(1);
               show_big(scrn_buffer);
               draw_bs(scrn_buffer, 14);            // show bullseye map

               set_clip_rect(scrn_buffer, 1, 1, db*100-2, db*100-2);
               void highlight_current_lift(BITMAP *b, int lift);
               highlight_current_lift(scrn_buffer, lift);   // crosshairs and rect on current lift
               set_clip_rect(scrn_buffer, 0, 0, SCREEN_W-1, SCREEN_H-1);
            }
            break;
         }
      } // end of if mouse on map

      // show text line 
      textout_centre_ex(scrn_buffer, font, txt, txc, 80, palette_color[10], 0);
      textout_centre_ex(scrn_buffer, font, "with left mouse button", txc, 88, palette_color[9], 0);
      textout_centre_ex(scrn_buffer, font, "Cancel", txc, 120, palette_color[14], 0);
      textout_centre_ex(scrn_buffer, font, "with right mouse button", txc, 128, palette_color[9], 0);

      show_mouse(scrn_buffer);
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      show_mouse(NULL);
      rest(10);      
      clear(scrn_buffer); 
      title_obj(scrn_buffer, obj_type, sub_type, num, 0, 15);

      while (mouse_b & 1) 
      {
         quit = 1;
         retval = 1;  // b1 xy 
      }
      while (mouse_b & 2)
      {
         quit = 1;
         retval = 2;  // b2 xy 
      }
      while (key[KEY_ESC])
      {
         quit = 1;
         retval = 0;  // ignore xy 
      }
   } // end of while(!quit);   


   if (dx > 99) dx = 99;
   if (dy > 99) dy = 99;
   get100_x = dx;
   get100_y = dy;

   if (retval != 1) // restore old positions if cancelled
   {
      if (obj_type == 2)
      {
         item[num][4] = original_dx;
         item[num][5] = original_dy;
         itemf[num][0] = itofix(original_dx);
         itemf[num][1] = itofix(original_dy);
      }     
      if (obj_type == 3)
      {
          Efi[num][0] = itofix(original_dx * 20);
          Efi[num][1] = itofix(original_dy * 20);
      }     

      if (obj_type == 99)
      {
          Efi[num][5] = itofix(original_dx * 20);
          Efi[num][6] = itofix(original_dy * 20);
      }     

      if (obj_type == 98)
      {
          Efi[num][5] = original_dx;
          Efi[num][6] = original_dy;
      }     

      if (obj_type == 4)
      {
         lift_steps[lift][step].x = original_dx * 20;
         lift_steps[lift][step].y = original_dy * 20;
         set_lift(lift, step);   // set current step in current lift
      }
   }  
   return retval;
}

int get_item(char *txt, int obj_type, int sub_type, int num )
{
   int itx, ity, dx, dy;
   int mouse_on_item = 0;
   int quit = 0;
   int ret_item = -1;

   while (mouse_b & 1);      // wait for release 

   int x2 = item[num][4]/20; // get the door entry position
   int y2 = item[num][5]/20;

   int li = item[num][9];    // get original linked item position
   int x3 = item[li][4]/20;
   int y3 = item[li][5]/20;

   while(!quit)
   {
      // printf(" "); // crashes under win 7 if this line is not here

      // show text line 
      textout_centre_ex(scrn_buffer, font, txt, txc, 80, palette_color[10], 0);
      textout_centre_ex(scrn_buffer, font, "with left mouse button", txc, 88, palette_color[9], 0);
      textout_centre_ex(scrn_buffer, font, "Cancel", txc, 120, palette_color[14], 0);
      textout_centre_ex(scrn_buffer, font, "with right mouse button", txc, 128, palette_color[9], 0);

      show_mouse(scrn_buffer);
      blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
      show_mouse(NULL);
      rest(10);      
      clear(scrn_buffer); 
      title_obj(scrn_buffer, obj_type, sub_type, num, 0, 15);

      dx = mouse_x/db;
      dy = mouse_y/db;

      draw_bs(scrn_buffer, 14);      // show bullseye map

      mouse_on_item = 0;

      if ((dx<100) && (dy<100))      // if mouse on map
         for (int x=0; x<500; x++)   // see if we are pointing at a door item
            if (item[x][0] == 1)  
            {
               itx = item[x][4]/20;
               ity = item[x][5]/20;
               if ((dx == itx) && (dy == ity))  
               {
                  mouse_on_item = 1;
                  ret_item = x;                      
               }
            }    

      itx = item[ret_item][4]/20;
      ity = item[ret_item][5]/20;

      crosshairs(scrn_buffer, 0, 0, x2, y2, 13); // draw the door entry position
      if (mouse_on_item)
      {
         crosshairs(scrn_buffer, 0, 0, itx, ity, 14); // draw the selected item position
         int o = db/2;
         line(scrn_buffer, x2*db+o, y2*db+o, itx*db+o, ity*db+o, palette_color[14]);
         sprintf(msg," Item:%d ", ret_item);
         textout_centre_ex(scrn_buffer, font, msg, txc, 180, palette_color[15], 0);
      }   
      else 
      {
         crosshairs(scrn_buffer, 0, 0, x3, y3, 10);  // show orignal linked item
         int o = db/2;
         line(scrn_buffer, x2*db+o, y2*db+o, x3*db+o, y3*db+o, palette_color[10]);
      }   

      while (mouse_b & 1) quit = 1;
      while ((mouse_b & 2) || (key[KEY_ESC]))
      {
         quit =1;
         ret_item = -1; 
      }

   } // end of while(!quit);   
   if (!mouse_on_item) ret_item = -1;
   return ret_item;
}    


int edit_int(int x, int y, int initial, int inc, int lv, int uv)
{
   extern int edit_int_retval;
   int imx = mouse_x;
   int imy = mouse_y;
   int quit_mode = 0, retval, quit=0, old_mouse;
   
   if (mouse_b & 1) quit_mode = 1;   // set mouse exit mode if b1 pressed on enter 
   clear_keybuf();
   show_mouse(NULL);
   while (!quit)
   {
      position_mouse(160, 100);
      old_mouse = mouse_y;
      sprintf(msg,"%d ",initial);
      textout_ex(screen, font, msg, x, y, palette_color[10], 0);
      rest(10);

      initial = initial - ((mouse_y - old_mouse) * inc);

      if (initial > uv) initial = uv;
      if (initial < lv) initial = lv;

      if (key[KEY_UP])
      {
         clear_keybuf();
         rest(5);
         initial += inc;
      }
      if (key[KEY_DOWN])
      {
         clear_keybuf();
         rest(5);
         initial -= inc;
      }
      if (quit_mode == 1)
      {
         if (!(mouse_b & 1))
         {
            clear_keybuf();
            sprintf(msg,"%d  ",initial);
            textout_ex(screen, font, msg, x, y, palette_color[11], 0);
            edit_int_retval = initial;
            retval = 1;
            quit = 1;
         }
      }
      if (quit_mode == 0)
      {
      if ((key[KEY_ENTER]) || (mouse_b & 1))
      {
         clear_keybuf();
         sprintf(msg,"%d  ",initial);
         textout_ex(screen, font, msg, x, y, palette_color[11], 0);
         edit_int_retval = initial;
         retval = 1;
         quit = 1;
      }
      }
      if ((key[KEY_ESC]) || (mouse_b & 2))
      {
         clear_keybuf();
         retval = 0;
         quit = 1;
      }
   } // end of  while (!quit); 
   position_mouse(imx, imy);
   return retval;
}



void initialize_zz(void)
{
   int c;
   for (c=0; c<NUM_ANS; c++)
      zz[2][c]=0;  // reset the passcount 
   passcount = 0;

   for (c=0; c<NUM_ANS; c++)
      zz[0][c]=zz[5][c];  // set shape one 
}

void set_swbl(int start_shape, int end_shape, int mt)
{
   // set swbl 
   extern int swbn;
   extern int cols;
   extern int fw;
   int c;

   if (mt) cols = (SCREEN_W / (20 + (fw*2)));
   else cols = 16;

   // erase array
   for (c=0; c<NUM_SPRITES; c++)
   {
      swbl[c][0] = 0;
      swbl[c][1] = 0;
   }
   swbn = 0; // set number of blocks to zero initially 

   for (c=start_shape; c<=end_shape; c++)
      if ((sa[c][0] == 1) && (sa[c][1] == 1)) // if block and locked 
            swbl[swbn++][0] = c;   // put shape # in list and inc counter 
   for (c=start_shape; c<=end_shape; c++)
      if ((sa[c][0] == 1) && (sa[c][1] == 0)) // if block and unlocked 
            swbl[swbn++][0] = c;   // put shape # in list and inc counter 
   if (mt)
   {
      int tswbn = swbn;
      for (c=start_shape; c<=end_shape; c++)
         if ((sa[c][0] == 0) && (sa[c][1] == 0)) // if empty and unlocked 
               swbl[tswbn++][0] = c;   // put shape # in list and inc counter 

   }
   swnbl = (swbn / 16) + 1;
   if (swnbl_cur == 0) swnbl_cur = swnbl; // initial only
}
