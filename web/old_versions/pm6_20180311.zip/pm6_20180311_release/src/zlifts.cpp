#include <allegro.h>
#include "pm.h"

void draw_lift_lines()
{
   for (int x=0; x<num_lifts; x++)  // cycle lifts 
   {
      int col = lifts[x].color+128;
      int sx = lift_steps[x][0].x + lifts[x].width * 10;
      int sy = lift_steps[x][0].y + lifts[x].height * 10;
      int px = sx;
      int py = sy;
      int nx;
      int ny;
    
      if (lifts[x].num_steps > 1) // only draw lines if more than one step
      {
         for (int y=0; y<lifts[x].num_steps; y++)  // cycle step
            if (lift_steps[x][y].type == 1) // look for move step 
            {
               nx = lift_steps[x][y].x + lifts[x].width * 10;
               ny = lift_steps[x][y].y + lifts[x].height * 10;
               line (l2000, px, py, nx, ny, palette_color[col]);
               for (int c=3; c>=0; c--)
                  circlefill (l2000, nx, ny, c, palette_color[(col - 96) + c*48]);
               px = nx;
               py = ny;
            }
         line(l2000, sx, sy, nx, ny, palette_color[col]);
      }   
   }
}




void draw_lifts()
{
   for (int d=0; d<num_lifts; d++)
   {
      int x1 = lifts[d].x1;
      int x2 = lifts[d].x2;
      int y1 = lifts[d].y1;
      int y2 = lifts[d].y2;
      int color = lifts[d].color;
      int a;

      // faded outer shell
      for (a=0; a<10; a++) rect(level_buffer, x1+a, y1+a, x2-a, y2-a, palette_color[color + ((9 - a)*16)] );

      // solid core
      rectfill(level_buffer, x1+a, y1+a, x2-a, y2-a, palette_color[color] );

      if ((lifts[d].width == 1) && (lifts[d].height > 1)) // rotate lift name for vertical lifts
         rtextout_centre(level_buffer, lifts[d].lift_name, ((x1+x2)/2)+1, ((y1+y2)/2)+1, color+160, 1, 64);
      else
        textout_centre_ex(level_buffer, font, lifts[d].lift_name, ((x1+x2)/2)+1, ((y1+y2)/2)-2, palette_color[color+160], -1);

      // show if player is riding this lift
      for (int p=0; p<NUM_PLAYERS; p++)
         if ((players[p].active) && (!players[p].paused))
            if ((players[p].player_ride) && (d == players[p].player_ride - 32)) // if player riding lift
            {
               int pc = players[p].color;
               if (pc == color) pc = 127;

               rect(level_buffer, x1, y1, x2, y2, palette_color[pc]);

          //   for (a=0; a<1 ; a++) rect(level_buffer, x1+a, y1+a, x2-a, y2-a, palette_color[pc    + (( 9-a ) * 16)] );
          //   for (a=0; a<10; a++) rect(level_buffer, x1+a, y1+a, x2-a, y2-a, palette_color[pc    + (( a   ) * 16)] );
          //   for (a=0; a<10; a++) rect(level_buffer, x1+a, y1+a, x2-a, y2-a, palette_color[color + (( 9 -a) * 16)] );

             }


      switch (lifts[d].limit_type) // limit type 
      {
         case 5: // timer wait 
            if (lifts[d].limit_counter > 0)
            {
               sprintf(msg,"%d",lifts[d].limit_counter);
               textout_centre_ex(level_buffer, font, msg, (lifts[d].x1 + lifts[d].x2)/2 + 2,
                                                           lifts[d].y1 - 8, palette_color[color+64], -1);
            }
         break;
         case 6: // prox wait 
         {
            int pd = lifts[d].limit_counter; // prox dist 
            int bx1 = x1 - pd;
            int by1 = y1 - pd;
            int bx2 = x2 + pd;
            int by2 = y2 + pd;
            rect(level_buffer, bx1+10, by1+10, bx2-10, by2-10, palette_color[color+128]);
         }
         break;
      } 
   }  // end of iterate lifts
}
      

void set_lift_xyinc(int d, int step)
{
   //  used when switching to a new move step;
   //  sets xinc, yinc and num of frames for mode 7 (move)

   lifts[d].limit_type = 7;   // move step countdown limit type 7 

   // get the integer x and y distances between current pos and next step
   int xln = lifts[d].x1 - lift_steps[d][step].x; 
   int yln = lifts[d].y1 - lift_steps[d][step].y; 
   if ((xln == 0) && (yln == 0)) // no move needed
   {
      lifts[d].limit_counter = 1;
      lifts[d].fxinc = itofix(0); 
      lifts[d].fyinc = itofix(0); 
   }      
   else 
   { 
      fixed xlen = itofix(xln);   // get the x distance
      fixed ylen = itofix(yln);   // get the y distance
   
      fixed hy_dist = fixhypot(xlen, ylen);     // hypotenuse distance
      fixed speed = itofix(lift_steps[d][step].val) / 10;  // speed is stored scaled by 10
   
      fixed scaler = fixdiv(hy_dist, speed);     // get scaler
      fixed xinc = fixdiv(xlen, scaler);         // calc xinc
      fixed yinc = fixdiv(ylen, scaler);         // calc yinc

      if (abs(xlen) > abs(ylen))  // xlen is longer so use this to set limit counter
         lifts[d].limit_counter = fixtoi( abs( fdiv(xlen, xinc))); // steps = distance / increment  
      
      if (abs(xlen) <= abs(ylen)) // ylen is longer or they are equal
         lifts[d].limit_counter = fixtoi( abs( fdiv(ylen, yinc))); // steps = distance / increment 

      lifts[d].fxinc = -xinc;
      lifts[d].fyinc = -yinc;
   }   
}

void move_lifts(int ignore_prox)
{
   for (int d=0; d<num_lifts; d++)
   {
      lifts[d].fx += lifts[d].fxinc;        // xinc 
      lifts[d].fy += lifts[d].fyinc;        // yinc 
      lifts[d].x1 = fixtoi(lifts[d].fx);    // put as int in x1 
      lifts[d].y1 = fixtoi(lifts[d].fy);    // put as int in y1 
      lifts[d].x2 = lifts[d].x1 + (lifts[d].width *20)-1;  // width  
      lifts[d].y2 = lifts[d].y1 + (lifts[d].height*20)-1;  // height 

      // limits 
      int next_step = 0;
      switch (lifts[d].limit_type) // limit type 
      {
         case 5: // timer wait 
            if (--lifts[d].limit_counter < 0) next_step = 1;
         break;   
         case 7: // step count 
            if (--lifts[d].limit_counter < 0)
            {
               next_step = 1;
               //make sure lift is exactly where it should be at the end of the move...


               int step = lifts[d].current_step;
               lifts[d].x1 = lift_steps[d][step].x; 
               lifts[d].y1 = lift_steps[d][step].y; 
               lifts[d].x2 = lifts[d].x1 + lifts[d].width*20; 
               lifts[d].y2 = lifts[d].y1 + lifts[d].height*20; 
               lifts[d].fx = itofix(lifts[d].x1); 
               lifts[d].fy = itofix(lifts[d].y1); 
               
            }   
               
         break;
         case 6: // prox wait 
            if (ignore_prox) next_step = 1;
            else            
            {
                              
               int pd = lifts[d].limit_counter; // prox dist 
               int bx1 = lifts[d].x1 - pd - 10;
               int by1 = lifts[d].y1 - pd - 10;
               int bx2 = lifts[d].x2 + pd - 10;
               int by2 = lifts[d].y2 + pd - 10;
   
               for (int p=0; p<NUM_PLAYERS; p++)
                  if (players[p].active)
                     if ((players[p].PX > itofix(bx1)) && (players[p].PX < itofix(bx2)))
                        if ((players[p].PY > itofix(by1)) && (players[p].PY < itofix(by2))) next_step = 1;
            }            
         break;

      }
      if (next_step)
      {
         if (++lifts[d].current_step > lifts[d].num_steps - 1)    // increment step
               lifts[d].current_step = lifts[d].num_steps -1;     // bounds check (for lifts with no loop to zero)
             
         int step = lifts[d].current_step;
         next_step = 0;
         switch (lift_steps[d][step].type)
         {
            case 1: // move 
               set_lift_xyinc(d, step);
            break;
            case 2: // wait time 
               lifts[d].limit_type = 5; // wait time 
               lifts[d].limit_counter = lift_steps[d][step].val; // limit 
               lifts[d].fxinc= 0; // no xinc 
               lifts[d].fyinc= 0; // no yinc 
            break;
            case 3: // wait prox 
               lifts[d].limit_type = 6; // wait prox
               lifts[d].limit_counter = lift_steps[d][step].val; // limit 
               lifts[d].fxinc= 0; // no xinc 
               lifts[d].fyinc= 0; // no yinc 
            break;
            case 4: // move to step 0 
               step = lifts[d].current_step = 0; // set step 0 
               set_lift_xyinc(d, step);
            break;
         }
      } // end of next step
   } // end of lift iterate 
}







