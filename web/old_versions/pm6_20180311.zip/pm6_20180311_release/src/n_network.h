extern int NetworkDriver;
int NetworkInit();

