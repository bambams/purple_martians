// e_lev.cpp (20171118)  // level viewer and renamer  

#include <allegro.h>
#include <math.h>
#include "pm.h"


#define NUM_LEV 400



// globals
int sel = 0;
int old_sel = 0;
int cur = 0;
int old_cur = 0;


int draw_frames = 1;






int lev_item_data(BITMAP *b, int x_pos,  int y_pos)
{
   int inum = 0;    // zero the counter
   for (int c=0; c<20; c++)
   {
//      sprintf(msg, "                      ");
//      textout_ex(screen, font, msg, x_pos, y_pos+c*8, palette_color[10], 0); // clear old 
      item_num_of_type[c] = 0;
   }      
   
   // get data about first 20 item types
   // and make sub lists of item types using these variables
   for (int c=0; c<500; c++) // get the type counts
   {
      item_num_of_type[item[c][0]]++; // inc number of this type
      if (item[c][0]) inum++;
      
   }


   sprintf(msg, "%-2d Items", inum);
   textout_ex(b, font, msg, x_pos, y_pos, palette_color[15], 0);
   y_pos += 8;

   sprintf(msg, "--------");
   textout_ex(b, font, msg, x_pos, y_pos, palette_color[15], 0);
   y_pos += 8;

   sprintf(msg, "%-2d Starts     ",  item_num_of_type[5]);
   textout_ex(b, font, msg, x_pos, y_pos, palette_color[13], 0);
   y_pos += 8;

   sprintf(msg, "%-2d Exits      ", item_num_of_type[3]);
   textout_ex(b, font, msg, x_pos, y_pos, palette_color[13], 0);
   y_pos += 8;

   if (item_num_of_type[12]) 
   {
      sprintf(msg, "%-2d Warps      ", item_num_of_type[12]);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[10], 0);
      y_pos += 8;
   }      
   if (item_num_of_type[1]) 
   {
      sprintf(msg, "%-2d Doors      ", item_num_of_type[1]);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[13], 0);
      y_pos += 8;
   }      
   if (item_num_of_type[4]) 
   {
      sprintf(msg, "%-2d Keys       ", item_num_of_type[4]);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[13], 0);
      y_pos += 8;
   }      
   if (item_num_of_type[14]) 
   {
      sprintf(msg, "%-2d Switches   ", item_num_of_type[14]);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[13], 0);
      y_pos += 8;
   }      
   if (item_num_of_type[15]) 
   {
      sprintf(msg, "%-2d Sproingies ", item_num_of_type[15]);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[13], 0);
      y_pos += 8;
   }      
   if (item_num_of_type[8]) 
   {
      sprintf(msg, "%-2d Bombs      ", item_num_of_type[8]);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[14], 0);
      y_pos += 8;
   }      
   if (item_num_of_type[11]) 
   {
      sprintf(msg, "%-2d Rockets    ", item_num_of_type[11]);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[14], 0);
      y_pos += 8;
   }      
   if (item_num_of_type[7]) 
   {
      sprintf(msg, "%-2d Mines      ", item_num_of_type[7]);
      textout_ex(b, font, msg, x_pos, y_pos, palette_color[14], 0);
      y_pos += 8;
   }      


   for (int c=1; c<16; c++)
   {
      if ((c != 5) && (c !=3) && (c!= 12) && (c!= 1) && (c!= 4) && (c!= 14) && (c!= 15) && (c!= 8) && (c!= 11) && (c!= 7))
         if (item_num_of_type[c]) // not zero
         {    
            sprintf(msg, "%-2d type %d???", item_num_of_type[c], c); // default
   
            if (c==0)  sprintf(msg, "%-2d type 0      ", item_num_of_type[c]);
            if (c==2)  sprintf(msg, "%-2d Bonus       ", item_num_of_type[c]);
            if (c==6)  sprintf(msg, "%-2d Free Men    ", item_num_of_type[c]);
            if (c==9)  sprintf(msg, "%-2d ???WTF      ", item_num_of_type[c]);
            if (c==10) sprintf(msg, "%-2d Messages    ", item_num_of_type[c]);
      
            textout_ex(b, font, msg, x_pos, y_pos, palette_color[3], 0);
            y_pos += 8;
         }   
   }
   return y_pos;
}




int lev_enemy_data(BITMAP *b, int x_pos, int y_pos)
{
   int e_num_of_type[20];
   int e_num = 0;

   // get data about first 20 enem types and make sub lists of enem types using these variables 
   for (int c=0; c<20; c++)   // zero the counters 
   {
      e_num_of_type[c] = 0;
//      sprintf(msg, "                      ");
//      textout_ex(screen, font, msg, x_pos, y_pos+c*8, palette_color[10], 0); // clear old 
   }
   for (int c=0; c<100; c++)  // counts 
   {
      e_num_of_type[Ei[c][0]]++;   // inc number of this type  
      if (Ei[c][0]) e_num++;
   }

   sprintf(msg, "%-2d Enemies", e_num);
   textout_ex(b, font, msg, x_pos, y_pos, palette_color[15], 0);
   y_pos += 8;

   sprintf(msg, "----------");
   textout_ex(b, font, msg, x_pos, y_pos, palette_color[15], 0);
   y_pos += 8;

   for (int c=1; c<16; c++)
   {
      if (e_num_of_type[c]) // not zero
      {    
         sprintf(msg, "%-2d %s", e_num_of_type[c], enemy_name[c]); // default
         textout_ex(b, font, msg, x_pos, y_pos, palette_color[10], 0);
         y_pos += 8;
      }   
   }
   return y_pos;
}



int lev_show_level_data(BITMAP *b, int x_pos, int y_pos)
{

   int ey_pos = lev_enemy_data(b, x_pos, y_pos); 
   
   int iy_pos = lev_item_data(b, x_pos+135, y_pos);

   ey_pos = ey_pos + 8;

   sprintf(msg, "%d Lifts  ", num_lifts);
   textout_ex(b, font, msg, x_pos, ey_pos, palette_color[15], 0);
   ey_pos += 8;

   sprintf(msg, "-------");
   textout_ex(b, font, msg, x_pos, ey_pos, palette_color[15], 0);
   ey_pos += 8;

   if (iy_pos > ey_pos) return iy_pos;
   else return ey_pos; 

}



void mark_rect(int sel, int color)
{
   int y = (sel/20) * 50;
   int x = (sel % 20) * 50;
   rect(screen,   x,   y, x+49, y+49, palette_color[color]);
   rect(screen, x+1, y+1, x+48, y+48, palette_color[color]);
}

void show_cur(void)
{
   rectfill(screen, 1000, 0, 1280, 1024/2, palette_color[0]); 

   sprintf(msg, "Currently selected level");
   textout_centre_ex(screen, font, msg, 1000+ (1280 - 1000)/2, 4, palette_color[14], 0);

   sprintf(msg, "Level:[%d]", cur);
   textout_centre_ex(screen, font, msg, 1000+ (1280 - 1000)/2, 15, palette_color[14], 0);

   rect(screen, 1000, 24, 1279, 303, palette_color[14] ); 
   rect(screen, 1001, 25, 1278, 302, palette_color[14] ); 

   int ts = 110;

   rect(screen, 1000, 24, 1279, 303+ts, palette_color[14] ); 
   rect(screen, 1001, 25, 1278, 302+ts, palette_color[14] ); 


   if (load_level(cur, 0))
   {
      draw_level2(screen, 1002, 26, 276, 1, 1, 1, 1, 0);
      lev_show_level_data(screen, 1010, 308);
   }   
   else textout_centre_ex(screen, font, "not found", 1000 + (1280 - 1000)/2, 30, palette_color[10], 0);
     
}    

void show_msel(void)
{
   int yo = 1024/2 - 96;

   rectfill(screen, 1000, yo, 1280, 1024, 0); 

   sprintf(msg, "Level under mouse");
   textout_centre_ex(screen, font, msg, 1000+ (1280 - 1000)/2, yo + 4, palette_color[10], 0);

   sprintf(msg, "Level:[%d]", sel);
   textout_centre_ex(screen, font, msg, 1000+ (1280 - 1000)/2, yo + 15, palette_color[10], 0);

   rect(screen, 1000, yo + 24, 1279, yo + 303, palette_color[10] ); 
   rect(screen, 1001, yo + 25, 1278, yo + 302, palette_color[10] ); 

   int ts = 110;

   rect(screen, 1000, yo + 24, 1279, yo + 303+ts, palette_color[10] ); 
   rect(screen, 1001, yo + 25, 1278, yo + 302+ts, palette_color[10] ); 

   if (load_level(sel, 0))
   {
      draw_level2(screen, 1002, yo+26, 276, 1, 1, 1, 1, 0);
      lev_show_level_data(screen, 1010, yo + 308);
   }   
   else textout_centre_ex(screen, font, "not found", 1000 + (1280 - 1000)/2, yo + 30, palette_color[10], 0);
     
}    

























void compare_all(void)
{
   // iterate and load levels
   int le[NUM_LEV]; // level exists array 
   int num_levs = 0;

   for (int x=0; x<NUM_LEV; x++) le[x] = 0; 

   char fn[20] = "levels/level000.pml";

   // level range to look for
   int lll = 0; // lower level limit
   int ull = 400; // upper level limit

   // look for levels that exist and put them in array
   for (int x=lll; x<ull; x++)
   {
      int h, d, rem = x;

      h = rem/100; // hundreds
      fn[12] = 48+h;
      rem -=h*100;

      d = rem/10;  // tens 
      fn[13] = 48 + d;
      rem -=d*10;

      fn[14] = 48 + rem; 
      if (exists(fn)) le[num_levs++] = x; // put in array 
   }

   int num_matches = 0;

   clear(screen);

   sprintf(msg, "<-------------List of matches------------------>"); 
   printf("%s\n", msg);
   textout_ex(screen, font, msg, 10, 100+num_matches*8, palette_color[15], 0);
   num_matches++; 



   // load every level (outer loop)
   for (int x=0; x<num_levs; x++) 
      if (load_level(le[x], 0))
      {

         int pc = (x+1)*100 / num_levs;
         void draw_percent_bar(BITMAP *bmp, int sx, int y, int width, int height, int percent);
         draw_percent_bar(screen, SCREEN_W/2, SCREEN_H/2, SCREEN_W-200, 20, pc );
         textout_centre_ex(screen, font, "Comparing levels", SCREEN_W/2, SCREEN_H/2+6, palette_color[15], -1);




//         printf("compare to level:%d\n", le[x]);
         int sb = 0;
         int m[100][100];
         // copy current level to m
         for (int a=0; a<100; a++)
            for (int b=0; b<100; b++)
            {
               m[a][b] = l[a][b];
               if (l[a][b]) sb++; // count solid blocksin source 
            }              

         // load every level (inner loop)
         for (int x1=0; x1<num_levs; x1++) 
            if (load_level(le[x1], 0))
            {
               int sbm = 0;
               for (int a=0; a<100; a++)
                  for (int b=0; b<100; b++)
                     if (m[a][b])
                        if (m[a][b] == l[a][b]) sbm++; // count solid block matches

               int match = sbm*100/sb;
               
//                  printf("match !!compare to level:[%d] sb1:%d sb2:%d smb:%d [%d]\n", le[x], sb1, sb2, sbm, sbm*100/sb1); 

               if (match > 90)
               {   
                  if (le[x] != le[x1]) 
                  {
                     sprintf(msg, "----> level%d - match [%d%%] with level:%d <----", le[x], match, le[x1]); 
                     printf("%s\n", msg);
                     textout_ex(screen, font, msg, 10, 100+num_matches*8, palette_color[15], 0);
                     num_matches++; 
                  }   
               } 

            } // next level (inner loop)
      } // next level (outer loop)   

   sprintf(msg, "<--------Done. Press any key to continue------->"); 
   printf("%s\n", msg);
   textout_ex(screen, font, msg, 10, 100+num_matches*8, palette_color[15], 0);
   tsw(); 
}   












































void lev_draw(int full)
{
   int ms = 50; // map size
   if (full) // load all the levels again
   {
      clear(scrn_buffer);  
      for (int my=0; my<20; my++) 
      {
         for (int mx=0; mx<20; mx++) 
         {
            int level = my*20 + mx;
            sprintf(msg, "%d", level);
            if (load_level(level, 0))
            {
               draw_level2(scrn_buffer, mx*ms, my*ms, ms, 1, 1, 1, 1, 0);
               sprintf(msg, "%d", level);
               textout_centre_ex(scrn_buffer, font, msg, mx*ms +ms/2, my*ms+ms/2, palette_color[11], 0);
            }   
            else
            {
               sprintf(msg, "%d", level);
               textout_centre_ex(scrn_buffer, font, msg, mx*ms + ms/2, my*ms+ms/2, palette_color[10], 0);
            }  
         }
      }
   }
   blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
   mark_rect(sel, 10);
   mark_rect(cur, 14);

   show_cur();         
   show_msel();

   int ty = 840;

   textout_centre_ex(screen, font, "Change currently selected",        1000+ (1280 - 1000)/2, ty+=8, palette_color[14], 0);
   textout_centre_ex(screen, font, "level with left mouse button",  1000+ (1280 - 1000)/2, ty+=8, palette_color[14], 0);
   ty+=20;
   textout_centre_ex(screen, font, "Move currently selected",          1000+ (1280 - 1000)/2, ty+=8, palette_color[10], 0);
   textout_centre_ex(screen, font, "level to empty level",          1000+ (1280 - 1000)/2, ty+=8, palette_color[10], 0);
   textout_centre_ex(screen, font, "with right mouse button", 1000+ (1280 - 1000)/2, ty+=8, palette_color[10], 0);
   ty+=20;
   textout_centre_ex(screen, font, "View currently selected",          1000+ (1280 - 1000)/2, ty+=8, palette_color[11], 0);
   textout_centre_ex(screen, font, "level full screen",             1000+ (1280 - 1000)/2, ty+=8, palette_color[11], 0);
   textout_centre_ex(screen, font, "by holding 'S'",          1000+ (1280 - 1000)/2, ty+=8, palette_color[11], 0);
   textout_centre_ex(screen, font, "or right mouse button",          1000+ (1280 - 1000)/2, ty+=8, palette_color[11], 0);
   ty+=20;
   textout_centre_ex(screen, font, "Quit with ESC",          1000+ (1280 - 1000)/2, ty+=8, palette_color[12], 0);
}

void level_viewer(void)
{
   scrn_buffer = create_bitmap(SCREEN_W,SCREEN_H);
   clear(screen);
   int redraw = 2;
   while (!key[KEY_ESC])
   { 
      if (key[KEY_S])
      {
         if (load_level(cur, 0)) draw_level2(screen, 0, 0, 1000, 1, 1, 1, 1, 0);
         while (key[KEY_S]);
         redraw = 1; 
      }
      if (redraw)
      {
         if (redraw == 1) lev_draw(0); 
         if (redraw == 2) lev_draw(1); // full reload of levels
         redraw = 0;
      }  

      if (key[KEY_A]) compare_all();

      if (key[KEY_C])
      {
         // check if other levels are similar
         
// compare l[100][100]
// count number of non-zero blocks
// count how many match with other levels...
         printf("Current level :[%d]\n", sel);

         int m[100][100];
         
         // copy current level to m
         for (int a=0; a<100; a++)
            for (int b=0; b<100; b++)
               m[a][b] = l[a][b];          
         
         // iterate and load levels
         int le[NUM_LEV]; // level exists array 
         int num_levs = 0;

         for (int x=0; x<NUM_LEV; x++) le[x] = 0; 

         char fn[20] = "levels/level000.pml";
      
         // level range to look for
         int lll = 0; // lower level limit
         int ull = 400; // upper level limit
      
         // look for levels that exist and put them in array
         for (int x=lll; x<ull; x++)
         {
            int h, d, rem = x;
      
            h = rem/100; // hundreds
            fn[12] = 48+h;
            rem -=h*100;
      
            d = rem/10;  // tens 
            fn[13] = 48 + d;
            rem -=d*10;
      
            fn[14] = 48 + rem; 
            if (exists(fn)) le[num_levs++] = x; // put in array 
         }

         int num_matches = 0;
      
         // load every level
         for (int x=0; x<num_levs; x++) 
            if (load_level(le[x], 0))
            {
               int sb1 = 0, sb2 = 0, sbm = 0;
               for (int a=0; a<100; a++)
                  for (int b=0; b<100; b++)
                  {
                     if (l[a][b]) sb2++;
                     if (m[a][b])
                     {
                        sb1++;                                
                        if (m[a][b] == l[a][b]) sbm++;
                        }   
                  }            

               int match = sbm*100/sb1;
               
//                  printf("match !!compare to level:[%d] sb1:%d sb2:%d smb:%d [%d]\n", le[x], sb1, sb2, sbm, sbm*100/sb1); 


               if (match > 90)
               {   
                  sprintf(msg, "----> match [%d%%] with level:%d <----", match, le[x]); 
                  textout_ex(screen, font, msg, 10, 100+num_matches*8, palette_color[15], 0);
                  num_matches++; 
               } 

            }
         tsw(); 
         redraw = 1; 
      }   

      show_mouse(screen);
      rest(5);
      show_mouse(NULL);

      if ((mouse_x < 1000) && (mouse_y < 1000))  // mouse is on the level grid
      {
         sel = (mouse_y/50) * 20 + (mouse_x/50); // high-light the level the mouse is over
         if (sel != old_sel)
         {
            old_sel = sel;
            redraw = 1; 
         }   

         if (mouse_b & 1) // set new current level
         {
            cur = sel;
            if (load_level(cur, 0)) draw_level2(screen, 0, 0, 1000, 1, 1, 1, 1, 0);
            redraw = 1; 
            while (mouse_b & 1);
/*
            if (cur != old_cur)
            {
               old_cur = cur;
               redraw = 1; 
            }
            */
            
            
            
            
            
            
            
         }            

         if (mouse_b & 2) // copy current to selected
         {
            while (mouse_b & 2);
            if ((cur != 0) && (sel !=0) && (cur != sel)) 
            {
               if (load_level(cur, 0) == 1) // cur exists
                  if (load_level(sel, 0) == 0) // sel does not exist
                  {
                     gui_fg_color = palette_color[10]; gui_bg_color = palette_color[10+224];
                     sprintf(msg, "Level:%d to Level:%d ?", cur, sel);
                     int g = alert3("Are you sure", "you want to move",msg,"Fuck Yeah!","Maybe?", "Never!", 'Y', 'H', 'N');
                     gui_fg_color = palette_color[9]; gui_bg_color = palette_color[0];
                     if (g == 1)
                     {
                        load_level(cur, 0);           // load current level   
                        save_level(sel);              // save as new level
                        make_filename(cur);           // make filename for old
                        delete_file(level_filename);  // delete old file                  
                        redraw = 2;                   // redraw everything (reload all levels) 
                     }   
                  }                                 
            }
         }  // end of mouse b2          
       } // end of mouse on map 
   } // end of while !ESC   
}


void show_sel(void)
{
   rectfill(screen, 1000, 0, 1280, 1024, palette_color[0]); 

   sprintf(msg, "Currently selected level");
   textout_centre_ex(screen, font, msg, 1000+ (1280 - 1000)/2, 4, palette_color[14], 0);

   sprintf(msg, "Level:[%d]", sel);
   textout_centre_ex(screen, font, msg, 1000+ (1280 - 1000)/2, 15, palette_color[14], 0);

   if (load_level(sel, 0))
   {
      draw_level2(screen, 1002, 26, 276, 1, 1, 1, 1, 0);
      rect(screen, 1000, 24, 1279, 303, palette_color[14] ); 
      rect(screen, 1001, 25, 1278, 302, palette_color[14] ); 
      lev_show_level_data(screen, 1010, 308);
   }   
   else textout_centre_ex(screen, font, "not found", 1000 + (1280 - 1000)/2, 30, palette_color[10], 0);
}    



void lev_draw_ls(int full)
{
   int ms = 50; // map size
   if (full) // load all the levels again
   {
      clear(scrn_buffer);  
      for (int my=0; my<20; my++) 
      {
         for (int mx=0; mx<20; mx++) 
         {
            int level = my*20 + mx;
            sprintf(msg, "%d", level);
            if (load_level(level, 0))
            {
               draw_level2(scrn_buffer, mx*ms, my*ms, ms, 1, 1, 1, 1, 0);
               sprintf(msg, "%d", level);
               textout_centre_ex(scrn_buffer, font, msg, mx*ms +ms/2, my*ms+ms/2, palette_color[11], 0);
            }   
            else
            {
               sprintf(msg, "%d", level);
               textout_centre_ex(scrn_buffer, font, msg, mx*ms + ms/2, my*ms+ms/2, palette_color[10], 0);
            }
         }
      }
   }
   blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
   mark_rect(sel, 10);
   show_sel();         

   int ty = 1024*2/3;

   textout_centre_ex(screen, font, "Choose a level",        1000+ (1280 - 1000)/2, ty+=8, palette_color[14], 0);
   textout_centre_ex(screen, font, "with left mouse button",  1000+ (1280 - 1000)/2, ty+=8, palette_color[14], 0);
   ty+=20;
   textout_centre_ex(screen, font, "View currently",          1000+ (1280 - 1000)/2, ty+=8, palette_color[11], 0);
   textout_centre_ex(screen, font, "selected level",          1000+ (1280 - 1000)/2, ty+=8, palette_color[11], 0);
   textout_centre_ex(screen, font, "full screen",             1000+ (1280 - 1000)/2, ty+=8, palette_color[11], 0);
   textout_centre_ex(screen, font, "by holding 'S'",          1000+ (1280 - 1000)/2, ty+=8, palette_color[11], 0);
   ty+=20;
   textout_centre_ex(screen, font, "Quit with ESC",          1000+ (1280 - 1000)/2, ty+=8, palette_color[12], 0);
}



int level_select_dialog(void)
{
   int level_chose = 999;

   scrn_buffer = create_bitmap(SCREEN_W,SCREEN_H);
   clear(screen);

   int redraw = 2;

   int quit = 0;
   while (!quit)
   { 
      if (key[KEY_ESC])
      {
         while (key[KEY_ESC]);
         quit = 1; 
      }

      if (key[KEY_S])
      {
         if (load_level(sel, 0)) draw_level2(screen, 0, 0, 1000, 1, 1, 1, 1, 0);
         while (key[KEY_S]);
         redraw = 1; 
      }
      if (redraw)
      {
         if (redraw == 1) lev_draw_ls(0); 
         if (redraw == 2) lev_draw_ls(1); 
         redraw = 0;
      }  

      show_mouse(screen);
      rest(5);
      show_mouse(NULL);

      if ((mouse_x < 1000) && (mouse_y < 1000))  // mouse is on the level grid
      {
         sel = (mouse_y/50) * 20 + (mouse_x/50); // high-light the level the mouse is over
         if (sel != old_sel)
         {
            old_sel = sel;
            redraw = 1; 
         }   
         if (mouse_b & 1) // choose level and exit
         {
            level_chose = sel;
            quit = 1; 
         }            

       } // end of mouse on map 
   } // end of while !ESC   
   

   return level_chose;
}



void show_cur_vs(int cur, int x1, int y1, int size, int fc)
{
   int x2 = x1 + size;
   int y2 = y1 + size;
   int xc = x1 + size / 2; // text center

   // clear space on screen
//   rectfill(screen, x1, y1, x2, y2+150, 0); 

   sprintf(msg, "Currently selected level");
   textout_centre_ex(scrn_buffer, font, msg, xc, y1+4-5, palette_color[15], 0);

   for (int a=0; a<16; a++)
      rect(scrn_buffer, x1+0-a, y1+24-a, x2-0+a, y2+24+a, palette_color[fc + (15-a)*16] ); 

   int tc = 15;
   if (fc == 15) tc = 0;

   sprintf(msg, "Level %d", cur);
   textout_centre_ex(scrn_buffer, font, msg, xc, y1+15-3, palette_color[tc], -1);

   if (load_level(cur, 0))
   {
      draw_level2(scrn_buffer, x1+2, y1+26, size-3, 1, 1, 1, 1, 0);
      int ty = lev_show_level_data(scrn_buffer, x1+2, y2+32+24);
      for (int a=0; a<16; a++)
         rect(scrn_buffer, x1+0-a, y2+55-a, x2-0+a, ty+a, palette_color[fc + (15-a)*16] ); 
   }   
   else textout_centre_ex(scrn_buffer, font, "not found", xc, y1+30, palette_color[10], 0);
}    



#define NUM_LEV 400

BITMAP * grid_bmp = NULL;
BITMAP * level_icon_bmp[NUM_LEV];
int le[NUM_LEV]; // level exists array 
int num_levs = 0;
int sel_x, sel_y, sel_size;
int grid_cols, grid_rows, grid_size, grid_width, grid_height;
int load_visual_level_select_done = 0;

void load_visual_level_select(void)
{
   load_visual_level_select_done = 1;

   for (int x=0; x<NUM_LEV; x++) le[x] = 0; 


   // level range to look for
   int lll = 1; // lower level limit
   int ull = 50; // upper level limit

/*   int lll = 190; // lower level limit
   int ull = 250; // upper level limit
*/

   char fn[20] = "levels/level000.pml";
   // look for levels that exist and put them in array
   for (int x=lll; x<ull; x++)
   {
      int h, d, rem = x;

      h = rem/100; // hundreds
      fn[12] = 48+h;
      rem -=h*100;

      d = rem/10;  // tens 
      fn[13] = 48 + d;
      rem -=d*10;

      fn[14] = 48 + rem; 
      if (exists(fn)) le[num_levs++] = x; // put in array 
   }

   // now we have the number of levels, we can figure out grid sizes

   // make selection map size 1/3 of SCREEN_W 
   sel_size = SCREEN_W / 3; 

   // position it at 2/3 of SCREEN_W
   sel_x = SCREEN_W * 2 / 3 - 2 -16;  // -16 for frame 
   sel_y = 0;  

   // how much x space is left?
   int x_space = sel_x-2 -32 -16 ; 

   // what is the area of the space left
   int area = x_space * SCREEN_H;

   // how much space for each icon
   int ia = area / num_levs;

   // get the size from this
   grid_size = (int) sqrt((float)ia);           
   grid_size -= grid_size% 20; // mod 20
                    
   // how many icon will fit vertically?
   grid_cols = x_space / grid_size;
   grid_width = grid_cols * grid_size;

   // how many horizontal rows are needed?
   grid_rows = (num_levs-1) / grid_cols+1;  
   grid_height = grid_rows * grid_size;
  
   // check if the intended grid is off the bottom of the screen
   while (grid_height >= SCREEN_H)
   {
      grid_size -= 20;                  

      // how many icon will fit vertically
      grid_cols = x_space / grid_size;
      grid_width = grid_cols * grid_size;
   
      // how many horizontal rows are needed?
      grid_rows = (num_levs-1) / grid_cols+1;  
      grid_height = grid_rows * grid_size;
   }

   // how many icon will fit vertically
   grid_cols = x_space / grid_size;
   grid_width = grid_cols * grid_size;

   // how many horizontal rows are needed?
   grid_rows = (num_levs-1) / grid_cols+1;  
   grid_height = grid_rows * grid_size;

   // resize the selection map to fit available space
   sel_size = SCREEN_W - 64 - grid_width; // (32 for grid frame, 32 for selmap frame)
   sel_x = SCREEN_W - sel_size - 16;  // -16 for frame 

   // create icon bitmaps 
   for (int x=0; x<num_levs; x++)
   {   
      level_icon_bmp[x] = create_bitmap(grid_size, grid_size);
      clear(level_icon_bmp[x]);
   }  

   // load every level and get icon bitmaps  
   for (int x=0; x<num_levs; x++) 
      if (load_level(le[x], 0))
      {
         draw_level2(level_icon_bmp[x], 0, 0, grid_size, 1, 1, 1, 1, 0);
         int pc = x*100 / num_levs;
         void draw_percent_bar(BITMAP *bmp, int sx, int y, int width, int height, int percent);
         draw_percent_bar(screen, SCREEN_W/2, SCREEN_H/2, SCREEN_W-200, 20, pc );
         textout_centre_ex(screen, font, "Creating level icon grid", SCREEN_W/2, SCREEN_H/2+6, palette_color[15], -1);
      }   

   // create the icon grid bitmap
   grid_bmp = create_bitmap(grid_width, grid_height);
   clear(grid_bmp);

   // draw the level icon grid on its bitmap
   for (int row=0; row<grid_rows; row++)
      for (int col=0; col<grid_cols; col++)
      {
         int grid_pos = (row * grid_cols) + col;     // the position in the grid
         int lev = le[grid_pos];                     // the level number that corresponds to that grid position 
         int bx1 = col * grid_size;                  // the screen position of that grid cell 
         int by1 = row * grid_size;

         if (lev)
         {
            blit(level_icon_bmp[grid_pos], grid_bmp, 0, 0, bx1, by1, grid_size, grid_size); 
            sprintf(msg, "%d", lev);
            textout_ex(grid_bmp, font, msg, bx1 + grid_size/2-8, by1 + grid_size/2-4, palette_color[11], 0);
         }
      } // end of grid iterate
   for (int x=0; x<num_levs; x++)  destroy_bitmap(level_icon_bmp[x]);
}

int visual_level_select(void)
{
   int p = active_local_player;
   int fc = players[p].color; // frame color


   if (!load_visual_level_select_done) load_visual_level_select();

   int quit = 0;
   int redraw = 2;
   int grid_sel_row, grid_sel_col;

   // get the initial selection
   int selected_level = start_level;
   int ss = 0;
   for (int x=0; x<num_levs; x++)
      if (le[x] == selected_level) ss = x;
   grid_sel_row = ss / grid_cols;
   grid_sel_col = ss - grid_sel_row * grid_cols;


   while (!quit)
   {
      if (redraw)
      {
         redraw = 0;      
         clear(scrn_buffer);

         // draw the grid of icons
         blit(grid_bmp, scrn_buffer, 0, 0, 16, 16, grid_width, grid_height);  

         // frame the grid
         int gx2 = 15 + grid_width; 
         int gy2 = 15 + grid_height; 

         draw_frames = 1; 

         if (draw_frames)
         {
            for (int a=-16; a<0; a++)
             rect (scrn_buffer, 16+a, 16+a, gx2-a, gy2-a, palette_color[256+fc+a*16]);   
            // frame the selection on grid
            int bx1 = 16 + grid_sel_col * grid_size;
            int by1 = 16 + grid_sel_row * grid_size;
            int bx2 = bx1 + grid_size - 1;
            int by2 = by1 + grid_size - 1;
            for (int a=-16; a<0; a++)
               rect (scrn_buffer, bx1+a, by1+a, bx2-a, by2-a, palette_color[256+fc+a*16]);
         }
 
         // show the large selected level
         show_cur_vs(selected_level, sel_x, 70, sel_size, fc);

         // text legend position
         int tx = sel_x + (sel_size/2);
         int ty = 0;

         if (draw_frames)
         {
            // draw the legend frame 
            int x1 = sel_x;
            int x2 = sel_x + sel_size;
            int y1 = ty+15;
            int y2 = ty+46;
            for (int a=0; a<16; a++)
              rect(scrn_buffer, x1-a, y1-a, x2+a, y2+a, palette_color[fc + (15-a)*16] ); 
         }   
      
         // draw the legend  
         textout_centre_ex(scrn_buffer, font, "Choose a level with <ENTER>", tx, ty+=16, palette_color[14], 0);
         textout_centre_ex(scrn_buffer, font, "Arrow keys change selection", tx, ty+=12, palette_color[11], 0);
         textout_centre_ex(scrn_buffer, font, "<ESC> to abort",              tx, ty+=12, palette_color[10], 0);

         blit(scrn_buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);


      } // end of redraw         

      proc_controllers();
     
      if ((key[KEY_LEFT]) || (players[0].left))
      {
         while ((key[KEY_LEFT]) || (players[0].left)) proc_controllers();
         if (--grid_sel_col < 0) grid_sel_col = 0;  
         redraw = 1; 
      }    
      if ((key[KEY_UP]) || (players[0].up))
      {
         while ((key[KEY_UP]) || (players[0].up)) proc_controllers();
         if (--grid_sel_row < 0) grid_sel_row = 0;  
         redraw = 1; 
      }    
      if ((key[KEY_RIGHT]) || (players[0].right))
      {
         while ((key[KEY_RIGHT]) || (players[0].right)) proc_controllers();
         if (++grid_sel_col > grid_cols-1) grid_sel_col = grid_cols-1;  
         // don't allow select of empty level  
         if (le[(grid_sel_row * grid_cols) + grid_sel_col] == 0) grid_sel_col--;
         redraw = 1; 
      }    
      if ((key[KEY_DOWN]) || (players[0].down))
      {
         while ((key[KEY_DOWN]) || (players[0].down)) proc_controllers();
         if (++grid_sel_row > grid_rows-1) grid_sel_row = grid_rows-1;  
         // don't allow select of empty level  
         if (le[(grid_sel_row * grid_cols) + grid_sel_col] == 0) grid_sel_row--;
         redraw = 1; 
      }    
      selected_level = le[grid_sel_row * grid_cols + grid_sel_col];  
      if ( (key[KEY_ENTER]) || (players[0].fire) || (players[0].jump) || (mouse_b & 1) )
      {
         while ((key[KEY_ENTER]) || (mouse_b & 1));
         while ((players[0].jump) || (players[0].fire)) proc_controllers();
         quit = 1; 
      }    
      if (key[KEY_ESC])
      {
         while (key[KEY_ESC]);
         selected_level = 0;  
         quit = 1; 
      }    
   }
   return selected_level;
}


















